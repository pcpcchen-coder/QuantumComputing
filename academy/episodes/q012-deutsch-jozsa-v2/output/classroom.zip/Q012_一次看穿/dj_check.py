"""父子科技學院 量子電腦學程 Q012：多伊奇–喬薩 判案小程式（只用 Python 內建功能，不用安裝套件）

用法：  python dj_check.py 01101001
        依序填 000、001、010、011、100、101、110、111 這八種輸入的答案（0 或 1）。
不填：  python dj_check.py        → 把場景 8 的四個內建函數各跑一次
"""
import sys

INPUTS = [format(x, '03b') for x in range(8)]          # 000 … 111；最右邊是 x₀
BUILTIN = {                                             # 和 operation.html#interference 三位元模式相同
    '常數 f = 0': '00000000',
    '常數 f = 1': '11111111',
    '平衡 f = x₀（最後一位）': '01010101',
    '平衡 f = 奇偶': '01101001',
}


def judge(name, card):
    f = [int(c) for c in card]
    signs = [-1 if v else 1 for v in f]                 # 黑盒子：答案是 1 的路蓋上負號
    arrows = ''.join('←' if s < 0 else '→' for s in signs)
    # 再做一次哈達瑪閘之後，量到 k 的振幅 = (1/8)·Σ(−1)^f(x)·(−1)^(x·k)
    amp = [sum(s * (-1) ** bin(x & k).count('1') for x, s in enumerate(signs)) / 8 for k in range(8)]
    prob = [round(a * a, 3) for a in amp]
    ones = sum(f)
    kind = '常數' if ones in (0, 8) else '平衡' if ones == 4 else '不是常數也不是平衡（違反保證）'
    print(f'【{name}】卡片 {card}（1 有 {ones} 個 → {kind}）')
    print(f'  八支箭頭：{arrows}　頭尾相接走到 {sum(signs):+d} 格')
    print(f'  量到 000 的機率：{prob[0]}')
    print('  所有結果：' + '、'.join(f'{INPUTS[k]} {p}' for k, p in enumerate(prob) if p > 0))
    verdict = '常數' if prob[0] > 0.999 else '平衡' if prob[0] < 0.001 else '違反保證：量一次不能保證判對'
    print(f'  量子判案：{verdict}\n')


if __name__ == '__main__':
    if len(sys.argv) > 1:
        card = sys.argv[1].strip()
        assert len(card) == 8 and set(card) <= {'0', '1'}, '請填 8 個 0 或 1，例如 01101001'
        judge('我的函數', card)
    else:
        for n, c in BUILTIN.items():
            judge(n, c)
