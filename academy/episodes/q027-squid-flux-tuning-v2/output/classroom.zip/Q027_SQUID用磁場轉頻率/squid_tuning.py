"""父子科技學院 量子電腦學程 Q027：SQUID 調頻曲線（和動畫 index.html#squid 同一套算法）。

不用安裝任何套件，只要 Python 3。執行：  python squid_tuning.py
- 兩個接面合起來的約瑟夫森能量 E_JΣ/h = 20 GHz，充電能量 E_C/h = 0.25 GHz（動畫的設定）。
- E_J(Φ) = E_JΣ × √(cos²(πΦ/Φ₀) + d² sin²(πΦ/Φ₀))，d 是接面不對稱度（0 = 兩個接面一樣）。
- 頻率 f01 ≈ √(8 E_J E_C) − E_C；磁通敏感度 = 頻率對磁通的斜率（和動畫一樣用 ±0.001 Φ₀ 的差分）。
- 參考：學程簡報 JJ_Microwave_Readout_Talk p17；docs/超導量子電腦師生對話教學紀錄.md 第 1–3 課。
"""
import math

EJS = 20.0     # GHz
EC = 0.25      # GHz


def f01(phi, d=0.0):
    c, s = math.cos(math.pi * phi), math.sin(math.pi * phi)
    ej = EJS * math.sqrt(c * c + d * d * s * s)
    return math.sqrt(8 * ej * EC) - EC


def shown(phi, d=0.0):
    """動畫讀數顯示的頻率（負的顯示成 0）。"""
    return max(0.0, f01(phi, d))


def slope(phi, d=0.0):
    return (f01(phi + 1e-3, d) - f01(phi - 1e-3, d)) / 2e-3


print('一、調頻曲線（對稱 d = 0 與不對稱 d = 0.6）')
print('磁通 Φ/Φ₀   f01（d=0）  斜率（d=0）   f01（d=0.6）  斜率（d=0.6）')
TABLE = [round(k * 0.05, 2) for k in range(11)]
for p in TABLE:
    print(f'  {p:5.2f}     {shown(p):6.3f} GHz  {slope(p):7.2f}      {shown(p, 0.6):6.3f} GHz  {slope(p, 0.6):7.2f}')

print()
print('二、闖關：滑桿每格 0.005 Φ₀，找最接近目標的格子（誤差要在 ±0.05 GHz 以內）')
GRID = [round(k * 0.005, 3) for k in range(101)]          # 0 ~ 0.5
TARGETS = [6.0, 5.5, 5.0, 4.5, 4.0]
QUEST = {}
for t in TARGETS:
    best = min(GRID, key=lambda p: abs(shown(p) - t))
    QUEST[t] = (best, shown(best))
    ok = '過關' if abs(shown(best) - t) <= 0.05 else '差太多'
    print(f'  目標 {t:.1f} GHz → 磁通 {best:.3f} Φ₀，頻率 {shown(best):.3f} GHz（差 {abs(shown(best) - t) * 1000:.0f} MHz，{ok}）')

print()
print('三、甜蜜點與雜訊')
NOISE0 = (f01(0) - f01(0.01)) * 1000
NOISE25 = (f01(0.25) - f01(0.26)) * 1000
DROP002 = (f01(0) - f01(0.02)) * 1000
print(f'  磁通 0 的斜率 = {slope(0):.2f}（甜蜜點）；0.25 的斜率 = {slope(0.25):.2f} GHz/Φ₀')
print(f'  同樣抖 0.01 Φ₀：在 0 頻率差 {NOISE0:.1f} MHz，在 0.25 差 {NOISE25:.0f} MHz（約 {NOISE25 / NOISE0:.0f} 倍）')
print(f'  從 0 拉到 0.02 Φ₀：頻率還是降了 {DROP002:.1f} MHz（一階不敏感，不是完全不動）')

print()
print('四、調頻範圍（最高 Φ = 0，最低 Φ = 0.5）')
RANGE = {}
for d in (0.0, 0.3, 0.6, 0.8):
    hi, lo = shown(0, d), shown(0.5, d)
    RANGE[d] = (hi, lo)
    print(f'  d = {d:.1f}：{hi:.3f} → {lo:.3f} GHz，範圍 {hi - lo:.3f} GHz；Φ = 0.25 的斜率 {slope(0.25, d):.2f}')
