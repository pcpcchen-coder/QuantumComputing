"""父子科技學院 量子電腦學程 Q064：模組專題——在模擬器跑我的線路（Release 任務，本機模擬器，不需要帳號）

安裝（只要一次）：  pip install qiskit qiskit-aer
執行：              python my_circuit_release.py
同一份程式也做成筆記本：my_circuit_release.ipynb（Jupyter 或 VS Code 開啟，按「全部重新執行」）
操作檢查表：① 定義問題 → ② 線路 → ③ 轉譯 → ④ 執行 → ⑤ 解讀（寫報告）
"""
# ── 第 0 格：記錄版本（報告第一段要抄）──────────────────────────────────
import sys
import qiskit
import qiskit_aer
VERSIONS = f'Python {sys.version.split()[0]} | qiskit {qiskit.__version__} | qiskit-aer {qiskit_aer.__version__}'
print(VERSIONS)
# 影片與解答用的版本：Python 3.13.18、qiskit 2.6.2、qiskit-aer 0.18.4

# ── 第 1 格：① 定義問題（改造區：換一個學過的演算法）──────────────────────
CHOICE = 'grover2'   # 可以改成 'bell'、'ghz3'、'deutsch'、'grover2'、'grover3'
PROBLEMS = {
    'bell':    ('貝爾態：兩顆位元糾纏', '00 和 11 各一半'),
    'ghz3':    ('格林伯格態：三顆一起糾纏', '000 和 111 各一半'),
    'deutsch': ('多伊奇演算法：f(x) = x 是常數還是平衡？', '1（平衡）'),
    'grover2': ('格羅弗搜尋：4 個抽屜找 11', '11'),
    'grover3': ('格羅弗搜尋：8 個抽屜找 101（2 輪）', '101'),
}
QUESTION, EXPECT = PROBLEMS[CHOICE]
print('問題：', QUESTION, '｜預期答案：', EXPECT)

# ── 第 2 格：② 線路 ───────────────────────────────────────────────────────
from qiskit import QuantumCircuit


def grover(n, target, rounds):
    """n 顆位元的格羅弗搜尋；target 的最右邊是 q0。"""
    qc = QuantumCircuit(n, n)
    qc.h(range(n))                            # 均勻疊加：每個抽屜一樣大
    zeros = [i for i, b in enumerate(reversed(target)) if b == '0']
    for _ in range(rounds):
        if zeros:
            qc.x(zeros)                       # 標記：把答案變成全 1 ……
        qc.h(n - 1); qc.mcx(list(range(n - 1)), n - 1); qc.h(n - 1)   # …… 多控制相位翻轉 ……
        if zeros:
            qc.x(zeros)                       # …… 再還原
        qc.h(range(n)); qc.x(range(n))        # 擴散：對平均值翻轉
        qc.h(n - 1); qc.mcx(list(range(n - 1)), n - 1); qc.h(n - 1)
        qc.x(range(n)); qc.h(range(n))
    qc.measure(range(n), range(n))
    return qc


def build(choice):
    if choice == 'bell':
        qc = QuantumCircuit(2, 2); qc.h(0); qc.cx(0, 1); qc.measure([0, 1], [0, 1])
    elif choice == 'ghz3':
        qc = QuantumCircuit(3, 3); qc.h(0); qc.cx(0, 1); qc.cx(1, 2); qc.measure(range(3), range(3))
    elif choice == 'deutsch':                 # 黑盒 f(x) = x：一個受控反閘
        qc = QuantumCircuit(2, 1); qc.x(1); qc.h([0, 1]); qc.cx(0, 1); qc.h(0); qc.measure(0, 0)
    elif choice == 'grover2':
        qc = grover(2, '11', 1)
    elif choice == 'grover3':
        qc = grover(3, '101', 2)
    return qc


qc = build(CHOICE)
print(qc.draw())

# ── 第 3 格：③ 轉譯到一顆假想的晶片，比較兩種最佳化等級 ─────────────────
from qiskit import transpile
from qiskit.transpiler import CouplingMap

BASIS = ['rz', 'sx', 'x', 'cx']             # 假想晶片的原生閘
CHIP = CouplingMap.from_line(5)              # 直線排列的 5 顆位元，只有相鄰的能做兩位元閘
LEVELS = (0, 3)                              # 0 = 不最佳化；3 = 最用力最佳化
SEED_T = 2026                                # 轉譯也有亂數，固定下來才能重現
compiled = {lv: transpile(qc, basis_gates=BASIS, coupling_map=CHIP, optimization_level=lv, seed_transpiler=SEED_T)
            for lv in LEVELS}


def summary(t):
    ops = t.count_ops()
    return {'深度': t.depth(), 'sx+x': ops.get('sx', 0) + ops.get('x', 0), 'cx': ops.get('cx', 0), 'rz': ops.get('rz', 0)}


for lv, t in compiled.items():
    print(f'最佳化等級 {lv}：', summary(t))

# ── 第 4 格：④ 執行：理想模擬器 vs 加上雜訊模型 ──────────────────────────
from qiskit_aer import AerSimulator
from qiskit_aer.noise import NoiseModel, depolarizing_error, ReadoutError

P1, P2, PR = 0.01, 0.01, 0.03                # 假設值：單位元閘 1%、受控反閘 1%、讀取 3%（rz 是虛擬 Z，不加雜訊）
noise = NoiseModel()
noise.add_all_qubit_quantum_error(depolarizing_error(P1, 1), ['sx', 'x'])
noise.add_all_qubit_quantum_error(depolarizing_error(P2, 2), ['cx'])
noise.add_all_qubit_readout_error(ReadoutError([[1 - PR, PR], [PR, 1 - PR]]))
ideal_sim = AerSimulator()
noisy_sim = AerSimulator(noise_model=noise)
SHOTS, SEED = 1024, 2026


def run(sim, t, seed=SEED):
    counts = sim.run(t, shots=SHOTS, seed_simulator=seed).result().get_counts()
    return dict(sorted(counts.items()))


results = {lv: (run(ideal_sim, t), run(noisy_sim, t)) for lv, t in compiled.items()}
for lv, (ideal, noisy) in results.items():
    print(f'等級 {lv} 理想  ', ideal)
    print(f'等級 {lv} 有雜訊', noisy)

# ── 第 5 格：⑤ 解讀：自動檢查，寫出實驗報告 ─────────────────────────────
top = {lv: max(r[0], key=r[0].get) for lv, r in results.items()}
for lv, (ideal, noisy) in results.items():
    assert sum(ideal.values()) == SHOTS and sum(noisy.values()) == SHOTS
    assert run(noisy_sim, compiled[lv]) == noisy, '同一個種子重跑，數字應該一模一樣'
    assert top[lv] in EXPECT, f'理想模擬最多的結果 {top[lv]} 和預期答案 {EXPECT} 不一樣：先檢查線路'
print('自動檢查全部通過')

VERSION = 'v1.0'
rows = ''.join(f"| {lv} | {summary(compiled[lv])['深度']} | {summary(compiled[lv])['sx+x']} | {summary(compiled[lv])['cx']} "
               f"| {results[lv][0].get(top[lv], 0)} | {results[lv][1].get(top[lv], 0)} |\n" for lv in LEVELS)
report = f"""# 模擬器實驗報告 {VERSION}：{QUESTION}

1. 問題與預期答案：{QUESTION}；預期 {EXPECT}
2. 環境：{VERSIONS}
3. 晶片假設：直線 5 顆，原生閘 {', '.join(BASIS)}；轉譯種子 {SEED_T}
4. 雜訊模型（假設值）：單位元閘 {P1:.0%}、受控反閘 {P2:.0%}、讀取 {PR:.0%}；rz 不加雜訊
5. 執行：shots = {SHOTS}，模擬種子 = {SEED}

| 最佳化等級 | 深度 | sx＋x 個數 | cx 個數 | 理想：{top[LEVELS[0]]} 次數 | 有雜訊：{top[LEVELS[0]]} 次數 |
|---|---|---|---|---|---|
{rows}
6. 我的解讀（自己寫）：＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿
7. 限制：雜訊模型是假設，不代表任何一台真機；換種子、換版本，數字會變。
"""
name = f'report_{CHOICE}_{VERSION}.md'
open(name, 'w', encoding='utf-8').write(report)
print(report)
print('報告存成', name)

# 影片中的結果（CHOICE = 'grover2'，種子 2026）：
#   等級 0：深度 26、sx＋x 14 個、cx 2 個；有雜訊 {'00': 25, '01': 67, '10': 66, '11': 866}
#   等級 3：深度 12、sx＋x 6 個、cx 2 個；有雜訊 {'00': 18, '01': 46, '10': 45, '11': 915}
#   改成 'grover3'：等級 0 cx 51 個、101 有 458 次；等級 3 cx 39 個、101 有 550 次
