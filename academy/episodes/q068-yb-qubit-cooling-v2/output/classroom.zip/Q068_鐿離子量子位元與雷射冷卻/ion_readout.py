"""父子科技學院 量子電腦學程 Q068：離子亮暗讀取模擬（只用 Python 內建功能，不需要安裝任何套件）

執行：python ion_readout.py
模型（和動畫 atoms.html#ionqubit 相同的代表值）：
  亮態 |1⟩：物鏡每微秒收到 0.1 個光子；背景每微秒 0.0005 個
  亮態偶爾經偏共振激發漏到暗態（平均 10000 μs 一次），暗態漏到亮態（平均 100000 μs 一次）
做法：各模擬 20000 次亮態與暗態，找出錯誤最少的閾值（光子數 > 閾值 判為 1）。
"""
import math
import random

random.seed(68)
R, BG, TAU1, TAU0 = 0.1, 0.0005, 10000, 100000


def poisson(lam):
    """數光子：平均 lam 的卜瓦松亂數。"""
    L, k, p = math.exp(-lam), 0, 1.0
    while True:
        k += 1
        p *= random.random()
        if p <= L:
            return k - 1


def shot(bright, t):
    """偵測 t 微秒，回傳收到幾個光子。"""
    tp = random.expovariate(1 / (TAU1 if bright else TAU0))
    te = min(t, tp) if bright else max(0.0, t - tp)
    return poisson(R * te + BG * t)


def best_threshold(t, n=20000):
    c0 = [shot(False, t) for _ in range(n)]
    c1 = [shot(True, t) for _ in range(n)]
    best = None
    for thr in range(12):
        err = (sum(c > thr for c in c0) + sum(c <= thr for c in c1)) / (2 * n)
        if best is None or err < best[1]:
            best = (thr, err)
    return best


# 改造區：換別的偵測時間試試看（微秒）
for t in (50, 100, 200, 300, 500):
    thr, err = best_threshold(t)
    print(f'偵測 {t:3d} μs：亮態平均 {R * t:4.0f} 個光子，閾值 > {thr}，判別保真度 ≈ {100 * (1 - err):.2f}%')

print('暗態 |0⟩ 為什麼暗：偵測光對準 F=1 → F′=0；|0⟩ 往上能吸收的線差了 12.6 + 2.1 =', round(12.6 + 2.1, 1), 'GHz')
