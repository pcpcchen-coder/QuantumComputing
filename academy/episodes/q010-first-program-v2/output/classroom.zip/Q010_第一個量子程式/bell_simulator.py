"""父子科技學院 量子電腦學程 Q010：第一個量子程式——貝爾態（本機模擬器，不需要帳號）

安裝（只要一次）：  pip install qiskit qiskit-aer
執行：              python bell_simulator.py
"""
from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator

# 第一段：建立線路——兩顆量子位元、兩格紀錄
qc = QuantumCircuit(2, 2)

# 改造區：想做另外三種貝爾態，把下面其中一行前面的 # 拿掉
# qc.x(0)        # Φ⁻：直方圖和原本一樣，差在負號
# qc.x(1)        # Ψ⁺：變成 01 和 10
# qc.x([0, 1])   # Ψ⁻：01 和 10，差在負號

# 第二段：照著樂譜加動作
qc.h(0)                         # 哈達瑪閘：第一顆（q0）進入疊加
qc.cx(0, 1)                     # 受控反閘：q0 是 1 時，翻轉 q1
qc.measure([0, 1], [0, 1])      # 把兩顆的結果寫進紀錄
print(qc.draw())

# 第三段：交給模擬器，重複 1024 次，數出每種結果
sim = AerSimulator()
counts = sim.run(transpile(qc, sim), shots=1024).result().get_counts()
print(counts)   # 位元字串的最右邊是 q0（第一顆）

# 想每次都得到同一組數字（例如和影片比對），可以改成：
# counts = sim.run(transpile(qc, sim), shots=1024, seed_simulator=2026).result().get_counts()
# 影片中的結果就是這樣跑出來的：{'00': 516, '11': 508}
