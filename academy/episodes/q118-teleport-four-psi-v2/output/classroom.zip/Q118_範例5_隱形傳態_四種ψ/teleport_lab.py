"""父子科技學院 量子電腦學程 Q118：範例 5 隱形傳態——四種 ψ（純 Python，不需安裝任何套件）

執行：  python teleport_lab.py
它用一個很小的三位元模擬器（只認得 H、X、Z、Ry、CNOT、CZ；振幅都是實數），印出：
  一、四種 ψ 各傳一次（延遲量測版，和 basic-circuits.html#teleport 相同）：每一步「單看 q0」「單看 q2」的 Bloch 向量
  二、Alice 量到什麼、Bob 手上是什麼、要怎麼修（ψ = √¾|0⟩ + ½|1⟩）
  三、真的「先量再修」：Alice 量測、把 2 個位元交給信差、Bob 照紙條修正，各傳 1000 次
  四、拿掉修正、只修一半：Bob 的 q2 變成什麼
  五、改造區：自己選 ψ 的角度、要不要修 X、要不要修 Z，先預測，再執行
q0、q1 在 Alice 那裡，q2 在 Bob 那裡。位元字串寫成 |q2 q1 q0⟩：最右邊那位是 q0（和 Qiskit、basic-circuits.html 一樣）。
Bloch 向量只寫 x、z 兩個分量（振幅都是實數，所以 y = 0）；大小 1 是「單看它是確定的狀態」，0 是縮在球心、完全隨機。
"""
import random
from math import cos, pi, sin, sqrt

R2 = 1 / sqrt(2)

# 四種要傳的狀態 ψ（和 basic-circuits.html#teleport 上方的選項相同），以及在 q0 準備它的閘
PSI = {
    '√¾|0⟩+½|1⟩': [('ry', 0, pi / 3)],
    '|1⟩': [('x', 0)],
    '|+⟩': [('h', 0)],
    '|−⟩': [('x', 0), ('h', 0)],
}
ENTANGLE = [('h', 1), ('cx', 1, 2)]          # 第 2 步：q1、q2 成為 Bell 態，q2 交給 Bob
ALICE = [('cx', 0, 1), ('h', 0)]              # 第 3 步：Bell 量測的前半
FIX = [('cx', 1, 2), ('cz', 0, 2)]            # 第 4 步：延遲量測版的修正（q1 控制 X、q0 控制 Z）


def run(gates, s=None):
    """三顆位元（第 i 根柱子 = i 的二進位字串 q2 q1 q0），依序做 gates，回傳 8 個振幅"""
    if s is None:
        s = [1.0] + [0.0] * 7
    s = s[:]
    for g in gates:
        name = g[0]
        if name in ('cx', 'cz'):
            c, t = 1 << g[1], 1 << g[2]
            if name == 'cx':
                s = [s[i ^ t] if i & c else s[i] for i in range(8)]
            else:
                s = [-s[i] if (i & c and i & t) else s[i] for i in range(8)]
            continue
        m, new = 1 << g[1], s[:]
        for i in range(8):
            if i & m:
                continue
            a, b = s[i], s[i | m]                    # 這一顆是 0、是 1 的兩個振幅
            if name == 'h':
                new[i], new[i | m] = (a + b) * R2, (a - b) * R2
            elif name == 'x':
                new[i], new[i | m] = b, a
            elif name == 'z':
                new[i], new[i | m] = a, -b
            elif name == 'ry':
                c, sn = cos(g[2] / 2), sin(g[2] / 2)
                new[i], new[i | m] = c * a - sn * b, sn * a + c * b
            else:
                raise ValueError('只認得 h、x、z、ry、cx、cz：' + name)
        s = new
    return s


def bloch(s, q):
    """單看第 q 顆的 Bloch 向量 (x, z)"""
    m = 1 << q
    x = sum(2 * s[i] * s[i | m] for i in range(8) if not i & m)
    z = sum((-1 if i & m else 1) * a * a for i, a in enumerate(s))
    return x, z


def fmt(v):
    x, z = v
    return f'(x {x:+.2f}, z {z:+.2f}) 大小 {sqrt(x * x + z * z):.2f}'


def target(prep):
    """ψ 本身的 Bloch 向量（只在 q0 準備，其他位元不動）"""
    return bloch(run(prep), 0)


def same(u, v):
    return abs(u[0] - v[0]) < 1e-9 and abs(u[1] - v[1]) < 1e-9


def p1(s, q):
    """量第 q 顆得到 1 的機率"""
    return sum(a * a for i, a in enumerate(s) if i & (1 << q))


def q2_state(s, q1, q0):
    """Alice 量到 q1 q0 之後，Bob 的 q2 的兩個振幅（已經除以總大小）與這個結果的機率"""
    a = [s[(b << 2) | (q1 << 1) | q0] for b in (0, 1)]
    p = a[0] ** 2 + a[1] ** 2
    return [x / sqrt(p) for x in a], p


def name_of(a, psi):
    """Bob 手上的 a 是 ψ、Zψ、Xψ 還是 XZψ（整體正負號不算）"""
    z = [psi[0], -psi[1]]
    for nm, v in (('ψ', psi), ('Zψ', z), ('Xψ', [psi[1], psi[0]]), ('XZψ', [z[1], z[0]])):
        if abs(abs(a[0] * v[0] + a[1] * v[1]) - 1) < 1e-9:
            return nm
    return '?'


def correct(a, q1, q0):
    """Bob 照紙條修正：q1 = 1 做 X，q0 = 1 做 Z（先 X、再 Z）"""
    if q1:
        a = [a[1], a[0]]
    if q0:
        a = [a[0], -a[1]]
    return a


def classical(prep, k, rng):
    """先量再修：Alice 量 q0、q1，把 2 個位元交給信差，Bob 修正後量 q2。回傳 Alice 各結果次數與 Bob 量到 1 的次數"""
    s = run(prep + ENTANGLE + ALICE)
    alice, bob1 = {'00': 0, '01': 0, '10': 0, '11': 0}, 0
    want = run(prep)
    want = [want[0], want[1]]                       # ψ 的兩個振幅
    for _ in range(k):
        r, pick = rng.random(), None
        for q1 in (0, 1):
            for q0 in (0, 1):
                a, p = q2_state(s, q1, q0)
                if pick is None and r < p:
                    pick = (q1, q0, a)
                r -= p
        q1, q0, a = pick or (1, 1, q2_state(s, 1, 1)[0])
        alice[f'{q1}{q0}'] += 1
        a = correct(a, q1, q0)
        assert abs(abs(a[0] * want[0] + a[1] * want[1]) - 1) < 1e-9   # 修完一定是 ψ
        bob1 += rng.random() < a[1] ** 2
    return alice, bob1


STEPS = [('起點', []), ('①準備ψ', None), ('②糾纏對', ENTANGLE), ('③Alice', ALICE), ('④Bob修正', FIX)]

if __name__ == '__main__':
    rng = random.Random(1118)
    print('一、四種 ψ 各傳一次（延遲量測版）：每一步單看 q0、單看 q2')
    for nm, prep in PSI.items():
        print(f'  ψ = {nm}   ψ 的 Bloch 向量 {fmt(target(prep))}')
        done = []
        for tag, gates in STEPS:
            done += prep if gates is None else gates
            s = run(done)
            print(f'    {tag}：單看 q0 {fmt(bloch(s, 0))}   單看 q2 {fmt(bloch(s, 2))}')
        print(f'    傳完：q2 和 ψ 一樣嗎？ {same(bloch(s, 2), target(prep))}   Bob 量到 1 的機率 {p1(s, 2):.2f}（ψ 本身 {p1(run(prep), 0):.2f}）')
    print('  四種傳完，單看 q0 都一樣嗎？', len({tuple(round(c, 9) for c in bloch(run(p + ENTANGLE + ALICE + FIX), 0)) for p in PSI.values()}) == 1)

    print('二、Alice 量到什麼、Bob 手上是什麼（ψ = √¾|0⟩+½|1⟩，第 ③ 步之後）')
    prep = PSI['√¾|0⟩+½|1⟩']
    psi = run(prep)[:2]
    s = run(prep + ENTANGLE + ALICE)
    for q1 in (0, 1):
        for q0 in (0, 1):
            a, p = q2_state(s, q1, q0)
            fix = {(0, 0): '不用修', (0, 1): 'Z', (1, 0): 'X', (1, 1): '先 X、再 Z'}[(q1, q0)]
            b = correct(a, q1, q0)
            print(f'  q1 q0 = {q1}{q0}  機率 {p:.2f}  Bob 手上 ({a[0]:+.3f}, {a[1]:+.3f}) = {name_of(a, psi):<4}'
                  f'修正：{fix} → ({b[0]:+.3f}, {b[1]:+.3f}) = {name_of(b, psi)}')

    print('三、真的先量再修（古典通訊版），各傳 1000 次（random 種子 1118）')
    for nm, prep in PSI.items():
        alice, bob1 = classical(prep, 1000, rng)
        print(f'  ψ = {nm:<12}Alice 的結果 ' + '  '.join(f'{k}:{v}' for k, v in alice.items())
              + f'   Bob 量到 1：{bob1} 次（理論 {p1(run(prep), 0) * 1000:.0f} 次）')

    print('四、拿掉修正、只修一半：Bob 的 q2（延遲量測版；每格是「對或錯  量到 1 的機率  向量大小」）')
    FIXES = (('不修', []), ('只修 X', FIX[:1]), ('只修 Z', FIX[1:]), ('兩個都修', FIX))
    print(('  ψ              ' + ''.join(f'{tag:<14}' for tag, _ in FIXES)).rstrip())
    for nm, prep in PSI.items():
        cells = []
        for tag, fix in FIXES:
            s = run(prep + ENTANGLE + ALICE + fix)
            ok = '對' if same(bloch(s, 2), target(prep)) else '錯'
            cells.append(f'{ok} {p1(s, 2):.2f} {sqrt(sum(c * c for c in bloch(s, 2))):.2f}')
        print((f'  {nm:<15}' + ''.join(f'{c:<16}' for c in cells)).rstrip())

    # 五、改造區：先預測，再執行。THETA 是 Ry 的角度（0 = |0⟩、pi = |1⟩、pi / 2 = |+⟩），FIX_X、FIX_Z 決定 Bob 修不修
    THETA, FIX_X, FIX_Z = 2 * pi / 3, True, False
    prep = [('ry', 0, THETA)]
    s = run(prep + ENTANGLE + ALICE + (FIX[:1] if FIX_X else []) + (FIX[1:] if FIX_Z else []))
    print('五、改造區')
    print(f'  ψ = Ry({THETA:.3f})|0⟩  修 X：{FIX_X}  修 Z：{FIX_Z}')
    print(f'    ψ 本身 {fmt(target(prep))}   Bob 的 q2 {fmt(bloch(s, 2))}   一樣嗎？ {same(bloch(s, 2), target(prep))}')
    print(f'    Bob 量到 1 的機率 {p1(s, 2):.2f}，ψ 本身 {p1(run(prep), 0):.2f}')
