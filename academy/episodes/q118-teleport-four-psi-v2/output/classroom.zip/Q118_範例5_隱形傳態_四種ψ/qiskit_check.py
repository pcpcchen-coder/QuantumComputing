"""父子科技學院 量子電腦學程 Q118：用本機 Qiskit 重現隱形傳態——四種 ψ（選用，不需要帳號）

安裝（只要一次）：  pip install qiskit
執行：              python qiskit_check.py
延遲量測版：Bob 的修正寫成受控閘（q1 控制 X、q0 控制 Z），和 basic-circuits.html#teleport 相同。
"""
from math import pi

from qiskit import QuantumCircuit
from qiskit.primitives import StatevectorSampler
from qiskit.quantum_info import DensityMatrix, Statevector, partial_trace, state_fidelity

PREP = {'√¾|0⟩+½|1⟩': lambda qc: qc.ry(pi / 3, 0), '|1⟩': lambda qc: qc.x(0),
        '|+⟩': lambda qc: qc.h(0), '|−⟩': lambda qc: (qc.x(0), qc.h(0))}


def teleport(prep, fix_x=True, fix_z=True):
    qc = QuantumCircuit(3)
    prep(qc)            # ① 在 q0 準備 ψ
    qc.h(1)             # ② q1、q2 成為 Bell 態
    qc.cx(1, 2)
    qc.cx(0, 1)         # ③ Alice：CNOT、H
    qc.h(0)
    if fix_x:
        qc.cx(1, 2)     # ④ Bob：q1 = 1 就做 X（延遲量測：改成受控閘）
    if fix_z:
        qc.cz(0, 2)     #    q0 = 1 就做 Z
    return qc


for name, prep in PREP.items():
    one = QuantumCircuit(1)
    prep(one)
    psi = DensityMatrix(Statevector.from_instruction(one))
    row = []
    for tag, fx, fz in (('兩個都修', True, True), ('不修', False, False), ('只修 X', True, False)):
        qc = teleport(prep, fx, fz)
        bob = partial_trace(Statevector.from_instruction(qc), [0, 1])    # 只留下 q2
        row.append(f'{tag} {state_fidelity(bob, psi):.3f}')
    m = teleport(prep).copy()
    m.measure_all()
    counts = StatevectorSampler(seed=2026).run([m], shots=1000).result()[0].data.meas.get_counts()
    bob1 = sum(v for k, v in counts.items() if k[0] == '1')                # 字串最左邊是 q2
    print(f'ψ = {name:<12} Bob 的 q2 和 ψ 的相似度（1 = 完全相同）：' + '，'.join(row) + f'；量 1000 次 Bob 得到 1：{bob1} 次')
print(teleport(PREP['√¾|0⟩+½|1⟩']).draw())
