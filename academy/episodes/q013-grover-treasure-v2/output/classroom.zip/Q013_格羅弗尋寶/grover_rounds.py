"""父子科技學院 量子電腦學程 Q013：格羅弗搜尋——每一輪之後，寶藏的機率是多少？

不用安裝任何套件，只要 Python 3。執行：  python grover_rounds.py
想改抽屜數，就改下面的 N（16、64、4……）；寶藏的號碼改 TREASURE（要在 0 到 N-1 之間）。
算法和學程動畫 operation.html#grover 相同：標記＝寶藏的振幅變號；擴散＝每個振幅 a 變成 2×平均−a。
"""
import math

N = 16          # 抽屜數
TREASURE = 11   # 寶藏在幾號抽屜（0 到 N-1）
ROUNDS = 8      # 要算到第幾輪

assert 0 <= TREASURE < N, '寶藏的號碼要在 0 到 N-1 之間'
amp = [1 / math.sqrt(N)] * N        # 一開始每根柱子一樣高
print(f'N = {N}，估算：√N × 0.785 ≈ {0.785 * math.sqrt(N):.2f}，去掉小數 → {math.floor(0.785 * math.sqrt(N))} 輪；古典平均約要翻 {N / 2:.0f} 次')
print(f'第 0 輪：寶藏的機率 {amp[TREASURE] ** 2:.3f}')
for r in range(1, ROUNDS + 1):
    amp[TREASURE] = -amp[TREASURE]                   # 標記：寶藏翻到下面
    mean = sum(amp) / N
    amp = [2 * mean - a for a in amp]                # 擴散：對平均值翻過去
    print(f'第 {r} 輪：寶藏的機率 {amp[TREASURE] ** 2:.3f}')
