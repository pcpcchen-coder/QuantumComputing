"""父子科技學院 量子電腦學程 Q054：任意旋轉 = 三個旋轉 的小實驗室（只用 Python 標準函式庫）

執行：python zyz_lab.py
一、把常見的單位元閘拆成「繞 z、繞 y、再繞 z」三個旋轉（U = e^(iγ)·Rz(φ)·Ry(θ)·Rz(λ)），
    印出在 operation.html#gates 要「依序按」的三個按鈕：Rz(λ) → Ry(θ) → Rz(φ)，並用矩陣相乘驗證。
二、比較受控 T 和受控 Rz(45°)：單獨一顆只差整體相位，做成受控版本就不一樣。
改造區：在 QUIZ 裡加入你自己的題目（可以把幾個閘相乘）。
"""
import cmath
import math

S2 = 1 / math.sqrt(2)


def mul(A, B):
    return [[sum(A[i][k] * B[k][j] for k in range(2)) for j in range(2)] for i in range(2)]


def RZ(deg):
    t = math.radians(deg)
    return [[cmath.exp(-1j * t / 2), 0], [0, cmath.exp(1j * t / 2)]]


def RY(deg):
    t = math.radians(deg)
    c, s = math.cos(t / 2), math.sin(t / 2)
    return [[c, -s], [s, c]]


def RX(deg):
    t = math.radians(deg)
    c, s = math.cos(t / 2), math.sin(t / 2)
    return [[c, -1j * s], [-1j * s, c]]


GATES = {
    'H': [[S2, S2], [S2, -S2]],
    'X': [[0, 1], [1, 0]],
    'Y': [[0, -1j], [1j, 0]],
    'Z': [[1, 0], [0, -1]],
    'S': [[1, 0], [0, 1j]],
    'S†': [[1, 0], [0, -1j]],
    'T': [[1, 0], [0, cmath.exp(1j * math.pi / 4)]],
    'T†': [[1, 0], [0, cmath.exp(-1j * math.pi / 4)]],
    '√X': [[0.5 + 0.5j, 0.5 - 0.5j], [0.5 - 0.5j, 0.5 + 0.5j]],
}


def norm180(a):
    a = (a + 180) % 360 - 180
    return 180.0 if abs(a + 180) < 1e-6 else a


def same_up_to_phase(A, B):
    """A = e^(iγ)·B？回傳 (是否相同, γ 度數)"""
    k = sum(complex(B[i][j]).conjugate() * complex(A[i][j]) for i in range(2) for j in range(2))
    k /= abs(k)
    ok = all(abs(complex(A[i][j]) - k * complex(B[i][j])) < 1e-9 for i in range(2) for j in range(2))
    return ok, math.degrees(cmath.phase(k)) % 360


def zyz(U):
    """U = e^(iγ)·Rz(φ)·Ry(θ)·Rz(λ)；回傳 (λ, θ, φ, γ)，單位是度。"""
    a, b = complex(U[0][0]), complex(U[0][1])
    c, d = complex(U[1][0]), complex(U[1][1])
    g = cmath.phase(a * d - b * c) / 2
    e = cmath.exp(-1j * g)
    a, c, d = a * e, c * e, d * e
    th = 2 * math.atan2(abs(c), abs(a))
    s = cmath.phase(d) if abs(d) > 1e-9 else 0.0   # (φ + λ) / 2
    t = cmath.phase(c) if abs(c) > 1e-9 else 0.0   # (φ − λ) / 2
    phi, lam = math.degrees(s + t), math.degrees(s - t)
    th = math.degrees(th)
    if th < 1e-6:                      # 中間那一步是 0：兩個 Rz 合成一個
        lam, phi = lam + phi, 0.0
    lam, phi = norm180(lam), norm180(phi)
    ok, gamma = same_up_to_phase(U, mul(RZ(phi), mul(RY(th), RZ(lam))))
    assert ok
    return lam, th, phi, gamma


def fmt(x):
    return f'{x:g}°' if abs(x - round(x)) > 1e-6 else f'{round(x)}°'


def plan(U):
    lam, th, phi, gamma = zyz(U)
    steps = [f'Rz({fmt(lam)})', f'Ry({fmt(th)})', f'Rz({fmt(phi)})']
    keep = [s for s, v in zip(steps, (lam, th, phi)) if abs(v) > 1e-6]
    return lam, th, phi, gamma, ' → '.join(keep) if keep else '（什麼都不用按）'


QUIZ = [   # (題目, 矩陣)；改造區：加你自己的題目
    ('H', GATES['H']), ('S', GATES['S']), ('T', GATES['T']), ('Z', GATES['Z']), ('X', GATES['X']),
    ('Y', GATES['Y']), ('√X', GATES['√X']), ('S†', GATES['S†']), ('T†', GATES['T†']),
    ('Rx(60°)', RX(60)), ('H 接 T', mul(GATES['T'], GATES['H'])), ('H 接 S', mul(GATES['S'], GATES['H'])),
]

if __name__ == '__main__':
    print('一、拆成三個旋轉（按鈕依序按；角度為 0 的那一步省略）')
    print(f'  {"題目":<8}{"λ":>8}{"θ":>8}{"φ":>8}{"整體相位":>10}   依序按')
    for name, U in QUIZ:
        lam, th, phi, gamma, order = plan(U)
        print(f'  {name:<8}{fmt(lam):>8}{fmt(th):>8}{fmt(phi):>8}{fmt(gamma):>10}   {order}')

    print('\n二、受控版本：整體相位會被看見')
    CT = [1, 1, 1, cmath.exp(1j * math.pi / 4)]                       # 受控 T 的對角線
    CR = [1, 1, cmath.exp(-1j * math.pi / 8), cmath.exp(1j * math.pi / 8)]  # 受控 Rz(45°)
    for name, D in (('受控 T', CT), ('受控 Rz(45°)', CR)):
        # 控制位元 |+⟩、目標位元 |1⟩：狀態 (|0⟩|1⟩ + |1⟩|1⟩)/√2，只看 |01⟩ 和 |11⟩ 的振幅
        a01, a11 = D[1] * S2, D[3] * S2
        ang = math.degrees(cmath.phase(a11 / a01))
        print(f'  {name:<12} 控制位元的相對相位 = {ang:.1f}°')
    print('  兩者差 22.5°：單獨一顆時看不見的整體相位，受控時變成控制位元上的相位。')
