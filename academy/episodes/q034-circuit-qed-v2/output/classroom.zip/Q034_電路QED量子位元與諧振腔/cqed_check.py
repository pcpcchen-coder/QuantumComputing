"""父子科技學院 量子電腦學程 Q034：電路 QED 小工具。

不用安裝任何套件，只要 Python 3。執行：  python cqed_check.py
- 一、頻率分得夠開嗎？失諧 Δ = f_q − f_r 和耦合強度 g 比一比（學程簡報 JJ_Microwave_Readout_Talk p28：|Δ| ≫ g 才是色散區域）。
- 二、動畫 index.html#chip 的四個讀取腔頻率與間隔（animations/js/scenes/08_chip.js 第 33 行）。
- 三、動畫右下角 |S21| 頻譜：每個凹陷在虛線左邊或右邊幾個像素（08_chip.js 第 97、100–101 行；core.js Plot.frame 邊界 46／12 px，插圖寬 380 px）。
"""

# 一、頻率分得夠開嗎？（GHz）
def detuning_ratio(f_q, f_r, g):
    """回傳 |Δ| / g；越大越像「只互推頻率、不交換能量」。"""
    return abs(f_q - f_r) / g


print('一、頻率分得夠開嗎？（|Δ| / g）')
RATIO = {}
for f_q, f_r, g in ((5.0, 7.0, 0.1), (6.5, 7.0, 0.1), (6.95, 7.0, 0.1), (7.0, 7.0, 0.1)):
    r = detuning_ratio(f_q, f_r, g)
    RATIO[(f_q, f_r)] = r
    tag = '分得很開（色散區域）' if r >= 10 else ('太接近：會直接交換能量' if r <= 1 else '介於中間')
    print(f'  量子位元 {f_q:.2f} GHz、讀取腔 {f_r:.2f} GHz、g = {1000 * g:.0f} MHz → |Δ|/g = {r:5.1f}　{tag}')

# 二、動畫的四個讀取腔
FR = [6.82, 6.97, 7.11, 7.26]
GAPS = [round(1000 * (b - a)) for a, b in zip(FR, FR[1:])]
print()
print('二、動畫 #chip 的四個讀取腔頻率（GHz）：' + '、'.join(f'{f:.2f}' for f in FR))
print('  相鄰間隔（MHz）：' + '、'.join(str(x) for x in GAPS))

# 三、右下角頻譜：凹陷偏離虛線幾個像素
CHI, KAP = 0.004, 0.006          # 08_chip.js 第 97 行（示意放大）
SHIFT = 6 * CHI                   # 第 101 行：|1⟩ → f_r + 6χ，|0⟩ → f_r − 6χ
W, L, R = 380, 46, 12
PX_PER_GHZ = (W - L - R) / (7.38 - 6.7)
DIP_PX = SHIFT * PX_PER_GHZ
FWHM_PX = (2 * KAP) * PX_PER_GHZ  # 1 − 0.85 / (1 + 4d²)，d = Δf / (2κ)：半深度在 |Δf| = κ
print()
print('三、動畫右下角 |S21| 頻譜')
print(f'  每 GHz 約 {PX_PER_GHZ:.0f} px；凹陷偏離虛線 {1000 * SHIFT:.0f} MHz ≈ {DIP_PX:.1f} px（|0⟩ 在左、|1⟩ 在右）')
print(f'  切換一顆量子位元，凹陷移動 {2 * DIP_PX:.1f} px；凹陷半深度寬約 {FWHM_PX:.1f} px')
print('  動畫的偏移是示意放大；場景讀數寫的典型值是 2χ/2π ≈ 1–5 MHz')
