"""父子科技學院 量子電腦學程 Q111：編譯與控制軟體堆疊——效能競賽（純 Python，不需要安裝任何套件）

執行：  python stack_race.py
一、原生閘驗算：H、CNOT、SWAP、X 換成 Rz、√X、CZ 以後，矩陣真的一樣（只差一個整體相位）。
二、效能競賽：Bell、GHZ、BV 放到「直線 5 顆」與「方格 3×3」兩種晶片，比較 SWAP 數、CZ 數與總時間。
    編譯步驟照 animations/transmon-3d.html 第 12 章的程式改寫（分解 → 映射 → 路由 → 最佳化 → 排程），數字應和動畫面板一樣；
    最後把編譯好的實體電路真的模擬一次，確認結果和原始電路相同。
三、聰明一點的路由：BV 的三個 CNOT 目標相同、可以交換順序，試遍所有順序，找最少 SWAP。
四、七層堆疊說明卡：MY_CIRCUIT 在 MY_CHIP 上，每一層做了什麼。
"""
import cmath
import math
from itertools import permutations, product

# 改造區 1：選一個電路（'bell'、'ghz'、'bv'）
MY_CIRCUIT = 'ghz'
# 改造區 2：選一種晶片（'line' 直線 5 顆、'grid' 方格 3×3）
MY_CHIP = 'line'

# ---------- 晶片與（固定的）校準資料：和動畫第 12 章相同 ----------
CHIPS = {
    'line': ('直線 5 顆', 5, [(0, 1), (1, 2), (2, 3), (3, 4)]),
    'grid': ('方格 3×3', 9, [(0, 1), (1, 2), (3, 4), (4, 5), (6, 7), (7, 8), (0, 3), (3, 6), (1, 4), (4, 7), (2, 5), (5, 8)]),
}
ERR1 = [0.031, 0.024, 0.018, 0.022, 0.045, 0.027, 0.019, 0.035, 0.028]          # 單位元閘錯誤率（%）
ERR2 = {'0-1': 0.62, '1-2': 0.48, '2-3': 0.55, '3-4': 1.10, '3-4g': 0.71, '4-5': 0.52, '6-7': 0.66, '7-8': 0.58,
        '0-3': 0.74, '3-6': 0.61, '1-4': 0.45, '4-7': 0.69, '2-5': 0.57, '5-8': 0.83}   # CZ 錯誤率（%）
DUR = {'SX': 32, 'RZ': 0, 'CZ': 48, 'M': 600}                                    # 每種原生操作花幾 ns
CIRCUITS = {
    'bell': ('Bell', 2, [('H', 0), ('CX', 0, 1), ('M', 0, 1)]),
    'ghz': ('GHZ（3 位元）', 3, [('H', 0), ('CX', 0, 1), ('CX', 0, 2), ('M', 0, 1, 2)]),
    'bv': ('BV（s = 111）', 4, [('X', 3), ('H', 3), ('H', 0), ('H', 1), ('H', 2), ('CX', 0, 3), ('CX', 1, 3), ('CX', 2, 3),
                               ('H', 0), ('H', 1), ('H', 2), ('M', 0, 1, 2)]),
}


def e2(chip, a, b):
    k = f'{min(a, b)}-{max(a, b)}'
    return ERR2['3-4g'] if chip == 'grid' and k == '3-4' else ERR2.get(k, 1)


def compile_circuit(ck, chip, ops=None):
    name, n, ops0 = CIRCUITS[ck]
    ops0 = ops or ops0
    cname, N, edges = CHIPS[chip]
    adj = [[] for _ in range(N)]
    for a, b in edges:
        adj[a].append(b)
        adj[b].append(a)
    dist = []
    for s in range(N):
        d = [99] * N
        d[s], q = 0, [s]
        while q:
            u = q.pop(0)
            for v in adj[u]:
                if d[v] == 99:
                    d[v] = d[u] + 1
                    q.append(v)
        dist.append(d)

    def next_hop(s, t):
        return next(v for v in adj[s] if dist[v][t] == dist[s][t] - 1)

    # ① 分解：CX → H·CZ·H，X → √X·√X
    st1 = []
    for o in ops0:
        if o[0] == 'CX':
            st1 += [('H', o[2]), ('CZ', o[1], o[2]), ('H', o[2])]
        elif o[0] == 'X':
            st1 += [('SX', o[1]), ('SX', o[1])]
        else:
            st1.append(o)
    # ② 映射：試遍所有配置，成本 = SWAP 需求 × 10 + 用到的連線與位元的錯誤率（挑最小的）
    pairs = [o[1:] for o in ops0 if o[0] == 'CX']
    best = None
    for L in permutations(range(N), n):
        cost = sum((dist[L[a]][L[b]] - 1) * 10 + (e2(chip, L[a], L[b]) if dist[L[a]][L[b]] == 1 else 1.5) for a, b in pairs)
        cost += sum(ERR1[p] * 2 for p in L)
        if best is None or cost < best[0] - 1e-9:
            best = (cost, list(L))
    L0 = best[1]
    # ③ 路由：CX 兩端不相鄰，就把一端沿最短路徑搬一步（插一個 SWAP），選「之後所有 CX 距離總和」較小的那一端
    L, inv = L0[:], {p: l for l, p in enumerate(L0)}
    routed, n_swap, cx_i = [], 0, 0
    for o in ops0:
        if o[0] == 'CX':
            a, b = o[1], o[2]
            rest = pairs[cx_i:]
            cx_i += 1
            while dist[L[a]][L[b]] > 1:
                cands = []
                for m, nx in ((a, next_hop(L[a], L[b])), (b, next_hop(L[b], L[a]))):
                    T2 = L[:]
                    if nx in inv:
                        T2[inv[nx]] = L[m]
                    T2[m] = nx
                    cands.append((sum(dist[T2[u]][T2[v]] for u, v in rest), m, nx))
                c, m, nx = min(cands, key=lambda x: x[0])
                pa, other = L[m], inv.get(nx)
                routed.append(('SWAP', pa, nx))
                n_swap += 1
                L[m], inv[nx] = nx, m
                if other is not None:
                    L[other], inv[pa] = pa, other
                else:
                    del inv[pa]
            routed.append(('CX', L[a], L[b]))
        else:
            routed.append((o[0],) + tuple(L[l] for l in o[1:]))
    st3 = []                                              # (閘, 實體位元…, 是否來自 SWAP)

    def cx(c, t, sw):
        st3.extend([('H', (t,), sw), ('CZ', (c, t), sw), ('H', (t,), sw)])
    for o in routed:
        if o[0] == 'SWAP':
            cx(o[1], o[2], 1), cx(o[2], o[1], 1), cx(o[1], o[2], 1)
        elif o[0] == 'CX':
            cx(o[1], o[2], 0)
        elif o[0] == 'X':
            st3 += [('SX', o[1:], 0), ('SX', o[1:], 0)]
        else:
            st3.append((o[0], o[1:], 0))
    # ④ 最佳化：相鄰 H·H 抵消 → H 展開成 Rz(π/2)·√X·Rz(π/2) → 合併相鄰 Rz、刪掉角度 0 的 Rz
    opsx, n_hh, changed = [list(o) for o in st3], 0, True
    while changed:
        changed = False
        for i in range(len(opsx)):
            if opsx[i][0] != 'H':
                continue
            q = opsx[i][1][0]
            for j in range(i + 1, len(opsx)):
                if q not in opsx[j][1]:
                    continue
                if opsx[j][0] == 'H':
                    del opsx[j], opsx[i]
                    changed, n_hh = True, n_hh + 1
                break
            if changed:
                break
    exp = []
    for g, p, sw in opsx:
        if g == 'H':
            exp += [['RZ', p, sw, math.pi / 2], ['SX', p, sw], ['RZ', p, sw, math.pi / 2]]
        else:
            exp.append([g, p, sw])
    st4, last_rz = [], {}
    for o in exp:
        if o[0] == 'RZ':
            k = last_rz.get(o[1][0])
            if k is not None:
                st4[k][3] = (st4[k][3] + o[3]) % (2 * math.pi)
                continue
            last_rz[o[1][0]] = len(st4)
            st4.append(o[:])
            continue
        for q in o[1]:
            last_rz.pop(q, None)
        st4.append(o)
    st4 = [o for o in st4 if not (o[0] == 'RZ' and abs(math.sin(o[3] / 2)) < 1e-9)]
    # ⑤ 排程：每個閘盡早開始；同時進行的 CZ 不可以共用或相鄰（避免頻率碰撞）
    free, czs, sched = [0] * N, [], []
    for o in st4:
        g, p = o[0], o[1]
        t, d = max(free[q] for q in p), DUR[g]
        if g == 'CZ':
            ok = False
            while not ok:
                ok = True
                for zp, zt, zd in czs:
                    near = any(a == b or b in adj[a] for a in p for b in zp)
                    if near and t < zt + zd and zt < t + d:
                        t, ok = zt + zd, False
            czs.append((p, t, d))
        sched.append((o, t, d))
        for q in p:
            free[q] = t + d
    total = max(t + d for o, t, d in sched)
    return {'name': name, 'n': n, 'chip': cname, 'N': N, 'L0': L0, 'Lend': L, 'n_swap': n_swap, 'n_hh': n_hh,
            'ops0': ops0, 'st1': st1, 'cz_raw': sum(o[0] == 'CZ' for o in st1),
            'cz_routed': sum(o[0] == 'CZ' for o in st3), 'sx_routed': sum(o[0] in ('H', 'SX') for o in st3),
            'sx': sum(o[0] == 'SX' for o in st4), 'rz': sum(o[0] == 'RZ' for o in st4), 'cz': sum(o[0] == 'CZ' for o in st4),
            'st4': st4, 'total': total, 'gates_end': max(t + d for o, t, d in sched if o[0] != 'M'),
            'non_adj': sum(1 for o in st1 if o[0] == 'CZ' and dist[L0[o[1]]][L0[o[2]]] > 1)}


# ---------- 狀態向量模擬（驗算用） ----------
S2 = 2 ** -0.5
GATES1 = {'H': [[S2, S2], [S2, -S2]], 'X': [[0, 1], [1, 0]],
          'SX': [[(1 + 1j) / 2, (1 - 1j) / 2], [(1 - 1j) / 2, (1 + 1j) / 2]]}


def rz(th):
    return [[cmath.exp(-0.5j * th), 0], [0, cmath.exp(0.5j * th)]]


def apply1(psi, n, q, U):
    b = 1 << (n - 1 - q)
    for i in range(len(psi)):
        if not i & b:
            x, y = psi[i], psi[i | b]
            psi[i], psi[i | b] = U[0][0] * x + U[0][1] * y, U[1][0] * x + U[1][1] * y


def apply2(psi, n, g, c, t):
    bc, bt = 1 << (n - 1 - c), 1 << (n - 1 - t)
    for i in range(len(psi)):
        if g == 'CZ' and i & bc and i & bt:
            psi[i] = -psi[i]
        if g == 'CX' and i & bc and not i & bt:
            psi[i], psi[i | bt] = psi[i | bt], psi[i]


def probs(psi, n, qubits):
    """量 qubits（依序）得到每個位元串的機率"""
    out = {}
    for i, a in enumerate(psi):
        if abs(a) > 1e-12:
            k = ''.join(str((i >> (n - 1 - q)) & 1) for q in qubits)
            out[k] = out.get(k, 0) + abs(a) ** 2
    return {k: round(v, 6) for k, v in sorted(out.items()) if round(v, 6) > 0}


def ideal(ops, n):
    psi = [0j] * (1 << n)
    psi[0] = 1
    for o in ops:
        if o[0] in GATES1:
            apply1(psi, n, o[1], GATES1[o[0]])
        elif o[0] == 'CX':
            apply2(psi, n, 'CX', o[1], o[2])
    return probs(psi, n, [o for o in ops if o[0] == 'M'][0][1:])


def physical(r):
    """模擬編譯好的實體電路（只用 Rz、√X、CZ），量測位置照路由後的配置"""
    N = r['N']
    psi = [0j] * (1 << N)
    psi[0] = 1
    for o in r['st4']:
        if o[0] == 'RZ':
            apply1(psi, N, o[1][0], rz(o[3]))
        elif o[0] == 'SX':
            apply1(psi, N, o[1][0], GATES1['SX'])
        elif o[0] == 'CZ':
            apply2(psi, N, 'CZ', *o[1])
    m = [o for o in r['ops0'] if o[0] == 'M'][0][1:]
    return probs(psi, N, [r['Lend'][l] for l in m])


# ---------- 一、原生閘驗算 ----------
def mat(ops, n):
    """依序做 ops 的 2^n × 2^n 矩陣（每一欄 = 某個基底態送進去的結果）"""
    cols = []
    for k in range(1 << n):
        psi = [0j] * (1 << n)
        psi[k] = 1
        for o in ops:
            if o[0] == 'RZ':
                apply1(psi, n, o[1], rz(o[2]))
            elif o[0] in GATES1:
                apply1(psi, n, o[1], GATES1[o[0]])
            else:
                apply2(psi, n, o[0], o[1], o[2])
        cols.append(psi)
    return cols


def same_up_to_phase(A, B):
    ph = None
    for ca, cb in zip(A, B):
        for x, y in zip(ca, cb):
            if abs(y) > 1e-9:
                ph = ph or x / y
                if abs(x - ph * y) > 1e-9:
                    return False
            elif abs(x) > 1e-9:
                return False
    return abs(abs(ph) - 1) < 1e-9


def fmt_map(L):
    return '、'.join(f'q{l}→Q{p}' for l, p in enumerate(L))


if __name__ == '__main__':
    print('一、原生閘驗算（只差一個整體相位就算相同）')
    hp = math.pi / 2
    checks = [
        ('H = Rz(π/2)·√X·Rz(π/2)', mat([('H', 0)], 1), mat([('RZ', 0, hp), ('SX', 0), ('RZ', 0, hp)], 1)),
        ('X = √X·√X', mat([('X', 0)], 1), mat([('SX', 0), ('SX', 0)], 1)),
        ('CNOT = H·CZ·H（H 做在目標）', mat([('CX', 0, 1)], 2), mat([('H', 1), ('CZ', 0, 1), ('H', 1)], 2)),
        ('SWAP = 3 個 CNOT', mat([('CX', 0, 1), ('CX', 1, 0), ('CX', 0, 1)], 2),
         [[1, 0, 0, 0], [0, 0, 1, 0], [0, 1, 0, 0], [0, 0, 0, 1]]),
    ]
    for name, A, B in checks:
        print(f'  {name}：{"相同 ✓" if same_up_to_phase(A, B) else "不同 ✗"}')
    print('二、效能競賽（總時間含讀取 600 ns；√X 32 ns、Rz 0 ns、CZ 48 ns）')
    for ck, chip in product(CIRCUITS, CHIPS):
        r = compile_circuit(ck, chip)
        ok = physical(r) == ideal(r['ops0'], r['n'])
        print(f'  {r["name"]} @ {r["chip"]}：SWAP {r["n_swap"]} 個，CZ {r["cz_raw"]} → {r["cz"]} 個，'
              f'√X {r["sx"]} 個，總時間 {r["total"]} ns，結果和原始電路{"相同 ✓" if ok else "不同 ✗"}')
    print('三、聰明一點的路由：BV 在直線晶片上，三個 CNOT 換順序')
    name, n, ops0 = CIRCUITS['bv']
    cxs = [o for o in ops0 if o[0] == 'CX']
    i0 = ops0.index(cxs[0])
    for order in permutations(cxs):
        ops = ops0[:i0] + list(order) + ops0[i0 + 3:]
        r = compile_circuit('bv', 'line', ops)
        ok = physical(r) == ideal(ops, n)
        tag = ' → '.join(f'CNOT({o[1]}→{o[2]})' for o in order)
        print(f'  {tag}：SWAP {r["n_swap"]} 個，CZ {r["cz"]} 個，總時間 {r["total"]} ns，結果{"相同 ✓" if ok else "不同 ✗"}')
    r = compile_circuit(MY_CIRCUIT, MY_CHIP)
    print(f'四、七層堆疊說明卡：{r["name"]} @ {r["chip"]}（MY_CIRCUIT、MY_CHIP）')
    gates = ' '.join(o[0] + '(' + ','.join(map(str, o[1:])) + ')' for o in r['ops0'])
    print(f'  ① 應用層：{gates}')
    print(f'  ② 電路 IR：{len(r["ops0"])} 個邏輯操作，還沒指定晶片')
    print(f'  ③ 編譯器：分解成 {r["cz_raw"]} 個 CZ；映射 {fmt_map(r["L0"])}；插 {r["n_swap"]} 個 SWAP；'
          f'抵消 {r["n_hh"]} 對 H·H；剩 √X {r["sx"]}、Rz {r["rz"]}、CZ {r["cz"]}')
    print(f'  ④ 脈衝層：√X 變成 32 ns 的微波脈衝、CZ 變成 48 ns 的磁通脈衝、Rz 只改相位（0 ns）；'
          f'閘在 {r["gates_end"]} ns 做完，讀取到 {r["total"]} ns')
    print('  ⑤ 即時控制：控制電子照時間軸同步播放、讀取；動態電路要在幾百 ns 內判斷並回饋')
    print('  ⑥ 類比硬體：數位波形 → 混頻 → 冷凍機 → 晶片 → 放大 → 數位化')
    print(f'  ⑦ 結果處理：理想機率 {ideal(r["ops0"], r["n"])}；實際要重跑數千次，再修正讀取誤差')
