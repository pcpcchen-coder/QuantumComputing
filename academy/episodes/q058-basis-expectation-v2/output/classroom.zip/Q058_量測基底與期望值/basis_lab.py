"""父子科技學院 量子電腦學程 Q058：量測基底與期望值 的小模擬器（只用 Python 標準函式庫）

執行：python basis_lab.py            → 印出每個狀態在 Z、X、Y 基底的理論期望值與一次模擬（1000 shots）
      python basis_lab.py 盲測        → 電腦偷偷出題，你選基底、看統計、猜答案
規則和硬體一樣：最後一定「量 Z」。
  - 量 Z：直接量
  - 量 X：先做 H 再量 Z
  - 量 Y：先做 S†，再做 H，再量 Z
期望值 = P(0) − P(1) = (0 的次數 − 1 的次數) / shots
改造區：在 STATES 加你自己的狀態（θ 是從北極倒下的角度，φ 是繞赤道轉的相位，單位都是度）。
"""
import cmath
import math
import random
import sys

STATES = {   # 名稱: (θ, φ)
    '|0⟩ 零態': (0, 0),
    '|1⟩ 一態': (180, 0),
    '|+⟩ 加態': (90, 0),
    '|−⟩ 減態': (90, 180),
    '|+i⟩ 虛數方向': (90, 90),
    '倒下 60°': (60, 0),
    '動畫場景 7 的 θ=90°': (90, math.degrees(0.4)),   # operation.html#readout 的準備狀態相位固定 0.4 rad
}

R2 = 1 / math.sqrt(2)
H = ((R2, R2), (R2, -R2))
SDG = ((1, 0), (0, -1j))


def prepare(theta, phi):
    t, p = math.radians(theta), math.radians(phi)
    return [complex(math.cos(t / 2)), cmath.exp(1j * p) * math.sin(t / 2)]


def apply(g, v):
    return [g[0][0] * v[0] + g[0][1] * v[1], g[1][0] * v[0] + g[1][1] * v[1]]


def rotate_for(basis, v):
    """量測前的基底旋轉：Z 不動、X 先 H、Y 先 S† 再 H。"""
    if basis == 'X':
        v = apply(H, v)
    elif basis == 'Y':
        v = apply(H, apply(SDG, v))
    return v


def p0(basis, v):
    return abs(rotate_for(basis, v)[0]) ** 2


def run(basis, v, shots=1000, rng=random):
    n0 = sum(rng.random() < p0(basis, v) for _ in range(shots))
    return n0, shots - n0


def expectation(n0, n1):
    return (n0 - n1) / (n0 + n1)


def table(seed=58):
    rng = random.Random(seed)
    print('狀態｜基底｜理論 P(0)｜理論期望值｜模擬 1000 shots（0 / 1）｜模擬期望值')
    for name, (th, ph) in STATES.items():
        v = prepare(th, ph)
        for b in 'ZXY':
            q = p0(b, v)
            n0, n1 = run(b, v, 1000, rng)
            print(f'{name}｜{b}｜{q:.3f}｜{round(2 * q - 1, 6) + 0.0:+.3f}｜{n0} / {n1}｜{expectation(n0, n1):+.3f}')
    print('\n提醒：模擬期望值每次會差一點點；shots 越多越接近理論值（下一堂會算要多少 shots）。')


def blind():
    names = ['|0⟩ 零態', '|1⟩ 一態', '|+⟩ 加態', '|−⟩ 減態']
    secret = random.choice(names)
    v = prepare(*STATES[secret])
    print('電腦偷偷從 ' + '、'.join(names) + ' 選了一個。每次輸入 Z 或 X（可以重複），輸入 猜 結束。')
    while True:
        b = input('基底（Z／X／猜）：').strip().upper()
        if b in ('Z', 'X'):
            n0, n1 = run(b, v, 100)
            print(f'  量 {b}（{"直接量" if b == "Z" else "先 H 再量 Z"}）100 次：0 → {n0}，1 → {n1}，期望值 {expectation(n0, n1):+.2f}')
        elif b in ('猜', 'G'):
            g = input('你猜是哪一個（0／1／+／−）：').strip().replace('-', '−')
            ok = {'0': names[0], '1': names[1], '+': names[2], '−': names[3]}.get(g) == secret
            print('答對了！' if ok else '答錯了，', '答案是', secret)
            return


if __name__ == '__main__':
    blind() if len(sys.argv) > 1 and sys.argv[1] in ('盲測', 'blind') else table()
