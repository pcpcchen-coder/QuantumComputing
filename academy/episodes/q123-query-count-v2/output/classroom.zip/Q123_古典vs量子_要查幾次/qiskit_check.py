"""父子科技學院 量子電腦學程 Q123：用本機 Qiskit 驗證三格「量子只問 1 次（或 2 輪）」（選用，不需要帳號）

安裝（只要一次）：  pip install qiskit
執行：              python qiskit_check.py
三個線路都是 3 顆輸入位元；黑盒子用相位翻轉閘寫成「把答案變號」的版本（和 query_count.py 一樣）。
"""
from qiskit import QuantumCircuit
from qiskit.primitives import StatevectorSampler
from qiskit.quantum_info import Statevector


def dj(balanced):
    qc = QuantumCircuit(3)
    qc.h([0, 1, 2])
    if balanced:
        qc.z([0, 1, 2])          # 平衡：f(x) = 三個位元的奇偶（只問 1 次）
    qc.h([0, 1, 2])
    return qc


def bv(secret='101'):
    qc = QuantumCircuit(3)
    qc.h([0, 1, 2])
    for q in range(3):
        if secret[2 - q] == '1':
            qc.z(q)              # 黑盒子：s·x 是奇數的項變號（只問 1 次）
    qc.h([0, 1, 2])
    return qc


def ccz(qc):
    qc.h(2)
    qc.ccx(0, 1, 2)
    qc.h(2)


def grover(answer='101', rounds=2):
    qc = QuantumCircuit(3)
    qc.h([0, 1, 2])
    zeros = [q for q in range(3) if answer[2 - q] == '0']
    for _ in range(rounds):
        if zeros:
            qc.x(zeros)
        ccz(qc)                  # 標記：每一輪問 1 次
        if zeros:
            qc.x(zeros)
        qc.h([0, 1, 2])
        qc.x([0, 1, 2])
        ccz(qc)
        qc.x([0, 1, 2])
        qc.h([0, 1, 2])
    return qc


sampler = StatevectorSampler(seed=2026)
for name, qc, key in (('Deutsch–Jozsa 常數', dj(False), '000'), ('Deutsch–Jozsa 平衡', dj(True), '000'),
                      ('BV 密碼 101', bv(), '101'), ('Grover 答案 101、2 輪', grover(), '101')):
    p = Statevector(qc).probabilities_dict().get(key, 0)
    m = qc.copy()
    m.measure_all()
    counts = sampler.run([m], shots=1000).result()[0].data.meas.get_counts()
    print(f'{name}：{key} 的理論機率 {p:.1%}　量 1000 次，{key} 出現 {counts.get(key, 0)} 次')
