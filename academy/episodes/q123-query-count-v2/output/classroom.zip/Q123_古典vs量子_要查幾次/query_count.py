"""父子科技學院 量子電腦學程 Q123：古典 vs 量子——要查幾次？（純 Python，不需安裝任何套件）

執行：  python query_count.py
它印出：
  一、Deutsch（1 位元）：四種黑盒子，古典問 2 次，量子模擬只問 1 次
  二、Deutsch–Jozsa（3 位元）：72 台機器全部用量子模擬跑一次；古典最壞要問幾次；允許出錯時隨便抽幾個問
  三、Bernstein–Vazirani（3 位元）：8 種密碼，古典問 100、010、001 三次；量子只問 1 次
  四、Grover：古典一個一個試平均幾次 vs 量子最佳輪數與成功率
  五、查詢次數比較表（位元數變多時）
  六、改造區：換成自己的位元數，先預測，再執行
量子部分用最簡單的狀態向量模擬（沒有亂數、沒有雜訊）。位元字串最左邊是最高位。
"""
from itertools import combinations
from math import asin, comb, pi, sin, sqrt


def hadamard_all(v, n):
    """對 n 顆位元都做哈達瑪閘"""
    v = v[:]
    for q in range(n):
        bit = 1 << q
        for i in range(2 ** n):
            if not i & bit:
                a, b = v[i], v[i | bit]
                v[i], v[i | bit] = (a + b) / sqrt(2), (a - b) / sqrt(2)
    return v


def one_query(f, n):
    """量子只問一次：H → 黑盒子把 f(x) = 1 的振幅變號（相位回踢）→ H，回傳每個結果的機率"""
    v = [0.0] * 2 ** n
    v[0] = 1.0
    v = hadamard_all(v, n)
    v = [-a if f(x) else a for x, a in enumerate(v)]   # 這一行就是唯一的一次查詢
    v = hadamard_all(v, n)
    return [a * a for a in v]


def bits(x, n):
    return format(x, f'0{n}b')


if __name__ == '__main__':
    print('一、Deutsch（1 位元，四種黑盒子）')
    for name, f in (('f(x) = 0', lambda x: 0), ('f(x) = 1', lambda x: 1), ('f(x) = x', lambda x: x), ('f(x) = 1 − x', lambda x: 1 - x)):
        classical = '常數' if f(0) == f(1) else '平衡'
        p0 = one_query(f, 1)[0]
        quantum = '常數' if p0 > 0.999 else '平衡'
        print(f'  {name:<12} 古典問 f(0)、f(1) 共 2 次 → {classical}；量子問 1 次，量到 0 的機率 {p0:.0%} → {quantum}')

    n = 3
    N = 2 ** n
    print(f'二、Deutsch–Jozsa（{n} 位元，{N} 個輸入）')
    machines = [('常數', frozenset()), ('常數', frozenset(range(N)))]
    machines += [('平衡', frozenset(c)) for c in combinations(range(N), N // 2)]
    right = 0
    for kind, ones in machines:
        p0 = one_query(lambda x: x in ones, n)[0]
        right += (p0 > 0.999) == (kind == '常數')
    print(f'  常數 2 台、平衡 {len(machines) - 2} 台，共 {len(machines)} 台；量子各問 1 次，判斷正確 {right} 台')
    worst = 0
    for k in range(1, N + 1):
        # 前 k 個輸入都回答 0，還有沒有「平衡」的機器符合？有的話就還不能下結論
        if any(kind == '平衡' and not (ones & set(range(k))) for kind, ones in machines):
            worst = k
    print(f'  古典：前 {worst} 個都回答 0，還可能是平衡的 → 最壞要問 {worst + 1} 次（= 2ⁿ⁻¹ + 1）')
    print('  允許出錯：隨便抽 k 個不同的輸入問，平衡機器卻剛好全部同答案（被誤判成常數）的機率')
    print('  ' + '  '.join(f'k = {k}：{2 * comb(N // 2, k) / comb(N, k):.1%}' for k in (2, 3, 4)))

    print(f'三、Bernstein–Vazirani（{n} 位元密碼）')
    ok_c = ok_q = 0
    for s in range(N):
        f = lambda x, s=s: bin(x & s).count('1') % 2     # 黑盒子只回答 s·x 的奇偶
        guess = ''.join(str(f(1 << (n - 1 - i))) for i in range(n))   # 古典依序問 100、010、001
        ok_c += guess == bits(s, n)
        p = one_query(f, n)
        ok_q += p[s] > 0.999
    print(f'  8 種密碼：古典各問 {n} 次全部猜中 {ok_c} 種；量子各問 1 次、量到密碼的機率 100% 的有 {ok_q} 種')

    print('四、Grover（找一個答案）')
    for n2 in (2, 3, 4, 6, 10):
        N2 = 2 ** n2
        th = asin(1 / sqrt(N2))
        r = max(1, round(pi / (4 * th) - 0.5))
        p = sin((2 * r + 1) * th) ** 2
        avg = sum(range(1, N2 + 1)) / N2               # 答案在每個位置機會相同，一個一個試
        print(f'  {n2:>2} 位元（N = {N2:>5,}）：古典平均 {avg:,.1f} 次（約 N/2 = {N2 // 2:,}）；'
              f'量子最佳 {r:>2} 輪，成功率 {p:.1%}，平均要跑 {1 / p:.2f} 回')

    print('五、查詢次數比較表')
    print('  位元數 | Deutsch–Jozsa 古典最壞 | BV 古典 | Grover 古典平均 | 量子（DJ、BV／Grover）')
    for n3 in (2, 3, 10, 20):
        N3 = 2 ** n3
        r = max(1, round(pi / (4 * asin(1 / sqrt(N3))) - 0.5))
        print(f'  {n3:>6} | {2 ** (n3 - 1) + 1:>22,} | {n3:>7} | {(N3 + 1) / 2:>15,.1f} | 1、1／{r:,} 輪')

    # 六、改造區：換成自己的位元數，先預測，再執行
    MY_BITS = 10
    N4 = 2 ** MY_BITS
    r4 = max(1, round(pi / (4 * asin(1 / sqrt(N4))) - 0.5))
    print('六、改造區')
    print(f'  {MY_BITS} 位元：Deutsch–Jozsa 古典最壞 {2 ** (MY_BITS - 1) + 1:,} 次 vs 量子 1 次；'
          f'BV 古典 {MY_BITS} 次 vs 量子 1 次；Grover 古典平均 {(N4 + 1) / 2:,.1f} 次 vs 量子 {r4:,} 輪')
