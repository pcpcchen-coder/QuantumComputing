"""父子科技學院 量子電腦學程 Q038：熱光子計算小工具。

不用安裝任何套件，只要 Python 3。執行：  python thermal_photons.py
- 一、熱光子數 n_th = 1 / (e^(hf/kT) − 1)（玻色–愛因斯坦分布；學程簡報 JJ_Microwave_Readout_Talk p33 與動畫 index.html#fridge 的讀數用同一個式子）。
- 二、孩子的算法：只算從室溫灌下來的熱雜訊，每經過一個 −20 dB 衰減器就除以 100（簡報 p32：4 K、100 mK、10 mK 各 −20 dB）。
- 三、分貝換算：每 −10 dB 變成十分之一；+20 dB 是 100 倍、+40 dB 是 10000 倍。
- 四、加分題：把衰減器自己放出的熱雜訊也算進去（簡報 p33：「衰減器把訊號與上游雜訊一起壓低，但自身在冷端只貢獻該溫度的熱雜訊」）。
  這裡用常見的衰減器模型：n_out = n_in / A + (1 − 1/A) × n_th(衰減器所在溫度)，A 是衰減倍數（−20 dB → A = 100）。
"""
import math

H = 6.62607015e-34   # 普朗克常數（J·s）
KB = 1.380649e-23    # 波茲曼常數（J/K）
F = 7e9              # 讀取微波 7 GHz（簡報 p33）


def n_th(T, f=F):
    """溫度 T（K）下、頻率 f 的平均熱光子數。"""
    return 1 / math.expm1(H * f / (KB * T))


def db_to_ratio(db):
    """分貝 → 功率倍數。"""
    return 10 ** (db / 10)


print('一、7 GHz 的熱光子數')
NTH = {}
for name, T in (('300 K 室溫', 300), ('4 K', 4), ('100 mK', 0.1), ('10 mK', 0.01)):
    NTH[T] = n_th(T)
    print(f'  {name:8s}：{NTH[T]:.3g} 個')

print()
print('二、孩子的算法：從 890 個開始，每個 −20 dB 衰減器除以 100')
SIMPLE = [890.0]
for k in range(3):
    SIMPLE.append(SIMPLE[-1] / 100)
    print(f'  經過第 {k + 1} 個衰減器：{SIMPLE[-1]:g} 個')
print(f'  只放兩個衰減器：{SIMPLE[2]:g} 個，是千分之一的 {SIMPLE[2] / 0.001:.0f} 倍')

print()
print('三、分貝換算')
DB = {}
for db in (-10, -20, -40, -60, 20, 40):
    DB[db] = db_to_ratio(db)
    print(f'  {db:+d} dB → × {DB[db]:g}')
SIG = [('AWG（室溫）', -50), ('經過三個 −20 dB 衰減器', -50 - 60)]
for name, dbm in SIG:
    print(f'  {name}：{dbm} dBm')

print()
print('四、加分題：衰減器自己也會放出所在溫層的熱雜訊')
STAGES = [(4, 20), (0.1, 20), (0.01, 20)]
n = n_th(300)
FULL = [n]
for T, att in STAGES:
    A = db_to_ratio(att)
    n = n / A + (1 - 1 / A) * n_th(T)
    FULL.append(n)
    print(f'  經過 {T:g} K 的 −{att} dB 衰減器：{n:.3g} 個')
A60 = db_to_ratio(60)
ALL_ROOM = n_th(300) / A60 + (1 - 1 / A60) * n_th(300)
print(f'  對照：60 dB 全部放在 300 K：{ALL_ROOM:.4g} 個（一點都沒有變少）')
