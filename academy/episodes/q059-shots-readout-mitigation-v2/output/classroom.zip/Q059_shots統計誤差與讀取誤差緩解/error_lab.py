"""父子科技學院 量子電腦學程 Q059：shots、統計誤差與讀取誤差緩解 的小模擬器（只用 Python 標準函式庫）

執行：python error_lab.py               → 加態跑 100、1000、10000 shots，印出原始值、誤差與緩解後的值
      python error_lab.py 次數 0.5 0.01  → 算出機率 0.5 時要達到 ±0.01 需要幾個 shots
      python error_lab.py 偵探            → 電腦偷偷決定有沒有讀取錯誤，你用 shots 與校準找出真相
公式：
  統計誤差 σ = √(P(1−P)/N)            （shots 加 4 倍，誤差才減半）
  需要的 shots N = P(1−P) ÷ 誤差²
  讀取誤差緩解（單一位元）：P_修正(1) = (P_量到(1) − P(1|0)) ÷ (P(1|1) − P(1|0))
改造區：改 P1_GIVEN_0、P0_GIVEN_1（讀取錯誤率）或 P_TRUE（理想的 P(1)）。
"""
import math
import random
import sys

P_TRUE = 0.5        # 理想的 P(1)：加態 |+⟩ 是 0.5
P1_GIVEN_0 = 0.02   # 準備 0 卻讀成 1 的機率
P0_GIVEN_1 = 0.08   # 準備 1 卻讀成 0 的機率（讀取途中 T₁ 衰減，通常比較大）


def read(bit, e10, e01, rng):
    """讀取：真正的位元是 bit，儀器偶爾讀錯。"""
    if bit == 0:
        return 1 if rng.random() < e10 else 0
    return 0 if rng.random() < e01 else 1


def run(p_true, shots, e10, e01, rng):
    """跑 shots 次：每次先依 p_true 決定位元（量子的隨機），再經過會讀錯的儀器。回傳讀到 1 的比例。"""
    ones = sum(read(1 if rng.random() < p_true else 0, e10, e01, rng) for _ in range(shots))
    return ones / shots


def sigma(p, n):
    return math.sqrt(p * (1 - p) / n)


def shots_needed(p, err):
    return math.ceil(round(p * (1 - p) / err ** 2, 9))


def calibrate(shots, e10, e01, rng):
    """校準線路：準備 0 量 shots 次、準備 1（先做 X）量 shots 次。回傳 P(1|0)、P(1|1)。"""
    return run(0.0, shots, e10, e01, rng), run(1.0, shots, e10, e01, rng)


def mitigate(p_meas, p10, p11):
    return min(1.0, max(0.0, (p_meas - p10) / (p11 - p10)))


def table(seed=59):
    rng = random.Random(seed)
    print(f'理想 P(1) = {P_TRUE}；讀取錯誤：P(1|0) = {P1_GIVEN_0}，P(0|1) = {P0_GIVEN_1}')
    p10, p11 = calibrate(10000, P1_GIVEN_0, P0_GIVEN_1, rng)
    print(f'校準（各 10000 shots）：P(1|0) = {p10:.4f}，P(1|1) = {p11:.4f}')
    print('shots｜原始 P(1) ± σ｜偏離理想幾個 σ｜緩解後 P(1)｜緩解後 σ')
    for n in (100, 1000, 10000):
        p = run(P_TRUE, n, P1_GIVEN_0, P0_GIVEN_1, rng)
        s = sigma(p, n)
        m = mitigate(p, p10, p11)
        print(f'{n:>6}｜{p:.4f} ± {s:.4f}｜{abs(p - P_TRUE) / s:4.1f}｜{m:.4f}｜{s / (p11 - p10):.4f}')
    print('\n看最後兩欄：shots 越多誤差越小，但原始值的偏差不會消失；緩解把它修回來，誤差稍微變大。')


def detective():
    rng = random.Random()
    cases = [('沒有讀取錯誤', 0.0, 0.0), ('讀取錯誤 2%／8%', 0.02, 0.08), ('讀取錯誤 5%／15%', 0.05, 0.15)]
    name, e10, e01 = rng.choice(cases)
    print('電腦準備了加態（理想 P(1) = 0.5），也偷偷決定了讀取錯誤（' + '、'.join(c[0] for c in cases) + ' 其中之一）。')
    print('輸入 shots 數字跑實驗；輸入 校準 跑校準線路；輸入 猜 結束。')
    while True:
        cmd = input('shots／校準／猜：').strip()
        if cmd.isdigit() and int(cmd) > 0:
            n = int(cmd); p = run(0.5, n, e10, e01, rng); s = sigma(p, n)
            print(f'  {n} shots：P(1) = {p:.4f} ± {s:.4f}，偏離 0.5 是 {abs(p - 0.5) / s:.1f} 個 σ')
        elif cmd == '校準':
            p10, p11 = calibrate(5000, e10, e01, rng)
            print(f'  校準（各 5000 shots）：P(1|0) = {p10:.4f}，P(0|1) = {1 - p11:.4f}')
        elif cmd in ('猜', 'g'):
            g = input('你猜是哪一個（0＝沒有、1＝2%／8%、2＝5%／15%）：').strip()
            print('答對了！' if g.isdigit() and int(g) < 3 and cases[int(g)][0] == name else '答錯了，', '答案是', name)
            return


if __name__ == '__main__':
    a = sys.argv[1:]
    if a and a[0] in ('偵探', 'detective'):
        detective()
    elif a and a[0] in ('次數', 'shots'):
        p, err = float(a[1]), float(a[2])
        print(f'P = {p}、誤差 ±{err}：需要約 {shots_needed(p, err)} shots')
    else:
        table()
