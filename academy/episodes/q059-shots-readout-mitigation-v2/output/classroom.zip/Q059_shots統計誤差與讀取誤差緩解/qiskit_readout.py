"""Q059 選用：用 Qiskit + Aer 跑 100、1000、10000 shots，並做一次混淆矩陣校正。
需要：pip install qiskit qiskit-aer（製作時用 qiskit 2.6.2、qiskit-aer 0.18.4 實跑過）。
"""
from qiskit import QuantumCircuit
from qiskit_aer import AerSimulator
from qiskit_aer.noise import NoiseModel, ReadoutError

# 讀取錯誤：準備 0 讀成 1 的機率 2%，準備 1 讀成 0 的機率 8%（改這裡就是偵探遊戲的「偷偷加料」）
ro = ReadoutError([[0.98, 0.02], [0.08, 0.92]])
noise = NoiseModel(); noise.add_all_qubit_readout_error(ro)
sim = AerSimulator(noise_model=noise, seed_simulator=59)


def p1(qc, shots):
    c = sim.run(qc, shots=shots).result().get_counts()
    return c.get('1', 0) / shots


plus = QuantumCircuit(1); plus.h(0); plus.measure_all()
for N in (100, 1000, 10000):
    p = p1(plus, N); s = (p * (1 - p) / N) ** 0.5
    print(f'加態 {N:>5} 次：P(1) = {p:.4f} ± {s:.4f}')
# 校準線路：準備 0、準備 1
c0 = QuantumCircuit(1); c0.measure_all()
c1 = QuantumCircuit(1); c1.x(0); c1.measure_all()
e10 = p1(c0, 10000); e11 = p1(c1, 10000)
print(f'校準：P(1|0) = {e10:.4f}，P(1|1) = {e11:.4f}')
raw = p1(plus, 10000)
mit = (raw - e10) / (e11 - e10)
print(f'加態 10000 次：原始 P(1) = {raw:.4f}，緩解後 P(1) = {mit:.4f}（理想 0.5）')
