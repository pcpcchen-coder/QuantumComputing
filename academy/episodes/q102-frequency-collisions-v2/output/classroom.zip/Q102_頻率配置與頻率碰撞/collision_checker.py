"""父子科技學院 量子電腦學程 Q102：頻率碰撞檢查器（只用 Python 標準函式庫，不需安裝、不需帳號）

規則與數值照學程 3D 動畫 transmon-3d.html#case（第 6 章）的設定：
  非諧性 α = −283 MHz（1→2 比 0→1 低 283 MHz）
  判定窗（示意值）：同頻 ±30 MHz、0→1 撞 1→2 ±25 MHz、雙光子 ±12 MHz
位元排成一列：Q1 – Q2 – Q3 – …，相鄰的兩顆互為鄰居；
同一顆位元的兩個鄰居（隔一顆）也要檢查「旁觀者碰撞」。

執行：python collision_checker.py
改造：把 PLANS 裡的頻率換成你自己排的數字（單位 GHz），再執行一次。
"""
ALPHA = -0.283                                  # GHz
WIN = {'same': 0.030, 'x12': 0.025, 'tp': 0.012}  # GHz


def check(freqs, tops=None):
    """回傳碰撞清單；空清單代表依動畫的判定窗沒有碰撞。
    tops：每顆位元的最高頻率（磁通為零的 sweet spot）；SQUID 只能往下調，超過就算錯。"""
    out = []
    n = len(freqs)
    for k, (f, top) in enumerate(zip(freqs, tops or [9.9] * n)):
        if f > top + 1e-9:
            out.append(f'Q{k + 1} 排 {f:.2f} 高於最高 {top:.2f}（只能往下調）')

    def pair(i, j, spectator):
        fi, fj = freqs[i], freqs[j]
        a, b = f'Q{i + 1}', f'Q{j + 1}'
        pre = '旁觀者：' if spectator else ''
        if abs(fi - fj) < WIN['same']:
            out.append(f'{pre}{a} ≈ {b}（同頻，差 {abs(fi - fj) * 1000:.0f} MHz）')
        if abs(fi - (fj + ALPHA)) < WIN['x12']:
            out.append(f'{pre}{a} 0→1 ≈ {b} 1→2')
        if abs(fj - (fi + ALPHA)) < WIN['x12']:
            out.append(f'{pre}{b} 0→1 ≈ {a} 1→2')
        if not spectator:
            if abs(fi - (fj + ALPHA / 2)) < WIN['tp']:
                out.append(f'{a} 驅動 ≈ {b} 雙光子 0→2')
            if abs(fj - (fi + ALPHA / 2)) < WIN['tp']:
                out.append(f'{b} 驅動 ≈ {a} 雙光子 0→2')

    for i in range(n - 1):
        pair(i, i + 1, False)      # 相鄰
    for i in range(n - 2):
        pair(i, i + 2, True)       # 同一顆位元的兩個鄰居
    return out


def zones(f):
    """某顆位元頻率為 f 時，鄰居不能去的五個頻率（GHz）。"""
    return {'0→1 撞 1→2（下）': f + ALPHA, '雙光子（下）': f + ALPHA / 2, '同頻': f,
            '雙光子（上）': f - ALPHA / 2, '0→1 撞 1→2（上）': f - ALPHA}


# 五顆練習用的「最高頻率」（自訂的練習數字，不是哪一台真機的資料）
TOPS5 = [5.12, 5.10, 5.39, 5.05, 5.25]

PLANS = {
    '剛做好（製程原貌）': [5.12, 5.10, 5.39],
    '棋盤格': [4.90, 5.10, 4.90],
    '動畫的配置': [4.90, 5.10, 5.30],
    '第二個空位': [4.90, 5.10, 5.00],
    '五顆（第一次嘗試）': [4.90, 5.10, 5.30, 5.00, 4.80],
    '五顆（範例解）': [4.90, 5.10, 5.30, 4.90, 5.10],
}

if __name__ == '__main__':
    print('Q2 在 5.10 GHz 時，鄰居的禁區：')
    for k, v in zones(5.10).items():
        print(f'  {k:<14}{v:.3f} GHz')
    print()
    for name, fs in PLANS.items():
        res = check(fs, TOPS5 if len(fs) == 5 else None)
        print(f'{name}：' + '、'.join(f'{f:.2f}' for f in fs) + ' GHz')
        print('  ' + ('無碰撞 ✓' if not res else f'碰撞 {len(res)} 處：' + '；'.join(res)))
