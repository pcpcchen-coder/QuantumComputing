"""父子科技學院 量子電腦學程 Q036：IQ 解調小工具。

不用安裝任何套件，只要 Python 3。執行：  python iq_check.py
- 一、解調：做一段 100 MHz 的中頻訊號 s(t) = A·cos(2π·f·t + φ)，每 1 ns 取樣一次（每秒十億次），取 200 ns；
  乘上 cos 加總得到 I、乘上 sin 加總得到 Q（學程簡報 JJ_Microwave_Readout_Talk p30 的公式，這裡權重 w(t) 取 1）。
  I = (2/N)·Σ s·cos(2πft)、Q = (2/N)·Σ s·sin(2πft)，算出來 I = A·cos φ、Q = −A·sin φ，所以 √(I² + Q²) = A。
- 二、混頻：7 GHz 的讀取訊號乘上 6.9 GHz 的本地振盪源，看乘積裡 0.1、6.9、7、13.9 GHz 各有多少。
- 三、正中間探測（上一堂 Q035，2χ = κ）：兩個狀態的穿透係數 S21 振幅一樣，但在 IQ 平面上的兩點距離是 1。
- 四、雲團：兩團中心距離 ÷（2 × 團寬 σ）＝ 訊雜比 SNR（簡報 p31；動畫 index.html#iq 的讀數同式），
  並印出手繪練習用的點（固定亂數種子，可重現）。
"""
import cmath
import math
import random


def demod(A, phi_deg, f=0.1, n=200):
    """f 以 GHz 為單位、每 1 ns 取一點，回傳 (I, Q)。"""
    phi = math.radians(phi_deg)
    s = [A * math.cos(2 * math.pi * f * t + phi) for t in range(n)]
    I = 2 / n * sum(v * math.cos(2 * math.pi * f * t) for t, v in enumerate(s))
    Q = 2 / n * sum(v * math.sin(2 * math.pi * f * t) for t, v in enumerate(s))
    return I, Q


print('一、解調：訊號的振幅 A、相位 φ → 算出的 I、Q → 從 I、Q 算回振幅與相位')
DEMOD = {}
for A, ph in ((1.0, 0), (1.0, 90), (1.0, 135), (0.5, 0), (0.5, 45), (0.8, -60)):
    I, Q = demod(A, ph)
    DEMOD[(A, ph)] = (I, Q)
    back = round(math.degrees(math.atan2(-Q, I)), 6) + 0.0
    print(f'  A = {A:.1f}、φ = {ph:+4d}° → I = {I:+.3f}、Q = {Q:+.3f} → 振幅 √(I²+Q²) = {math.hypot(I, Q):.3f}、相位 {back:+.1f}°')

print()
print('二、混頻：cos(2π·7t) × cos(2π·6.9t)，t 以 ns 為單位、每 0.005 ns 取一點、取 100 ns')
N2, DT = 20000, 0.005
prod = [math.cos(2 * math.pi * 7 * k * DT) * math.cos(2 * math.pi * 6.9 * k * DT) for k in range(N2)]
MIX = {}
for f in (0.1, 6.9, 7.0, 13.9):
    c = sum(v * cmath.exp(-2j * math.pi * f * k * DT) for k, v in enumerate(prod))
    MIX[f] = 2 * abs(c) / N2
    print(f'  {f:>5} GHz 的成分振幅：{MIX[f]:.3f}')
print('  → 剩下 0.1 GHz（差頻）和 13.9 GHz（和頻）各 0.5；和頻再用濾波器濾掉，就只剩 100 MHz 的中頻')

print()
print('三、正中間探測（χ/κ = 0.5，探測頻率在兩個諧振腔頻率正中間）')


def s21(probe, shift):
    return 1 / (1 + 2j * (probe - shift))


S0, S1 = s21(0, -0.5), s21(0, 0.5)
MID = (abs(S0), abs(S1), abs(S1 - S0), math.degrees(cmath.phase(S0)), math.degrees(cmath.phase(S1)))
print(f'  |0⟩：I = {S0.real:+.3f}、Q = {S0.imag:+.3f}，振幅 {abs(S0):.3f}、相位 {MID[3]:+.1f}°')
print(f'  |1⟩：I = {S1.real:+.3f}、Q = {S1.imag:+.3f}，振幅 {abs(S1):.3f}、相位 {MID[4]:+.1f}°')
print(f'  → 振幅一樣，只看振幅分不出來；兩點距離 {abs(S1 - S0):.3f}，在平面上分得很開')

print()
print('四、雲團：|0⟩ 中心 (−1.4, −0.7)、|1⟩ 中心 (+1.4, +0.7)，判別線是兩個中心的垂直平分線')
C0, C1 = (-1.4, -0.7), (1.4, 0.7)
D = math.dist(C0, C1)
SNR = {}
WRONG = {}
rng = random.Random(36)
for sig in (0.33, 1.25):
    SNR[sig] = D / (2 * sig)
    wrong = 0
    for k in range(2000):
        c = C0 if k % 2 == 0 else C1
        x, y = c[0] + rng.gauss(0, sig), c[1] + rng.gauss(0, sig)
        side = x * (C1[0] - C0[0]) + y * (C1[1] - C0[1])  # 投影到兩中心連線（中點在原點）
        wrong += (side > 0) if c is C0 else (side < 0)
    WRONG[sig] = wrong / 2000
    print(f'  團寬 σ = {sig}：訊雜比 = {D:.2f} ÷ (2 × {sig}) = {SNR[sig]:.1f}；2000 個點裡落錯邊的比例 {WRONG[sig] * 100:.1f} %')

print()
print('五、手繪練習的點（團寬 0.33，四捨五入到 0.1；每格 0.5）')
rng = random.Random(2036)
DRAW = []
for k in range(12):
    st = k % 2
    c = C1 if st else C0
    x, y = round(c[0] + rng.gauss(0, 0.33), 1), round(c[1] + rng.gauss(0, 0.33), 1)
    DRAW.append((st, x, y))
    print(f'  第 {k + 1:2d} 點：準備 |{st}⟩ → (I, Q) = ({x:+.1f}, {y:+.1f})')
