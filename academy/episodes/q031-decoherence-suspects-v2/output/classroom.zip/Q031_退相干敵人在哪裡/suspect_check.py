"""父子科技學院 量子電腦學程 Q031：退相干偵探小工具（和動畫 index.html#bloch 同一套公式）。

不用安裝任何套件，只要 Python 3。執行：  python suspect_check.py
- 一、鐵律檢查：T2 不會大於 2*T1；超過就先懷疑量測或計算。
- 二、從證據配對嫌犯（學程簡報 JJ_Microwave_Readout_Talk p24 的整理）。
- 三、動畫的衰減曲線：T1 模式 P(1) = e^(-t/5)；Ramsey 模式 |r| = e^(-t/6)、P(1) 固定 0.5
  （animations/js/scenes/01_bloch.js 第 50、80–84 行；時間是動畫的相對單位）。
"""
import math

SUSPECTS = {
    'TLS 二能階缺陷': ('T1 變短（還會讓頻率漂移）', '表面處理、Ta/Nb 電容板、藍寶石或高電阻率矽基板、加大電容板間距'),
    '準粒子（紅外線、宇宙射線）': ('T1 變短', '紅外屏蔽、濾波器、準粒子陷阱'),
    '磁通雜訊': ('T2 變短（可調頻量子位元）', '停在甜蜜點、不對稱 SQUID、磁屏蔽'),
    '讀取腔熱光子': ('T2 變短', '輸入線衰減器、良好接地與封裝'),
    'Purcell 效應': ('T1 變短（能量經讀取腔漏出）', 'Purcell 濾波器'),
}


def believable(t1, t2):
    """T2 <= 2*T1 才可信。"""
    return t2 <= 2 * t1


def suspects_for(t1_short, t2_short):
    if t1_short:
        return [k for k, v in SUSPECTS.items() if v[0].startswith('T1')]
    if t2_short:
        return [k for k, v in SUSPECTS.items() if v[0].startswith('T2')]
    return []


print('一、鐵律檢查（單位：微秒）')
CASES = [(50, 80), (50, 100), (50, 150), (100, 120)]
CHECK = {}
for t1, t2 in CASES:
    ok = believable(t1, t2)
    CHECK[(t1, t2)] = ok
    print(f'  T1 = {t1:3d}、T2 = {t2:3d}：2*T1 = {2 * t1:3d} → ' + ('可信' if ok else '不可能，先懷疑量測或計算'))

print()
print('二、從證據配對嫌犯')
for label, a, b in (('T1 變短', True, False), ('T1 沒變、只有 T2 變短', False, True)):
    print(f'  {label}：' + '、'.join(suspects_for(a, b)))
print('  嫌犯檔案：')
for k, (ev, fix) in SUSPECTS.items():
    print(f'    {k}｜證據：{ev}｜對策：{fix}')

print()
print('三、動畫 index.html#bloch 的衰減（相對單位，T1 = 5、T2 = 6）')
CURVE = {}
for t in (0, 2, 3.47, 5, 8, 12):
    p1 = math.exp(-t / 5)
    r = math.exp(-t / 6)
    CURVE[t] = (p1, 1 - 2 * p1, r)
    print(f'  t = {t:5.2f}：T1 模式 P(1) = {p1:.2f}、z = {1 - 2 * p1:+.2f}｜Ramsey 模式 |r| = {r:.2f}、P(1) = 0.50')
print('  T1 模式在 t = 5 ln2 ≈ 3.47 時箭頭經過球心；12 時重來一次')
