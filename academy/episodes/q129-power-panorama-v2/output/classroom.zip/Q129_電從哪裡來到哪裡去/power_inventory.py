"""父子科技學院 量子電腦學程 Q129：電從哪裡來、到哪裡去——用電清單（純 Python，不需要安裝任何套件，沒有亂數）

執行：  python power_inventory.py
一、一套超導量子電腦（約 20 位元級）的用電清單：數字取自學程動畫 peripherals.html#overview 右下的「典型用電分配（示意）」。
二、1,000 位元設施的用電清單：數字取自 power1000.html#overview（設計文件第 4 章的推論區間）。
三、和一個超級電腦（HPC）機櫃比一比（約 140 kW，供電簡報第 6 頁）。
四、改造區：把你自己找到的設備寫進 MY_LIST，程式會幫你分類加總。
"""

# 一、一套超導量子電腦：(設備, kW, 類別)
ONE_SYSTEM = [
    ('脈衝管壓縮機', 10.7, '冷凍'),
    ('冷卻水系統', 10.0, '設施'),
    ('控制電子機櫃', 3.0, '控制電子'),
    ('氣體處理系統（泵）', 1.5, '冷凍'),
    ('電腦 / 監控 / 網路', 1.0, '設施'),
]
# 為了讓晶片保持低溫而用的電：壓縮機、冷卻水（帶走壓縮機的熱）、氣體處理系統
KEEP_COLD = ('脈衝管壓縮機', '冷卻水系統', '氣體處理系統（泵）')

# 二、1,000 位元設施：(負載, 低 kW, 高 kW, 匯流排)
FACILITY = [
    ('壓縮機 ×3–5', 37.5, 62.5, '機電'),
    ('冰水機與泵', 15, 40, '機電'),
    ('氣體處理系統', 3, 5, '機電'),
    ('控制電子', 10, 100, '乾淨'),
    ('精密直流 ×110 台', 3, 7, '乾淨'),
    ('時脈與網路', 2, 5, '乾淨'),
    ('即時解碼', 5, 50, '運算'),
    ('電子區空調', 5, 50, '運算'),
]

GROUPS = ('冷凍', '控制電子', '設施')
HPC_RACK = 140.0  # kW，一個 HPC 機櫃（Cray EX4000，供電簡報第 6 頁）

# 四、改造區：你在動畫裡找到的設備（設備, kW, 類別：冷凍／控制電子／設施）
MY_LIST = [
    ('脈衝管壓縮機', 10.7, '冷凍'),
    ('冷卻水系統', 10.0, '設施'),
    ('控制電子機櫃', 3.0, '控制電子'),
]


def by_group(items):
    out = {}
    for name, kw, g in items:
        out[g] = out.get(g, 0) + kw
    return out


def show_list(title, items):
    total = sum(kw for _, kw, _ in items)
    print(title)
    for name, kw, g in items:
        print(f'  {name}：{kw:.1f} kW（{kw / total * 100:.1f}%，{g}）')
    print(f'  合計 {total:.1f} kW')
    groups = by_group(items)
    print('  分三類：' + '、'.join(f'{g} {groups[g]:.1f} kW（{groups[g] / total * 100:.0f}%）' for g in GROUPS if g in groups))
    return total


if __name__ == '__main__':
    total = show_list('一、一套超導量子電腦（peripherals.html#overview，示意）', ONE_SYSTEM)
    cold = sum(kw for n, kw, _ in ONE_SYSTEM if n in KEEP_COLD)
    print(f'  為了保冷用的電（壓縮機＋冷卻水＋氣體處理）：{cold:.1f} kW，佔 {cold / total * 100:.0f}%')
    print('二、1,000 位元設施（power1000.html#overview，推論區間）')
    lo = sum(x[1] for x in FACILITY)
    hi = sum(x[2] for x in FACILITY)
    mid = sum((x[1] + x[2]) / 2 for x in FACILITY)
    for bus in ('機電', '乾淨', '運算'):
        rows = [x for x in FACILITY if x[3] == bus]
        print(f'  {bus}匯流排：{sum(r[1] for r in rows):g}–{sum(r[2] for r in rows):g} kW（'
              + '、'.join(r[0] for r in rows) + '）')
    print(f'  合計 {lo:g}–{hi:g} kW，中點合計 {mid:g} kW')
    print('三、和一個 HPC 機櫃（約 140 kW）比')
    print(f'  一套超導量子電腦 {total:.1f} kW ＝ 機櫃的 {total / HPC_RACK * 100:.0f}%')
    print(f'  1,000 位元設施中點 {mid:g} kW ＝ {mid / HPC_RACK:.1f} 個機櫃')
    print('四、我的用電清單（MY_LIST）')
    mine = by_group(MY_LIST)
    for g in GROUPS:
        print(f'  {g}：{mine.get(g, 0):.1f} kW' + ('' if g in mine else '  ← 還沒找到這一類'))
    print(f'  已找到 {len(MY_LIST)} 項、合計 {sum(kw for _, kw, _ in MY_LIST):.1f} kW')
