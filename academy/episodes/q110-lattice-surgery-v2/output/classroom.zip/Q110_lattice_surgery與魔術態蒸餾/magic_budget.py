"""父子科技學院 量子電腦學程 Q110：lattice surgery 與魔術態蒸餾（純 Python，不需要安裝任何套件）

執行：  python magic_budget.py
一、T 閘傳送：用一顆魔術態 |T⟩ 加上 Z⊗Z、X 兩次量測，把 T 作用到資料位元上（四種量測結果逐一驗算）。
二、15-to-1 蒸餾的檢查：15 顆輸入編號 1～15，工廠量 4 個檢查值（第 k 個檢查看編號二進位第 k 位是 1 的那 8 顆）。
三、注入錯誤率 p → 接受率、輸出錯誤率（32768 種錯誤排列全部加總，不用亂數）。
四、邏輯閘資源估算表：要跑 MY_T_COUNT 個 T 閘，需要幾輪蒸餾、消耗多少顆注入態。
"""
import cmath
from itertools import combinations

# 改造區 1：注入錯誤率（調高看看接受率怎麼變；動畫滑桿最右邊約 0.05）
MY_P = 0.04
# 改造區 2：資源估算——演算法要用幾個 T 閘
MY_T_COUNT = 10 ** 9


def fmt(x):
    return f'{x:.1e}'.replace('e-0', 'e-').replace('e-', '×10^-') if x < 0.01 else f'{x:.3f}'


# ---------- 一、T 閘傳送 ----------
W = cmath.exp(1j * cmath.pi / 4)            # T = diag(1, e^{iπ/4})


def teleport_T(a, b):
    """資料 a|0⟩+b|1⟩，魔術態 (|0⟩+W|1⟩)/√2；回傳四種結果 (ZZ, X) → 機率、資料位元的狀態"""
    s = 2 ** -0.5
    amp = {(0, 0): a * s, (0, 1): a * W * s, (1, 0): b * s, (1, 1): b * W * s}   # (資料, 魔術態)
    out = {}
    for zz in (+1, -1):
        keep = {k: v for k, v in amp.items() if (1 if k[0] == k[1] else -1) == zz}      # 量 Z⊗Z
        for x in (+1, -1):
            # 量魔術態的 X：投影到 |+⟩ 或 |−⟩，剩下資料位元的狀態
            d0 = sum(v * (1 if k[1] == 0 else x) for k, v in keep.items() if k[0] == 0) * s
            d1 = sum(v * (1 if k[1] == 0 else x) for k, v in keep.items() if k[0] == 1) * s
            out[(zz, x)] = (abs(d0) ** 2 + abs(d1) ** 2, d0, d1)
    return out


def same_state(u0, u1, v0, v1):
    """兩個單一位元狀態是否只差一個整體相位"""
    n = (abs(u0) ** 2 + abs(u1) ** 2) ** 0.5 * (abs(v0) ** 2 + abs(v1) ** 2) ** 0.5
    return abs(abs(u0.conjugate() * v0 + u1.conjugate() * v1) - n) < 1e-12


# ---------- 二、15-to-1 的 4 個檢查 ----------
def syndrome(bad):
    """bad = 出錯輸入的編號集合；第 k 個檢查 = 編號二進位第 k 位是 1 的輸入裡，出錯的個數是奇數"""
    return tuple(sum((q >> k) & 1 for q in bad) % 2 for k in range(4))


# 32768 種錯誤排列裡，哪些騙得過 4 個檢查：依出錯顆數分類
SNEAKY = [0] * 16
for w in range(16):
    SNEAKY[w] = sum(1 for bad in combinations(range(1, 16), w) if syndrome(bad) == (0, 0, 0, 0))


def distill(p):
    """一輪 15-to-1：接受率、輸出錯誤率（騙過檢查又不是零個錯誤的，一律算成輸出有錯）"""
    acc = sum(SNEAKY[w] * p ** w * (1 - p) ** (15 - w) for w in range(16))
    bad = sum(SNEAKY[w] * p ** w * (1 - p) ** (15 - w) for w in range(1, 16))
    return acc, bad / acc


if __name__ == '__main__':
    print('一、T 閘傳送（資料 = 0.6|0⟩ + 0.8i|1⟩）')
    a, b = 0.6, 0.8j
    target = (a, b * W)                        # T|ψ⟩
    fixes = {'不必補': lambda d0, d1: (d0, d1), '補相位翻轉': lambda d0, d1: (d0, -d1),
             '補 S': lambda d0, d1: (d0, 1j * d1), '補 S 和相位翻轉': lambda d0, d1: (d0, -1j * d1)}
    for (zz, x), (prob, d0, d1) in teleport_T(a, b).items():
        fix = next(n for n, f in fixes.items() if same_state(*f(d0, d1), *target))
        print(f'  Z⊗Z = {zz:+d}、X = {x:+d}：機率 {prob:.2f} → {fix} → 得到 T|ψ⟩ ✓')
    print('二、15 顆輸入裡有幾顆出錯，騙得過 4 個檢查的排列有幾種')
    for w in (1, 2, 3, 4):
        print(f'  {w} 顆出錯：{len(list(combinations(range(15), w))):4d} 種排列中 {SNEAKY[w]:3d} 種騙過檢查')
    print('三、注入錯誤率 p → 一輪蒸餾的接受率與輸出錯誤率（35p³ 是近似公式）')
    for p in (1e-4, 1e-3, 1e-2, 0.05, 0.1, MY_P):
        acc, out = distill(p)
        print(f'  p = {fmt(p):>10}  接受率 {acc * 100:5.1f}%  輸出錯誤率 {fmt(out):>10}  35p³ = {fmt(35 * p ** 3)}'
              + ('  ← 我的 p（MY_P）' if p is MY_P else ''))
    print(f'四、邏輯閘資源估算表（{MY_T_COUNT:,} 個 T 閘，注入錯誤率 1.0×10^-3，目標：全部加起來出錯不到 0.01 次）')
    p_in, cost, rounds = 1e-3, 1.0, 0
    while True:
        total_fail = MY_T_COUNT * p_in
        print(f'  蒸餾 {rounds} 輪：每顆魔術態錯誤率 {fmt(p_in):>10}，每顆約耗 {cost:7.1f} 顆注入態，'
              f'全部 T 閘預計出錯 {total_fail:.1e} 次')
        if total_fail < 0.01:
            break
        acc, p_in = distill(p_in)
        cost, rounds = cost * 15 / acc, rounds + 1
    print(f'  → 要蒸餾 {rounds} 輪；總共約 {MY_T_COUNT * cost:.1e} 顆注入態')
