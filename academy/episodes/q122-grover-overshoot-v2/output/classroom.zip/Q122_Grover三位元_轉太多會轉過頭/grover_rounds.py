"""父子科技學院 量子電腦學程 Q122：Grover 三位元——轉太多會轉過頭（純 Python，不需安裝任何套件）

執行：  python grover_rounds.py
它印出：
  一、三顆位元、答案 101：0～3 輪，每輪標記後的平均、答案和其他的振幅、答案的機率
  二、繼續多做幾輪：機率先降、再爬回來（一圈一圈起伏）
  三、指針的角度：每一輪多轉同樣的角度，答案在 90°
  四、選項變多：最佳輪數 ≈ (π/4)√N，和古典平均要試幾次比一比
  五、如果有兩個答案：最佳輪數變少，做太多一樣轉過頭
  六、改造區：換成自己的 N，先算，再執行
位元字串寫成 q2 q1 q0（最右邊是 q0），和 basic-circuits.html#grover、Qiskit 一樣。
"""
from math import asin, degrees, pi, sin, sqrt

ANSWER = '101'      # 簡報第 25 頁用的答案


def sg(a):
    return f'{a + 0.0:+.2f}'.replace('-', '−')


def grover(n, answers, rounds):
    """回傳每一輪的紀錄：(輪數, 標記後平均, 擴散後的振幅)"""
    N = 2 ** n
    idx = [int(t, 2) for t in answers]
    v = [1 / sqrt(N)] * N
    out = [(0, None, v[:])]
    for r in range(1, rounds + 1):
        for i in idx:
            v[i] = -v[i]                   # 標記：答案變號
        m = sum(v) / N
        v = [2 * m - a for a in v]          # 擴散：對平均值翻轉
        out.append((r, m, v[:]))
    return out


def p_answer(v, answers):
    return sum(v[int(t, 2)] ** 2 for t in answers)


def best_rounds(N, k=1):
    """最佳輪數：讓 (2r + 1)θ 最接近 90° 的整數 r，sin θ = √(k/N)"""
    th = asin(sqrt(k / N))
    return max(1, round(pi / (4 * th) - 0.5)), th


if __name__ == '__main__':
    print(f'一、三顆位元、8 個選項、答案 {ANSWER}')
    i = int(ANSWER, 2)
    rec = grover(3, [ANSWER], 6)
    for r, m, v in rec[:4]:
        other = v[(i + 1) % 8]
        mark = '（還沒做）      ' if m is None else f'標記後平均 {sg(m)}'
        print(f'  {r} 輪：{mark}   答案 {sg(v[i])}   其他每根 {sg(other)}   答案的機率 {v[i] ** 2:.1%}')

    print('二、繼續多做幾輪')
    print('  ' + '  '.join(f'{r} 輪 {v[i] ** 2:.2%}' for r, m, v in rec))

    print('三、指針的角度（答案在 90°）')
    th = asin(1 / sqrt(8))
    print(f'  一開始 {degrees(th):.1f}°，每一輪多轉 {degrees(2 * th):.1f}°')
    print('  ' + '  '.join(f'{r} 輪 {degrees((2 * r + 1) * th):.0f}°→{sin((2 * r + 1) * th) ** 2:.1%}' for r in range(4)))

    print('四、選項變多：最佳輪數 vs 古典平均')
    for n in (2, 3, 4, 10, 20):
        N = 2 ** n
        r, t = best_rounds(N)
        print(f'  {n:>2} 顆（N = {N:>9,}）：(π/4)√N = {pi / 4 * sqrt(N):7.2f}，最佳 {r:>3} 輪，'
              f'成功率 {sin((2 * r + 1) * t) ** 2:.5%}；古典平均 {(N + 1) / 2:,.1f} 次')

    print('五、8 個選項裡有 2 個答案（101 和 011）')
    two = ['101', '011']
    r2, _ = best_rounds(8, 2)
    print('  ' + '  '.join(f'{r} 輪 {p_answer(v, two):.1%}' for r, m, v in grover(3, two, 3)) + f'   最佳 {r2} 輪')

    # 六、改造區：換成自己的 N（2 的次方），先算，再執行
    MY_N = 1024
    r, t = best_rounds(MY_N)
    print('六、改造區')
    print(f'  N = {MY_N:,}：√N = {sqrt(MY_N):g}，(π/4)√N ≈ {pi / 4 * sqrt(MY_N):.2f}，最佳 {r} 輪')
    print('  ' + '  '.join(f'{k} 輪 {sin((2 * k + 1) * t) ** 2:.2%}' for k in (r - 1, r, r + 1)))
    print(f'  古典平均要試 {(MY_N + 1) / 2:,.1f} 次')
