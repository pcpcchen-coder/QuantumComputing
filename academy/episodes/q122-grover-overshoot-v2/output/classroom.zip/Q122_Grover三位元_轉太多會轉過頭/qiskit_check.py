"""父子科技學院 量子電腦學程 Q122：用本機 Qiskit 重現三位元 Grover 的 1、2、3 輪（選用，不需要帳號）

安裝（只要一次）：  pip install qiskit
執行：              python qiskit_check.py
線路和 basic-circuits.html#grover 的接法相同：標記 = X、多控制 Z、X；擴散 = H、X、多控制 Z、X、H。
"""
from qiskit import QuantumCircuit
from qiskit.primitives import StatevectorSampler
from qiskit.quantum_info import Statevector

ANSWER = '101'      # 寫成 q2 q1 q0


def ccz(qc):
    qc.h(2)
    qc.ccx(0, 1, 2)                          # 多控制 Z = H、Toffoli、H
    qc.h(2)


def grover(rounds, measure=True):
    qc = QuantumCircuit(3)
    qc.h([0, 1, 2])
    zeros = [q for q in range(3) if ANSWER[2 - q] == '0']
    for _ in range(rounds):
        if zeros:
            qc.x(zeros)                      # 標記：先把答案變成 111
        ccz(qc)
        if zeros:
            qc.x(zeros)
        qc.h([0, 1, 2])                      # 擴散：H、X、多控制 Z、X、H
        qc.x([0, 1, 2])
        ccz(qc)
        qc.x([0, 1, 2])
        qc.h([0, 1, 2])
    if measure:
        qc.measure_all()
    return qc


sampler = StatevectorSampler(seed=2026)
for r in (1, 2, 3):
    p = Statevector(grover(r, measure=False)).probabilities_dict()[ANSWER]
    counts = sampler.run([grover(r)], shots=1000).result()[0].data.meas.get_counts()
    print(f'{r} 輪：答案 {ANSWER} 的理論機率 {p:.1%}　量 1000 次，{ANSWER} 出現 {counts.get(ANSWER, 0)} 次')
