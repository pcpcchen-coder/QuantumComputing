"""父子科技學院 量子電腦學程 Q020：磁通量子 Φ₀ = h/2e 有多小？——算數值、換算地磁場的面積、檢查相位時鐘貼紙。

不用安裝任何套件，只要 Python 3。執行：  python flux_scale.py
普朗克常數 h 與基本電荷 e 是國際單位制從 2019 年起的定義值；Φ₀ = h/(2e)（維基百科 Magnetic flux quantum、學程簡報 p9）。
地磁場約 30–60 μT（維基百科 Earth's magnetic field），本程式以 50 μT 為代表值。
"""
H = 6.62607015e-34    # 普朗克常數（J·s）
E = 1.602176634e-19   # 基本電荷（C）

PHI0 = H / (2 * E)    # 超導的磁通量子（Wb）
PHI_E = H / E         # 如果載流子是單顆電子，一格會是這麼大（Wb）
print(f'磁通量子 Φ₀ = h / 2e ≈ {PHI0:.4e} Wb')
print(f'如果是單顆電子 h / e ≈ {PHI_E:.4e} Wb（是 Φ₀ 的 {PHI_E / PHI0:.0f} 倍）')

print()
print('地磁場垂直穿過一個圈，要剛好裝進一格 Φ₀，圈要多大？（面積 = Φ₀ ÷ 磁場）')
AREAS = {}
for b_ut in (30, 50, 60):
    area = PHI0 / (b_ut * 1e-6)          # 平方公尺
    um2 = area * 1e12                    # 平方微米
    side = area ** 0.5 * 1e6             # 正方形每一邊（微米）
    AREAS[b_ut] = (um2, side)
    print(f'  {b_ut} μT：面積 ≈ {um2:5.1f} μm²，正方形每一邊 ≈ {side:4.2f} μm')
PER_MM = 1000 / AREAS[50][1]
print(f'一毫米（1000 μm）裡排得下約 {PER_MM:.0f} 個每邊 {AREAS[50][1]:.1f} μm 的小正方形')

print()
print('繩圈上 8 張相位時鐘貼紙：每張多轉幾度，回到起點時一共轉了幾圈？')
TURNS = {}
for step in (45, 22.5, 90, 30):
    total = 8 * step
    TURNS[step] = total / 360
    ok = '可以（整數圈）' if total % 360 == 0 else '不行（接不起來）'
    print(f'  每張 {step:5.1f}°：一共 {total:5.1f}° = {total / 360:.2f} 圈 → {ok}')
