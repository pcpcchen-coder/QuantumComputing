"""父子科技學院 量子電腦學程 Q112：模組發表——換你當老師（純 Python，不需要安裝任何套件）

執行：  python teach_helper.py
一、對答案：transmon-3d.html 第 1 章「大十字電容的作用」分頁的面板數字，照動畫的程式重算一次
    （電荷基底哈密頓量 + 二分法求能階；E_J/h 固定 15 GHz、E_C/h = 19.37 / C[fF] GHz）。
二、出題小幫手：把 MY_C 改成你想考爸爸的電容值，印出一題計算題和它的解答。
三、對話稿檢查：檢查 MY_LESSON 是否有一課該有的五個部分、老師和學生是否都有說話、
    動畫有沒有註明出處（章名與網址後面的 #代號）、課後練習是不是剛好三題而且都有解答。
"""

# 改造區 1：你想考爸爸的電容值（fF；動畫滑桿範圍 5–200，每格 0.5）
MY_C = 40

# 改造區 2：你的自編對話（照模板寫；每一行用「標記：內容」）
MY_LESSON = '''
課名：第 2 課 Transmon 怎麼寫入狀態
學習目標：對照晶片圖說出十字電容、SQUID、XY 線、Z 線、讀取腔各自的工作
學生：transmon 是怎麼寫入狀態的？SQUID 的作用是什麼？
老師：先猜猜看，五個零件裡，哪一個負責寫入？
學生：SQUID？
老師：很多人這樣猜。其實 SQUID 不負責寫入，XY 線送 5.21 GHz 的微波脈衝才是寫入。
學生：那 SQUID 做什麼？
老師：它有兩個身分：非線性電感，讓能階不等距；也是頻率旋鈕，Z 線的磁通靠它調頻率。
重點整理：XY 線寫入、Z 線經由 SQUID 調頻率、讀取共振腔讀出；SQUID 不負責寫入
動畫演示：transmon-3d.html#chip 第 1 章 晶片：按「送出 π 脈衝」，十字板發光代表進入 |1⟩
練習 1：要把 |0⟩ 寫成一半一半的疊加，要改脈衝的哪個參數？
解答 1：脈衝面積（振幅 × 時間）做成 π/2
練習 2：XY 線和 Z 線分別用電場還是磁場耦合到位元？
解答 2：XY 用電場（電容耦合）；Z 用磁場（磁通穿過 SQUID 迴路）
練習 3：改錯：「SQUID 負責把狀態寫進位元。」
解答 3：寫入靠 XY 線的微波脈衝；SQUID 是非線性電感和頻率旋鈕
'''

from decimal import Decimal, ROUND_HALF_UP

EJ = 15.0          # E_J/h（GHz），和動畫相同
EC_PER_FF = 19.37  # E_C/h [GHz] = 19.37 / C[fF]，和動畫相同


def transmon_levels(ej, ec, ng, k=3, n=25):
    """電荷基底三對角哈密頓量，用 Sturm 序列二分法求最低 k 個能階（照動畫 transmonLevels 改寫）"""
    d = [4 * ec * (m - ng) ** 2 for m in range(-n, n + 1)]
    e2 = (ej / 2) ** 2

    def count(x):
        q = d[0] - x
        c = 1 if q < 0 else 0
        for i in range(1, len(d)):
            q = d[i] - x - e2 / (1e-300 if q == 0 else q)
            if q < 0:
                c += 1
        return c
    out = []
    for j in range(k):
        lo, hi = -ej - 1, 4 * ec * (n + 1) ** 2 + ej + 1
        for _ in range(90):
            m = (lo + hi) / 2
            if count(m) > j:
                hi = m
            else:
                lo = m
        out.append((lo + hi) / 2)
    return out


def cap_stats(c):
    ec = EC_PER_FF / c
    a, b = transmon_levels(EJ, ec, 0), transmon_levels(EJ, ec, 0.5)
    fa, fb = a[1] - a[0], b[1] - b[0]
    return {'EC': ec, 'f01': (fa + fb) / 2, 'alpha': ((a[2] - 2 * a[1] + a[0]) + (b[2] - 2 * b[1] + b[0])) / 2,
            'disp': abs(fa - fb), 'ratio': EJ / ec}


def fixed(x, n):
    """和 JavaScript 的 toFixed 一樣：剛好一半時進位"""
    return str(Decimal(x).quantize(Decimal(1).scaleb(-n), rounding=ROUND_HALF_UP))


def fmt_f(g):
    """和動畫一樣的頻率格式（輸入單位 GHz）"""
    v = g * 1e9
    if v >= 1e9:
        return fixed(g, 2) + ' GHz'
    if v >= 1e6:
        return fixed(v / 1e6, 0 if v >= 1e8 else 1) + ' MHz'
    if v >= 1e3:
        return fixed(v / 1e3, 1) + ' kHz'
    return fixed(v, 1) + ' Hz'


def verdict(ratio):
    return '電荷雜訊主導（接近 Cooper pair box）' if ratio < 20 else 'transmon 區間' if ratio <= 120 else '非諧性偏小，閘需放慢'


def row(c):
    r = cap_stats(c)
    disp = '< 0.1 Hz' if r['disp'] * 1e9 < 0.1 else fmt_f(r['disp'])
    sign = '−' if r['alpha'] < 0 else '+'
    return (f'C_Σ {c:.1f} fF：E_C {fmt_f(r["EC"])}，E_J/E_C {fixed(r["ratio"], 1)}，f₀₁ {fmt_f(r["f01"])}，'
            f'α {sign}{fmt_f(abs(r["alpha"]))}，電荷色散 {disp}，判斷：{verdict(r["ratio"])}')


SECTIONS = ['課名', '學習目標', '重點整理', '動畫演示']


def check_lesson(text):
    lines = [s.strip() for s in text.strip().splitlines() if s.strip()]
    tags = [s.split('：', 1)[0] for s in lines]
    res = []
    for s in SECTIONS:
        res.append((f'有「{s}」', s in tags))
    t, st = tags.count('老師'), tags.count('學生')
    res.append((f'師生對話：老師 {t} 句、學生 {st} 句（兩邊都要有）', t > 0 and st > 0))
    anim = [s for s in lines if s.startswith('動畫演示')]
    res.append(('動畫註明出處（檔名＋#代號＋章名）', any('.html#' in s and '章' in s for s in anim)))
    q = [s for s in tags if s.startswith('練習')]
    a = [s for s in tags if s.startswith('解答')]
    res.append((f'課後練習 {len(q)} 題、解答 {len(a)} 個（要剛好三題、每題都有解答）', len(q) == 3 and len(a) == 3))
    return res


if __name__ == '__main__':
    print('一、對答案：第 1 章「大十字電容的作用」面板（E_J/h = 15 GHz）')
    for c in (20, 77.5, 200):
        print('  ' + row(c))
    lo = next(x / 2 for x in range(10, 401) if 20 <= cap_stats(x / 2)['ratio'] <= 120)
    hi = max(x / 2 for x in range(10, 401) if 20 <= cap_stats(x / 2)['ratio'] <= 120)
    print(f'  滑桿每格 0.5 fF：判斷是「transmon 區間」的範圍是 {lo:.1f}–{hi:.1f} fF')
    print(f'二、出題小幫手（MY_C = {MY_C}）')
    r = cap_stats(MY_C)
    print(f'  題目：如果十字電容是 {MY_C} fF，E_J/E_C 是多少？位元頻率 f₀₁ 會比 77.5 fF 時的 5.21 GHz 高還是低？落在哪個區間？')
    print(f'  解答：E_J/E_C = {fixed(r["ratio"], 1)}；f₀₁ = {fmt_f(r["f01"])}（比 5.21 GHz {"高" if r["f01"] > cap_stats(77.5)["f01"] else "低"}）；{verdict(r["ratio"])}')
    print('  ' + row(MY_C))
    print('三、對話稿檢查（MY_LESSON）')
    res = check_lesson(MY_LESSON)
    for name, ok in res:
        print(f'  {"✓" if ok else "✗"} {name}')
    print(f'  結果：{sum(ok for _, ok in res)}/{len(res)} 項通過')
