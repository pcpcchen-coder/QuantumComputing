"""父子科技學院 量子電腦學程 Q055：兩位元閘小實驗室（只用 Python 標準函式庫）

執行：python twoqubit_lab.py
一、CZ 和 CNOT 作用在四個基底態上；CNOT = (I⊗H)·CZ·(I⊗H)。
二、交叉共振：目標 B 的旋轉方向由控制 A 決定。
三、照 operation.html#twoqubit（05_twoqubit.js）的模型，改「脈衝深度」，看條件相位、閘時間與能階間距。
模型是教學用的簡化，只用來比較趨勢。
"""
import math

S = 1 / math.sqrt(2)
KETS = ['00', '01', '10', '11']   # 左邊是 A，右邊是 B


def mat_vec(m, v):
    return [sum(m[i][j] * v[j] for j in range(4)) for i in range(4)]


def mat_mul(a, b):
    return [[sum(a[i][k] * b[k][j] for k in range(4)) for j in range(4)] for i in range(4)]


def kron(a, b):
    return [[a[i // 2][j // 2] * b[i % 2][j % 2] for j in range(4)] for i in range(4)]


I2 = [[1, 0], [0, 1]]
H2 = [[S, S], [S, -S]]
CZ = [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, -1]]
CNOT = [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 0, 1], [0, 0, 1, 0]]

print('一、CZ 只讓 |11⟩ 多一個負號')
for k, name in enumerate(KETS):
    v = [0, 0, 0, 0]
    v[k] = 1
    out = mat_vec(CZ, v)
    print(f'  CZ |{name}⟩ = {"−" if out[k] < 0 else "+"}|{name}⟩')
IH = kron(I2, H2)
built = mat_mul(mat_mul(IH, CZ), IH)
same = all(abs(built[i][j] - CNOT[i][j]) < 1e-12 for i in range(4) for j in range(4))
print(f'  (I⊗H)·CZ·(I⊗H) 等於 CNOT 嗎？ {same}')

print('\n二、交叉共振：B 從北極出發，轉 90°')
for a in (0, 1):
    ang = math.pi / 2 * (1 if a == 0 else -1)      # A=0 繞 +x、A=1 繞 −x（同動畫）
    y, z = -math.sin(ang), math.cos(ang)           # 北極 (0,0,1) 繞 x 轉 ang
    side = '−y（動畫畫面往左）' if y < 0 else '+y（動畫畫面往右）'
    print(f'  A = {a}：B 的布洛赫向量 (x, y, z) = (0.00, {y:+.2f}, {z:+.2f}) → 指向 {side}')

print('\n三、磁通調頻 CZ：改脈衝深度（05_twoqubit.js 的模型）')
FB, AL, G, FA0 = 5.0, -0.25, 0.015, 6.0   # GHz：B 的頻率、非諧性、耦合、A 的起點


def lower(fa):
    e11, e20 = fa + FB, 2 * fa + AL
    m, d = (e11 + e20) / 2, (e11 - e20) / 2
    return m - math.sqrt(d * d + 2 * G * G)


def phase(depth, tp):
    fmin = FA0 - depth * (FA0 - 5.25 + 0.02)
    def fa(t):
        r = min(1, t / (tp * 0.25), (tp - t) / (tp * 0.25))
        return FA0 - (FA0 - fmin) * math.sin(math.pi / 2 * max(0, r)) ** 2
    n, s = 400, 0.0
    for i in range(n):
        f = fa((i + 0.5) / n * tp)
        s += (lower(f) - (f + FB)) * tp / n
    return abs(2 * math.pi * s), fmin


print('  深度   A 最低頻率   找到 π 的時間   間距（|20⟩−|11⟩）')
for depth in (0.85, 0.90, 0.95):             # 改造區：試試 0.80、0.93
    best = min(range(20, 121), key=lambda t: abs(phase(depth, t)[0] - math.pi))
    ph, fmin = phase(depth, best)
    gap = (2 * fmin + AL - (fmin + FB)) * 1000
    note = '（120 ns 內湊不到 π）' if abs(ph - math.pi) > 0.1 else ''
    print(f'  {depth:.2f}   {fmin:.3f} GHz    {best:3d} ns {note}  {gap:4.0f} MHz')
print('  越靠近交叉點：閘越快，但間距越小、越容易洩漏到 |20⟩。')
