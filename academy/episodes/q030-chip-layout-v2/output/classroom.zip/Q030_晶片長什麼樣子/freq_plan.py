"""父子科技學院 量子電腦學程 Q030：一條饋線串四個讀取腔的頻率表檢查器。

不用安裝任何套件，只要 Python 3。執行：  python freq_plan.py
- 把你設計的四個讀取腔頻率（GHz）寫進 PLAN，執行後會檢查：
  1. 都在 6–8 GHz 之間（簡報 JJ_Microwave_Readout_Talk p27：λ/4 諧振腔 fr ≈ 6–8 GHz）
  2. 相鄰兩個至少隔 MIN_GAP（本課自訂 50 MHz；動畫讀數寫典型凹陷寬度、狀態偏移約 1–5 MHz）
- 也估算每個讀取腔蛇形線的總路程：λ/4 共振腔的頻率和路程成反比，
  以簡報「約 4 mm ↔ 約 7 GHz」為基準：L ≈ 4 mm × 7 GHz ÷ f（只是數量級，沒有考慮材料與實際佈局）。
- 參考：animations/js/scenes/08_chip.js（四個讀取腔 6.82、6.97、7.11、7.26 GHz）。
"""

PLAN = [6.40, 6.60, 6.80, 7.00]   # ← 改成你的四個頻率（GHz）
MIN_GAP = 0.050                     # 本課自訂的安全距離：50 MHz
SCENE = [6.82, 6.97, 7.11, 7.26]    # 動畫 index.html#chip 的四個讀取腔


def path_mm(f):
    """以「約 4 mm ↔ 約 7 GHz」換算的蛇形線總路程（mm）。"""
    return 4.0 * 7.0 / f


def check(plan, min_gap=MIN_GAP):
    """回傳 (是否通過, 相鄰間隔 MHz 清單, 問題清單)。"""
    fs = sorted(plan)
    gaps = [round((b - a) * 1000) for a, b in zip(fs, fs[1:])]
    problems = []
    for f in fs:
        if not 6.0 <= f <= 8.0:
            problems.append(f'{f:.2f} GHz 不在 6–8 GHz 之間')
    for (a, b), g in zip(zip(fs, fs[1:]), gaps):
        if g < min_gap * 1000:
            problems.append(f'{a:.2f} 和 {b:.2f} GHz 只差 {g} MHz，太接近')
    return (not problems), gaps, problems


def report(name, plan):
    ok, gaps, problems = check(plan)
    print(f'{name}：' + '、'.join(f'{f:.2f}' for f in sorted(plan)) + ' GHz')
    print('  相鄰間隔：' + '、'.join(f'{g} MHz' for g in gaps))
    print('  蛇形線路程：' + '、'.join(f'{path_mm(f):.2f} mm' for f in sorted(plan)))
    print('  結果：' + ('通過' if ok else '不通過 → ' + '；'.join(problems)))
    return ok


print('一、動畫 index.html#chip 的頻率表')
SCENE_OK = report('動畫', SCENE)
print()
print('二、你的頻率表')
PLAN_OK = report('我的設計', PLAN)
print()
print('三、太接近的例子：兩個讀取腔只差 1 MHz')
CLOSE_OK = report('太接近', [6.80, 6.801, 7.00, 7.20])
print()
D1 = path_mm(6.82) - path_mm(6.97)
D2 = path_mm(7.11) - path_mm(7.26)
print(f'四、頻率差 150 MHz，路程差多少？6.82→6.97 GHz：{D1:.3f} mm；7.11→7.26 GHz：{D2:.3f} mm（都不到 0.1 mm）')
