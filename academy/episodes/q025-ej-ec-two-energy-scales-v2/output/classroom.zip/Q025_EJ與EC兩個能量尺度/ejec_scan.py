"""父子科技學院 量子電腦學程 Q025：E_J／E_C 掃描（和動畫 transmon-3d.html#capacitor 同一套算法）。

不用安裝任何套件，只要 Python 3。執行：  python ejec_scan.py
- 約瑟夫森能量 E_J/h 固定 15 GHz；充電能量 E_C/h = 19.37 GHz ÷ 電容（fF）（e²/2hC）。
- 能量公式 H = 4E_C(n − n_g)² − E_J cos φ 寫成電荷基底的三對角矩陣，用二分法求最低三個能階；
  在背景電荷 n_g = 0 與 0.5 各算一次（和動畫的 capStats 一樣）：
  非諧性 α 取兩點的平均，電荷色散 = 兩點的 f01 相差多少。
- 參考：學程簡報 JJ_Microwave_Readout_Talk p15、p19；transmon.pptx p15；維基百科 Transmon。
"""
EJ = 15.0             # GHz（約瑟夫森能量 E_J/h，動畫的設定）
EC_PER_FF = 19.37     # GHz·fF（E_C/h = 19.37 / C）


def levels(ej, ec, ng, k=3, n_max=25):
    """電荷基底 H 的最低 k 個能階（單位 GHz），Sturm 序列二分法。"""
    d = [4 * ec * (n - ng) ** 2 for n in range(-n_max, n_max + 1)]
    e2 = (ej / 2) ** 2

    def count(x):
        q = d[0] - x
        c = 1 if q < 0 else 0
        for di in d[1:]:
            q = di - x - e2 / (q if q != 0 else 1e-300)
            if q < 0:
                c += 1
        return c

    out = []
    for j in range(k):
        lo, hi = -ej - 1, 4 * ec * (n_max + 1) ** 2 + ej + 1
        for _ in range(90):
            m = (lo + hi) / 2
            if count(m) > j:
                hi = m
            else:
                lo = m
        out.append((lo + hi) / 2)
    return out


def stats(c_ff):
    ec = EC_PER_FF / c_ff
    a, b = levels(EJ, ec, 0.0), levels(EJ, ec, 0.5)
    fa, fb = a[1] - a[0], b[1] - b[0]
    alpha = ((a[2] - 2 * a[1] + a[0]) + (b[2] - 2 * b[1] + b[0])) / 2
    return {'C': c_ff, 'EC': ec, 'ratio': EJ / ec, 'f01': (fa + fb) / 2, 'alpha': alpha, 'disp': abs(fa - fb)}


def fix(x, d):
    """像 JavaScript 的 toFixed：剛好在一半時進位（Python 的 format 會取偶數）。"""
    from decimal import Decimal, ROUND_HALF_UP
    return str(Decimal(x).quantize(Decimal(1).scaleb(-d), rounding=ROUND_HALF_UP))


def hz(g):
    """GHz → 好讀的單位（和動畫的 fmtF 寫法一樣）。"""
    v = g * 1e9
    if v >= 1e9:
        return fix(g, 2) + ' GHz'
    if v >= 1e6:
        return fix(v / 1e6, 0 if v >= 1e8 else 1) + ' MHz'
    if v >= 1e3:
        return fix(v / 1e3, 1) + ' kHz'
    return '< 0.1 Hz' if v < 0.1 else fix(v, 1) + ' Hz'


def verdict(r):
    if r < 20:
        return '電荷雜訊主導'
    return 'transmon 區間' if r <= 120 else '非諧性偏小，閘需放慢'


SCAN = [10, 20, 30, 50, 77.5, 100, 150, 200]
ROWS = [stats(c) for c in SCAN]
print('電容      E_C        E_J/E_C   f01         非諧性 α     電荷色散     判斷')
for s in ROWS:
    print(f"{s['C']:6.1f} fF  {hz(s['EC']):>9}  {s['ratio']:6.1f}   {hz(s['f01']):>9}   −{hz(abs(s['alpha'])):>9}   "
          f"{hz(s['disp']):>10}   {verdict(s['ratio'])}")

print()
print('折衷點的例子：非諧性至少 200 MHz、電荷色散低於 10 kHz')
ALL = [stats(c / 2) for c in range(10, 401)]          # 5–200 fF，每 0.5 fF（和動畫滑桿一樣）
OK = [s['C'] for s in ALL if abs(s['alpha']) >= 0.2 and s['disp'] < 1e-5]
LOW, HIGH = min(OK), max(OK)
print(f'  兩條都符合的電容：{LOW} – {HIGH} fF（比值 {stats(LOW)["ratio"]:.1f} – {stats(HIGH)["ratio"]:.1f}）')
print('  電容再小：電荷色散超過 10 kHz；電容再大：非諧性不到 200 MHz。')
