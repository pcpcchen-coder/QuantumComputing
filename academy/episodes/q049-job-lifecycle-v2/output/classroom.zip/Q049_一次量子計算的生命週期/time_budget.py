"""父子科技學院 量子電腦學程 Q049：一次量子計算的生命週期——時間預算與時間機器（只用 Python 標準函式庫）

執行：python time_budget.py
數字是學程動畫 operation.html#workflow 與簡報整理的典型量級（依機型、後端與當天負載而異）。
"""
SLOW = 1_000_000                      # 時間機器：放慢一百萬倍（1 微秒 → 1 秒）


def shot_us(depth=20, active_reset=False):
    reset = 2.0 if active_reset else 250.0   # 主動重置約 2 μs；被動等待約 250 μs
    gates = depth * 0.1                      # 每一層閘約 0.1 μs
    meas = 1.0                               # 讀取約 1 μs
    return reset, gates, meas, reset + gates + meas


def pretty(sec):
    for unit, s in (('年', 365.25 * 86400), ('天', 86400), ('小時', 3600), ('分鐘', 60), ('秒', 1),
                    ('毫秒', 1e-3), ('微秒', 1e-6), ('奈秒', 1e-9)):
        if sec >= s:
            return f'{sec / s:.3g} {unit}'
    return f'{sec:.3g} 秒'


for label, depth, active, shots in [('預設（被動重置）', 20, False, 1000),
                                    ('shots 改成十萬', 20, False, 100_000),
                                    ('主動重置＋十萬 shots', 20, True, 100_000),
                                    ('主動重置＋十萬 shots＋深度 1000 層', 1000, True, 100_000)]:
    r, g, m, s = shot_us(depth, active)
    job = s * shots / 1e6
    print(f'{label}：每 shot {s:.1f} μs（重置 {r / s:.1%}、閘 {g / s:.1%}、讀取 {m / s:.1%}）× {shots:,} = {pretty(job)}；'
          f'放慢後 {pretty(job * SLOW)}')

# 改造區：量子線路以外的等待（自己填，單位：秒）
waits = {'排隊': 60, '轉譯與脈衝排程': 5, '載入波形': 2, '網路往返': 1}
quantum = shot_us()[3] * 1000 / 1e6
total = sum(waits.values()) + quantum
print(f'\n全部合計 {pretty(total)}，晶片上只佔 {quantum / total:.2%}')
for k, v in waits.items():
    print(f'  {k}：{pretty(v)}，放慢一百萬倍後 {pretty(v * SLOW)}')
