"""父子科技學院 量子電腦學程 Q119：範例 6 Deutsch——紅綠球搖獎機（純 Python，不需安裝任何套件）

執行：  python deutsch_lab.py
它印出：
  一、古典偵探搖球：兩顆球要搖幾次？50 顆、8 顆球運氣最差要搖幾次？允許一點點出錯時，隨機搖 10 顆會猜錯多少？
  二、德意志線路：四種黑盒子各問一次（和 basic-circuits.html#deutsch 相同），每一步的四個振幅與量到 1 的機率
  三、8 顆球的版本（3 個輸入位元）：每條路蓋的正負號、|000⟩ 的振幅，以及最後量到哪些結果
  四、改造區：自己設計 8 顆球的顏色，先預測，再執行
紅色記 0、綠色記 1。第 x 顆球的顏色就是 f(x)。
位元字串寫成 |q1 q0⟩：最右邊那位是 q0（輸入），左邊是 q1（輔助位元），和 Qiskit、basic-circuits.html 一樣。
"""
import random
from math import comb, sqrt

R2 = 1 / sqrt(2)

# 兩顆球的四種黑盒子：(名字, 第 1 次搖 f(0), 第 2 次搖 f(1))
BOXES = [('f(x)=0   兩顆都紅', 0, 0), ('f(x)=1   兩顆都綠', 1, 1),
         ('f(x)=x   一紅一綠', 0, 1), ('f(x)=1−x 一綠一紅', 1, 0)]


def kind(colors):
    """顏色清單 → 常數、平衡，或「沒守承諾」"""
    g = sum(colors)
    return '常數' if g in (0, len(colors)) else '平衡' if 2 * g == len(colors) else '沒守承諾'


def worst_case(n):
    """n 顆球（一半一半或全同色），搖出不放回，保證知道答案最多要搖幾顆：一顆一顆試所有可能的排列太多，
    用道理算：運氣最差時前面一直同色；同色的球最多 n/2 顆，所以第 n/2 + 1 顆一定揭曉。這裡再用 n = 8 全部排列驗證一次。"""
    return n // 2 + 1


def brute_worst(n):
    """n 顆球全部可能的放法都試一遍：每次搖到「已經能確定」為止，記下最多搖了幾顆"""
    from itertools import permutations
    worst = 0
    machines = [tuple([0] * n), tuple([1] * n)] + list(set(permutations([0] * (n // 2) + [1] * (n // 2))))
    for m in machines:
        seen = set()
        for k, c in enumerate(m, 1):
            seen.add(c)
            if len(seen) == 2 or k == n // 2 + 1:      # 看到兩種顏色 → 平衡；同色已超過一半 → 常數
                worst = max(worst, k)
                break
    return worst


def deutsch(f0, f1):
    """兩顆位元的德意志線路，回傳每一步之後的四個振幅（順序 |00⟩ |01⟩ |10⟩ |11⟩，字串是 |q1 q0⟩）"""
    s = [1.0, 0.0, 0.0, 0.0]
    out = []
    s = [s[i ^ 2] for i in range(4)]                                   # ① X(q1)：輔助位元翻成 1
    out.append(('①翻轉輔助', s))
    s = h(h(s, 0), 1)                                                  # ② 兩顆都做 H
    out.append(('②兩顆哈達瑪', s))
    f = (f0, f1)
    s = [s[i ^ 2] if f[i & 1] else s[i] for i in range(4)]             # ③ 黑盒：|x⟩|y⟩ → |x⟩|y ⊕ f(x)⟩
    out.append(('③問黑盒一次', s))
    s = h(s, 0)                                                        # ④ 輸入位元再做 H
    out.append(('④輸入哈達瑪', s))
    return out


def h(s, q):
    m, new = 1 << q, s[:]
    for i in range(len(s)):
        if not i & m:
            a, b = s[i], s[i | m]
            new[i], new[i | m] = (a + b) * R2, (a - b) * R2
    return new


def p_q0_is_1(s):
    return sum(a * a for i, a in enumerate(s) if i & 1)


def eight(colors):
    """8 顆球（3 個輸入位元）：H⊗3 → 每條路蓋 (−1)^f(x) → H⊗3。回傳每個結果 y 的振幅"""
    n = len(colors)
    return [sum((-1) ** (colors[x] + bin(x & y).count('1')) for x in range(n)) / n for y in range(n)]


def show(v):
    return ' '.join(f'{a + 0.0:+.2f}'.replace('-', '−') for a in v)


if __name__ == '__main__':
    print('一、古典偵探搖球')
    print('  兩顆球：搖 1 次只看到一個顏色，什麼都不能判斷；四種黑盒子都要搖 2 次')
    for n in (2, 8, 50, 1_000_000):
        print(f'  {n:>9,} 顆球：運氣最差要搖 {worst_case(n):,} 次')
    print(f'  8 顆球把 72 種放法全部試一遍，最多搖了 {brute_worst(8)} 次（和上面相同）')
    k = 10
    print(f'  允許出錯：隨機搖 {k} 顆（每次放回），全部同色就判常數')
    print(f'    一半一半的機器被誤判成常數的機率 2 × (1/2)^{k} = {2 * 0.5 ** k:.5f}（約 {2 * 0.5 ** k:.1%}）')
    print(f'    50 顆球、搖出不放回時：2 × C(25,{k}) / C(50,{k}) = {2 * comb(25, k) / comb(50, k):.5f}')
    rng = random.Random(1119)
    trials = 100_000
    wrong = sum(len({rng.random() < 0.5 for _ in range(k)}) == 1 for _ in range(trials))
    print(f'    真的模擬 {trials:,} 台一半一半的機器（random 種子 1119）：誤判 {wrong} 台（{wrong / trials:.3%}）')

    print('二、德意志線路：四種黑盒子各問一次（振幅順序 |00⟩ |01⟩ |10⟩ |11⟩，字串 |q1 q0⟩）')
    for name, f0, f1 in BOXES:
        steps = deutsch(f0, f1)
        print(f'  {name}（{kind([f0, f1])}）')
        for tag, s in steps:
            print(f'    {tag}：{show(s)}   量 q0 得到 1 的機率 {p_q0_is_1(s):.2f}')
        verdict = '常數' if p_q0_is_1(steps[-1][1]) < 0.5 else '平衡'
        print(f'    判讀：q0 = {0 if verdict == "常數" else 1} → {verdict} {"✓" if verdict == kind([f0, f1]) else "✗"}（只問了黑盒子 1 次）')

    print('三、8 顆球的版本：3 個輸入位元、8 條路')
    MACHINES = [('常數 全紅', [0] * 8), ('常數 全綠', [1] * 8),
                ('平衡 紅綠紅綠紅綠紅綠', [0, 1] * 4), ('平衡 紅綠綠紅綠紅紅綠', [0, 1, 1, 0, 1, 0, 0, 1]),
                ('沒守承諾 5 綠 3 紅', [1, 1, 0, 1, 1, 0, 1, 0])]
    for name, c in MACHINES:
        amps = eight(c)
        signs = ''.join('+' if x == 0 else '−' for x in c)
        hits = '、'.join(f'{y:03b}：{a * a:.1%}' for y, a in enumerate(amps) if abs(a) > 1e-9)
        print(f'  {name}')
        print(f'    每條路的章 {signs}   |000⟩ 的振幅 {amps[0]:+.3f} → P(000) = {amps[0] ** 2:.3f}')
        print(f'    最後量到：{hits}   判讀：{"全 0 → 常數" if amps[0] ** 2 > 0.999 else "一定有 1 → 平衡" if amps[0] ** 2 < 1e-9 else "有時全 0、有時有 1：判不準"}')

    # 四、改造區：設計自己的 8 顆球。紅寫 0、綠寫 1，先預測 P(000)，再執行
    MY_BALLS = [0, 0, 1, 1, 1, 1, 0, 0]
    amps = eight(MY_BALLS)
    print('四、改造區')
    print(f'  我的 8 顆球 {MY_BALLS}（{kind(MY_BALLS)}）   正號 {MY_BALLS.count(0)} 條、負號 {MY_BALLS.count(1)} 條')
    print(f'    |000⟩ 的振幅 = ({MY_BALLS.count(0)} − {MY_BALLS.count(1)}) / 8 = {amps[0]:+.3f} → P(000) = {amps[0] ** 2:.3f}')
    print('    最後量到：' + '、'.join(f'{y:03b}：{a * a:.1%}' for y, a in enumerate(amps) if abs(a) > 1e-9))
