"""父子科技學院 量子電腦學程 Q119：用本機 Qiskit 重現德意志演算法與 8 顆球的版本（選用，不需要帳號）

安裝（只要一次）：  pip install qiskit
執行：              python qiskit_check.py
"""
from qiskit import QuantumCircuit
from qiskit.primitives import StatevectorSampler


def deutsch(box):
    """兩顆位元：q0 輸入、q1 輔助；box 是黑盒裡的閘（和 basic-circuits.html#deutsch 相同）"""
    qc = QuantumCircuit(2, 1)
    qc.x(1)
    qc.h([0, 1])
    if box in ('x', '1-x'):
        qc.cx(0, 1)
    if box in ('1', '1-x'):
        qc.x(1)
    qc.h(0)
    qc.measure(0, 0)
    return qc


def eight(colors):
    """8 顆球：3 個輸入位元 q0–q2，輔助位元 q3。第 x 顆是綠色（1）就讓那一條路翻轉輔助位元"""
    qc = QuantumCircuit(4, 3)
    qc.x(3)
    qc.h(range(4))
    for x, c in enumerate(colors):
        if c:
            ctrl = [q for q in range(3) if not (x >> q) & 1]
            if ctrl:
                qc.x(ctrl)
            qc.mcx([0, 1, 2], 3)
            if ctrl:
                qc.x(ctrl)
    qc.h(range(3))
    qc.measure(range(3), range(3))
    return qc


sampler = StatevectorSampler(seed=2026)
for box, name in (('0', 'f(x)=0'), ('1', 'f(x)=1'), ('x', 'f(x)=x'), ('1-x', 'f(x)=1−x')):
    counts = sampler.run([deutsch(box)], shots=1000).result()[0].data.c.get_counts()
    print(f'{name:<8} 量 q0 1000 次：{dict(sorted(counts.items()))}')
for name, c in (('常數 全綠', [1] * 8), ('平衡 紅綠紅綠紅綠紅綠', [0, 1] * 4), ('平衡 紅綠綠紅綠紅紅綠', [0, 1, 1, 0, 1, 0, 0, 1]),
                ('沒守承諾 5 綠 3 紅', [1, 1, 0, 1, 1, 0, 1, 0])):
    counts = sampler.run([eight(c)], shots=1000).result()[0].data.c.get_counts()
    print(f'{name}：量 1000 次，全 0（000）出現 {counts.get("000", 0)} 次；最多的是 {max(counts, key=counts.get)}')
print(deutsch('1-x').draw())
