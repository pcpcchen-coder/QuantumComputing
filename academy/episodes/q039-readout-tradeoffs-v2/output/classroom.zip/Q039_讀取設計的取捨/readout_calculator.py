"""父子科技學院 量子電腦學程 Q039：讀取參數計算器。

不用安裝任何套件，只要 Python 3。執行：  python readout_calculator.py
想試自己的參數，改最下面 MY_DESIGN 那一行的數字再執行一次。

公式（學程簡報 JJ_Microwave_Readout_Talk p35、p37 與學程筆記 notes/dispersive-readout.md §2.5、§3；頻率都是「除以 2π」以後的數字）：
- 失諧 Δ = f_q − f_r
- 色散位移 χ = g² α / [Δ (Δ + α)]（兩個狀態的讀取腔頻率差 2χ）
- 建議線寬 κ = 2|χ|（2χ ≈ κ 時兩個狀態分得最開）
- 臨界光子數 n_crit = Δ² / (4 g²)
- 珀塞爾漏能 γ_P = κ (g/Δ)²，珀塞爾限制的 T₁ 上限 = 1 / (2π γ_P)
- 讀取腔響應時間約 1 / (2π κ)；簡報 p37 的讀取時間是它的好幾倍（約 300–600 ns 對 145 ns）
- 兩個狀態在同相正交平面上的距離（探測在正中間）= 2x / (1 + x²)，x = 2χ/κ（最大值 1 在 x = 1）
- 珀塞爾濾波器：學程簡報和筆記沒有給它能把漏能壓低幾倍；這裡的 FILTER = 100 是練習用的假設值，不是某個濾波器的規格。
"""
import math

FILTER = 100  # 假設：濾波器把珀塞爾漏能壓低 100 倍（練習用）


def design(fr, fq, g, alpha, kappa=None, filt=1):
    """fr、fq、g、alpha 單位 GHz（g = 0.1 就是 100 MHz）；kappa 不給就用 2|χ|；filt = 濾波器壓低倍數。"""
    D = fq - fr
    chi = g ** 2 * alpha / (D * (D + alpha))
    k = 2 * abs(chi) if kappa is None else kappa
    x = 2 * abs(chi) / k
    gp = k * (g / D) ** 2 / filt
    return {'chi_MHz': chi * 1e3, 'kappa_MHz': k * 1e3, 'ratio_2chi_kappa': x, 'distance': 2 * x / (1 + x * x),
            'n_crit': D ** 2 / (4 * g ** 2), 'T1_limit_us': 1 / (2 * math.pi * gp * 1e9) * 1e6,
            'one_over_kappa_ns': 1 / (2 * math.pi * k * 1e9) * 1e9}


def show(name, d):
    print(f'  {name}')
    print(f"    色散位移 χ = {d['chi_MHz']:.3f} MHz，線寬 κ = {d['kappa_MHz']:.3f} MHz，2χ/κ = {d['ratio_2chi_kappa']:.2f}，距離 = {d['distance']:.3f}")
    print(f"    臨界光子數 = {d['n_crit']:.0f}，珀塞爾限制的 T₁ 上限 = {d['T1_limit_us']:.0f} μs，1/κ = {d['one_over_kappa_ns']:.0f} ns")


print('一、簡報 p37 的範例：讀取腔 7 GHz、量子位元 5 GHz、g = 100 MHz、α = −250 MHz')
BASE = design(7.0, 5.0, 0.100, -0.250)
show('沒有濾波器、κ = 2|χ|', BASE)

print()
print('二、色散位移不變，只改線寬')
K = BASE['kappa_MHz'] / 1e3
DOUBLE = design(7.0, 5.0, 0.100, -0.250, kappa=2 * K)
HALF = design(7.0, 5.0, 0.100, -0.250, kappa=K / 2)
show('線寬加倍（讀得快）', DOUBLE)
show('線寬減半（讀得慢）', HALF)

print()
print('三、沒有濾波器：維持 κ = 2|χ|，把 g 調小，直到 T₁ 上限超過 500 μs')
NOFILTER = None
for g_mhz in range(100, 20, -1):
    d = design(7.0, 5.0, g_mhz / 1000, -0.250)
    if d['T1_limit_us'] >= 500:
        NOFILTER = (g_mhz, d)
        break
show(f'g = {NOFILTER[0]} MHz', NOFILTER[1])
print(f"    讀取腔響應時間從 {BASE['one_over_kappa_ns']:.0f} ns 變成 {NOFILTER[1]['one_over_kappa_ns']:.0f} ns，讀取變慢")

print()
print(f'四、有濾波器（假設把漏能壓低 {FILTER} 倍）：g = 100 MHz')
WITHF = design(7.0, 5.0, 0.100, -0.250, filt=FILTER)
WITHF2 = design(7.0, 5.0, 0.100, -0.250, kappa=2 * K, filt=FILTER)
show('κ = 2|χ|', WITHF)
show('κ 加倍（更快，但 2χ/κ 變 0.5）', WITHF2)

print()
print('五、我的設計（改這一行）')
MY_DESIGN = design(7.0, 5.0, 0.100, -0.250)
show('MY_DESIGN', MY_DESIGN)
