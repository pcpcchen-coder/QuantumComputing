"""父子科技學院 量子電腦學程 Q114：用本機 Qiskit 重現 |+⟩、|−⟩（選用，不需要帳號）

安裝（只要一次）：  pip install qiskit
執行：              python qiskit_check.py
"""
from qiskit import QuantumCircuit
from qiskit.primitives import StatevectorSampler
from qiskit.quantum_info import Statevector


def report(name, qc):
    sv = Statevector.from_instruction(qc)
    m = qc.copy()
    m.measure_all()
    counts = StatevectorSampler(seed=2026).run([m], shots=1000).result()[0].data.meas.get_counts()
    print(name, '振幅', [round(float(a.real), 3) for a in sv.data],
          '機率', {str(k): round(float(v), 3) for k, v in sv.probabilities_dict().items()}, '量測 1000 次', dict(sorted(counts.items())))


plus = QuantumCircuit(1)
plus.h(0)                    # |0⟩ → 哈達瑪閘 → |+⟩
minus = QuantumCircuit(1)
minus.x(0)                   # 先用翻轉閘準備 |1⟩
minus.h(0)                   # |1⟩ → 哈達瑪閘 → |−⟩
report('|+⟩', plus)
report('|−⟩', minus)

for name, qc in (('|+⟩ 再加 H', plus), ('|−⟩ 再加 H', minus)):
    qc2 = qc.copy()
    qc2.h(0)                 # 改造：再加一個哈達瑪閘
    report(name, qc2)
print(minus.draw())
