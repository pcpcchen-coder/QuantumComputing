"""父子科技學院 量子電腦學程 Q114：範例 1 疊加——量子硬幣與 |+⟩、|−⟩（純 Python，不需安裝任何套件）

執行：  python coin.py
它用一個很小的一顆位元模擬器（只認得 H、X、Z 三種閘），印出：
  一、兩種疊加態的振幅與機率：|0⟩ → H 得 |+⟩；|1⟩（先 X）→ H 得 |−⟩
  二、各量測 1000 次的次數（用固定的亂數種子，所以每次執行結果相同；真實量測每次都不同）
  三、盲測：電腦偷偷選 |+⟩ 或 |−⟩，只給你看次數
  四、改造區：再加一個 H 會怎樣？
"""
import random
from math import sqrt

R2 = 1 / sqrt(2)


def run(gates):
    """一顆位元從 |0⟩ 出發，由左往右依序做 gates（'h'、'x'、'z'），回傳 [|0⟩ 的振幅, |1⟩ 的振幅]"""
    a, b = 1.0, 0.0
    for g in gates:
        if g == 'h':
            a, b = (a + b) * R2, (a - b) * R2
        elif g == 'x':
            a, b = b, a
        elif g == 'z':
            b = -b
        else:
            raise ValueError('只認得 h、x、z：' + g)
    return [a, b]


def amp(v):
    return '0' if abs(v) < 1e-9 else ('+' if v > 0 else '−') + f'{abs(v):.3f}'


def show(title, gates):
    s = run(gates)
    print(f'  {title:<14}' + '  '.join(f'|{i}⟩ {amp(v)}（{v * v * 100:.0f}%）' for i, v in enumerate(s)))


def shots(gates, n, rng):
    """量測 n 次：每次以機率 振幅² 得到 0 或 1，回傳 [0 的次數, 1 的次數]"""
    p0 = run(gates)[0] ** 2
    c0 = sum(rng.random() < p0 for _ in range(n))
    return [c0, n - c0]


def name(gates):
    return ' → '.join(g.upper() for g in gates) or '（沒有閘）'


PLUS, MINUS = ['h'], ['x', 'h']

if __name__ == '__main__':
    rng = random.Random(1114)   # 固定種子：教材的輸出才對得起來；改成 random.Random() 就每次不同
    print('一、兩種疊加態（機率 = 振幅²）')
    show('|+⟩ = H|0⟩', PLUS)
    show('|−⟩ = H|1⟩', MINUS)
    print('二、各量測 1000 次')
    for title, g in (('|+⟩', PLUS), ('|−⟩', MINUS)):
        c = shots(g, 1000, rng)
        print(f'  {title:<6}0 → {c[0]} 次  1 → {c[1]} 次')
    print('三、盲測 5 回合（先看次數猜，再看答案）')
    for r in range(1, 6):
        secret = rng.choice(['|+⟩', '|−⟩'])
        c = shots(PLUS if secret == '|+⟩' else MINUS, 1000, rng)
        print(f'  第 {r} 回  0 → {c[0]} 次  1 → {c[1]} 次    答案：{secret}')

    # 四、改造區：先預測，再執行。閘寫成 'h'、'x'、'z'，由左往右排
    MY_CIRCUITS = [['h', 'h'], ['x', 'h', 'h']]
    print('四、改造區：再加一個 H')
    for g in MY_CIRCUITS:
        show(name(g), g)
