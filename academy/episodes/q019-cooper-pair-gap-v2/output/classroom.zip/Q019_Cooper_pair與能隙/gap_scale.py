"""父子科技學院 量子電腦學程 Q019：鋁的能隙有多大？——熱能、量子位元、能隙比一比。

不用安裝任何套件，只要 Python 3。執行：  python gap_scale.py
能隙用 BCS 理論的關係 Δ(0) ≈ 1.764 k_B T_c（維基百科 BCS theory），鋁的臨界溫度 T_c ≈ 1.2 K（學程簡報 p7）。
最後一段的配對比例用學程動畫 animations/index.html#cooper（js/scenes/02_cooper.js）裡的示意公式 1 − (T/T_c)⁴，不是真實材料的曲線。
"""
H = 6.62607015e-34    # 普朗克常數（J·s）
KB = 1.380649e-23     # 波茲曼常數（J/K）
E = 1.602176634e-19   # 基本電荷（C），用來把焦耳換成電子伏特

TC = 1.2              # 鋁的臨界溫度（K）
T_CHIP = 0.010        # 量子晶片工作溫度（K），約 10 mK
F_QUBIT = 5e9         # 量子位元頻率（Hz），約 5 GHz

gap = 2 * 1.764 * KB * TC          # 拆散一對需要的能量 2Δ（J）
GAP_GHZ = gap / H / 1e9
QUBIT_GHZ = F_QUBIT / 1e9
THERMAL_GHZ = KB * T_CHIP / H / 1e9

print(f'能隙 2Δ        ≈ {GAP_GHZ:6.1f} GHz（{gap / E * 1e6:.0f} μeV）')
print(f'量子位元 f01   ≈ {QUBIT_GHZ:6.1f} GHz（{H * F_QUBIT / E * 1e6:.0f} μeV）')
print(f'熱能 k_B T（10 mK）≈ {THERMAL_GHZ:6.2f} GHz（{KB * T_CHIP / E * 1e6:.2f} μeV）')
RATIO_GAP_QUBIT = GAP_GHZ / QUBIT_GHZ
RATIO_QUBIT_THERMAL = QUBIT_GHZ / THERMAL_GHZ
RATIO_TC_CHIP = TC / T_CHIP
print(f'能隙 ÷ 量子位元 ≈ {RATIO_GAP_QUBIT:.1f} 倍；量子位元 ÷ 熱能 ≈ {RATIO_QUBIT_THERMAL:.0f} 倍；臨界溫度 ÷ 晶片溫度 = {RATIO_TC_CHIP:.0f} 倍')
print('結論：微波（量子位元）和熱都跨不過能隙，拆不散電子對。')

print()
print('動畫的示意公式：配對比例 = 1 − (T / Tc)⁴（只在 T < Tc 時；10 對電子）')
TABLE = []
for t in (2.5, 1.2, 1.1, 1.0, 0.8, 0.6, 0.3):
    frac = 1 - (t / TC) ** 4 if t < TC else 0.0
    TABLE.append((t, round(frac * 100), round(frac * 10)))
    print(f'  T = {t:4.2f} K  配對比例 ≈ {frac * 100:3.0f} %  成對的有 {round(frac * 10):2d} 對')
