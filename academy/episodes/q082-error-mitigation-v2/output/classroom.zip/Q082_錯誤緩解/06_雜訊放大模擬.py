"""零雜訊外插的本機模擬器（父子科技學院 Q082）。只用 Python 標準函式庫：python3 06_雜訊放大模擬.py

模型和學程動畫 operation.html#circuit 的「加入雜訊」相同：
兩位元 Grover 線路共 12 個閘，理想上一定量到 11。每個閘的錯誤率 = 1% × 倍數；
只要有任何一個閘出錯（機率 1 − (1 − p)^12），這一次就變成 00、01、10、11 隨機一個。
"""
import math
import random

GATES = 12
SHOTS = 1000          # 改大一點，誤差棒就變小
READOUT = 0.0         # 進階：改成 0.03，看看外插的答案會停在哪裡
SEED = None           # 想讓每次結果一樣，就填一個整數


def run(scale, rng):
    p = 0.01 * scale
    hit = 0
    for _ in range(SHOTS):
        k = 3                                            # 理想答案 11
        if rng.random() < 1 - (1 - p) ** GATES:
            k = rng.randrange(4)
        for bit in (1, 2):
            if rng.random() < READOUT:
                k ^= bit
        hit += k == 3
    y = hit / SHOTS
    return y, math.sqrt(y * (1 - y) / SHOTS)


rng = random.Random(SEED)
xs = [1, 2, 3]
pts = [run(x, rng) for x in xs]
for x, (y, s) in zip(xs, pts):
    print(f'雜訊 {x} 倍：量到 11 的比例 = {y:.3f} ± {s:.3f}')
ys = [y for y, _ in pts]
mx, my = 2, sum(ys) / 3
slope = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / 2
lin = my - slope * mx
quad = 3 * ys[0] - 3 * ys[1] + ys[2]
sl = math.sqrt(sum(((14 - 6 * x) / 6) ** 2 * s ** 2 for x, (_, s) in zip(xs, pts)))
sq = math.sqrt(9 * pts[0][1] ** 2 + 9 * pts[1][1] ** 2 + pts[2][1] ** 2)
print(f'直線外插到 0 倍：{lin:.3f} ± {sl:.3f}')
print(f'彎曲線（穿過三點）外插到 0 倍：{quad:.3f} ± {sq:.3f}')
y0, s0 = run(0, rng)
print(f'揭曉：把雜訊關掉（0 倍）跑出來 = {y0:.3f}')
