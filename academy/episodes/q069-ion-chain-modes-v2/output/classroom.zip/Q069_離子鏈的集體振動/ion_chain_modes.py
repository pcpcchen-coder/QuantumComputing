"""父子科技學院 量子電腦學程 Q069：離子鏈的正規模（只用 Python 內建功能，不需要安裝套件）

和動畫 atoms.html#modes 用同一組方程：長度以 ℓ = (e²/4πε₀mω_z²)^(1/3) 為單位、頻率以軸向頻率 ω_z 為單位。
執行：python ion_chain_modes.py          （預設：頻率比 ω_r/ω_z = 5）
      python ion_chain_modes.py 10       （改頻率比）
"""
import math
import sys


def hessian(x):
    n = len(x)
    H = [[0.0] * n for _ in range(n)]
    for i in range(n):
        s = 1.0
        for j in range(n):
            if j != i:
                c = 2.0 / abs(x[i] - x[j]) ** 3
                s += c
                H[i][j] = -c
        H[i][i] = s
    return H


def solve_linear(M, b):
    n = len(b)
    M = [r[:] for r in M]
    b = b[:]
    for c in range(n):
        p = max(range(c, n), key=lambda r: abs(M[r][c]))
        M[c], M[p] = M[p], M[c]
        b[c], b[p] = b[p], b[c]
        for r in range(c + 1, n):
            f = M[r][c] / M[c][c]
            for k in range(c, n):
                M[r][k] -= f * M[c][k]
            b[r] -= f * b[c]
    x = [0.0] * n
    for r in range(n - 1, -1, -1):
        x[r] = (b[r] - sum(M[r][k] * x[k] for k in range(r + 1, n))) / M[r][r]
    return x


def eigenvalues(A):
    """對稱矩陣的 Jacobi 旋轉法，回傳由小到大的特徵值。"""
    n = len(A)
    a = [r[:] for r in A]
    for _ in range(100):
        off = sum(a[p][q] ** 2 for p in range(n) for q in range(p + 1, n))
        if off < 1e-22:
            break
        for p in range(n):
            for q in range(p + 1, n):
                if abs(a[p][q]) < 1e-15:
                    continue
                th = (a[q][q] - a[p][p]) / (2 * a[p][q])
                t = math.copysign(1.0, th) / (abs(th) + math.sqrt(th * th + 1))
                c = 1 / math.sqrt(t * t + 1)
                s = t * c
                for k in range(n):
                    akp, akq = a[k][p], a[k][q]
                    a[k][p], a[k][q] = c * akp - s * akq, s * akp + c * akq
                for k in range(n):
                    apk, aqk = a[p][k], a[q][k]
                    a[p][k], a[q][k] = c * apk - s * aqk, s * apk + c * aqk
    return sorted(a[i][i] for i in range(n))


def chain(n, ratio):
    # 平衡位置：牛頓法解 u_i = Σ sgn(u_i − u_j)/(u_i − u_j)²
    u = [(i - (n - 1) / 2) * (2.2 / n ** 0.44) for i in range(n)]
    for _ in range(200):
        g = [u[i] - sum(math.copysign(1.0, u[i] - u[j]) / (u[i] - u[j]) ** 2 for j in range(n) if j != i) for i in range(n)]
        d = solve_linear(hessian(u), g)
        u = [x - dx for x, dx in zip(u, d)]
        if max(abs(v) for v in d) < 1e-12:
            break
    A = hessian(u)
    axial = [math.sqrt(v) for v in eigenvalues(A)]
    R = [[(ratio ** 2 - (A[i][j] - 1) / 2) if i == j else -A[i][j] / 2 for j in range(n)] for i in range(n)]
    rv = eigenvalues(R)
    radial = [math.sqrt(v) if v > 0 else float('nan') for v in rv]
    return u, axial, radial, rv[0] <= 0


if __name__ == '__main__':
    ratio = float(sys.argv[1]) if len(sys.argv) > 1 else 5.0
    print(f'頻率比 ω_r/ω_z = {ratio}（頻率單位：軸向頻率 ω_z）')
    print('離子數 | 質心 | 呼吸 | 最高軸向 | 徑向質心 | 最低徑向 | 相鄰徑向最小間距')
    for n in range(2, 13):
        u, ax, rad, zig = chain(n, ratio)
        ok = [w for w in rad if w == w]
        gap = min(abs(ok[i] - ok[i - 1]) for i in range(1, len(ok))) if len(ok) > 1 else 0
        low = '不穩定（鋸齒形）' if zig else f'{min(rad):.3f}'
        print(f'{n:>4}   | {ax[0]:.3f} | {ax[1]:.3f} | {ax[-1]:.3f}    | {max(ok):.3f}    | {low} | {gap:.3f}')
    u, ax, rad, zig = chain(5, ratio)
    print('五顆離子的平衡位置：', ', '.join(f'{x:+.3f}' for x in u))
    print('相鄰間距（中間密、兩端疏）：', ', '.join(f'{u[i + 1] - u[i]:.3f}' for i in range(4)))
