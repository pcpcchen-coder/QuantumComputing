"""父子科技學院 量子電腦學程 Q056：轉譯：邏輯線路到硬體 的路由裁判（只用 Python 標準函式庫）

執行：python routing_lab.py
對每一張題卡、每一張耦合圖，窮舉所有擺法與交換順序，找出「最少要插幾個 SWAP」，
並印出一組做法：一開始代幣怎麼擺、在哪裡交換。用來當效能競賽的裁判。
規則（和紙板遊戲相同）：
  - 題卡上的 CNOT 照順序做；做每個 CNOT 時，兩枚代幣必須在有連線的兩個圓點上。
  - 一次 SWAP = 把一條連線兩端的代幣（或代幣與空位）互換，記 1 分；1 個 SWAP = 3 個 CNOT。
改造區：在 BOARDS 加你自己的耦合圖、在CARDS 加你自己的題卡。
"""
from collections import deque
from itertools import permutations

BOARDS = {   # 圓點編號 → 連線
    '線形 5 顆': (5, [(0, 1), (1, 2), (2, 3), (3, 4)]),
    '方格 3×3': (9, [(0, 1), (1, 2), (3, 4), (4, 5), (6, 7), (7, 8), (0, 3), (3, 6), (1, 4), (4, 7), (2, 5), (5, 8)]),
    '重六角小片 7 顆': (7, [(0, 1), (1, 2), (1, 3), (3, 5), (4, 5), (5, 6)]),
}

CARDS = {    # 題卡：邏輯位元數、CNOT 順序（控制, 目標）
    'A 兩人組': (2, [(0, 1)]),
    'B 一拖二': (3, [(0, 1), (0, 2)]),
    'C 接力鏈': (4, [(0, 1), (1, 2), (2, 3)]),
    'D 一拖三': (4, [(0, 1), (0, 2), (0, 3)]),
    'E 三角形': (3, [(0, 1), (1, 2), (2, 0)]),
    'F 一拖四': (5, [(0, 1), (0, 2), (0, 3), (0, 4)]),
}


def solve(board, card):
    n, edges = BOARDS[board]
    k, gates = CARDS[card]
    if k > n:
        return None
    adj = {i: set() for i in range(n)}
    for a, b in edges:
        adj[a].add(b)
        adj[b].add(a)
    start = {}
    dist, back, dq = {}, {}, deque()
    for pl in permutations(range(n), k):          # pl[q] = 邏輯位元 q 所在的圓點
        s = (pl, 0)
        dist[s], back[s] = 0, None
        dq.append(s)
    while dq:                                     # 0-1 BFS：做 CNOT 不花分，SWAP 花 1 分
        s = dq.popleft()
        pl, g = s
        if g == len(gates):
            steps, cur = [], s
            while back[cur] is not None:
                prev, move = back[cur]
                if move:
                    steps.append(move)
                cur = prev
            return dist[s], cur[0], steps[::-1]
        a, b = gates[g]
        if pl[b] in adj[pl[a]]:
            t = (pl, g + 1)
            if t not in dist or dist[t] > dist[s]:
                dist[t], back[t] = dist[s], (s, None)
                dq.appendleft(t)
            continue
        for u, v in edges:
            npl = tuple(v if p == u else u if p == v else p for p in pl)
            if npl == pl:
                continue
            t = (npl, g)
            if t not in dist:
                dist[t], back[t] = dist[s] + 1, (s, f'SWAP 圓點{u}–{v}（在第 {g + 1} 個 CNOT 之前）')
                dq.append(t)


if __name__ == '__main__':
    for card, (k, gates) in CARDS.items():
        print(f'題卡 {card}：' + '、'.join(f'CNOT(q{a},q{b})' for a, b in gates))
        for board in BOARDS:
            r = solve(board, card)
            if r is None:
                print(f'  {board}：位元不夠')
                continue
            cnt, pl, steps = r
            place = '、'.join(f'q{q}→{p}' for q, p in enumerate(pl))
            print(f'  {board}：最少 {cnt} 個 SWAP（多 {3 * cnt} 個 CNOT）；擺法 {place}' + (f'；{"；".join(steps)}' if steps else ''))
    print('\n粗估：每個 CNOT 錯 1% 時，全部不出錯的機會 = 0.99 的 CNOT 數次方')
    for m in (1, 3, 4, 9):
        print(f'  {m} 個 CNOT：{0.99 ** m:.1%}')
