"""父子科技學院 量子電腦學程 Q061：QFT 與相位估計 的小模擬器

執行：python qpe_lab.py              → 精度實驗：θ = 3/8 與 1/3，用 3、4、5 個計數位元各跑 1000 次
      python qpe_lab.py 分布 0.3      → 改造：自己選一個相位（單位：圈），印出三種位元數的直方圖
      python qpe_lab.py 成就          → 解鎖成就：電腦偷偷選相位，你從量測結果猜答案
      python qpe_lab.py qiskit 0.3    → 有裝 qiskit 與 qiskit-aer 時，用真正的相位估計線路跑
相位 θ 的單位是「圈」：θ = 1 代表轉一整圈。估計值 = 量到的整數 y ÷ 2ⁿ。
只用 Python 標準函式庫（qiskit 模式除外）。
"""
import cmath
import math
import random
import sys


def probs(theta, n):
    """理想相位估計（n 個計數位元）量到 y 的機率：|(1/2ⁿ) Σ_k e^{2πik(θ − y/2ⁿ)}|²。"""
    N = 2 ** n
    out = []
    for y in range(N):
        s = sum(cmath.exp(2j * math.pi * k * (theta - y / N)) for k in range(N)) / N
        out.append(abs(s) ** 2)
    return out


def run(theta, n, shots=1000, rng=random):
    p = probs(theta, n)
    counts = [0] * len(p)
    for y in rng.choices(range(len(p)), weights=p, k=shots):
        counts[y] += 1
    return counts


def report(theta, n, counts):
    N = 2 ** n
    y = max(range(N), key=lambda k: counts[k])
    est = y / N
    err = min(abs(est - theta), 1 - abs(est - theta))   # 相位是一圈一圈的，0 和 1 是同一點
    return y, est, err


def table(seed=61):
    rng = random.Random(seed)
    for theta, name in ((3 / 8, '3/8'), (1 / 3, '1/3')):
        print(f'相位 θ = {name} ≈ {theta:.4f} 圈')
        print('位元數｜格子｜最多次的 y（次數）｜估計 y ÷ 2ⁿ｜誤差｜最多次那格的理論機率')
        for n in (3, 4, 5):
            c = run(theta, n, 1000, rng)
            y, est, err = report(theta, n, c)
            print(f'{n}｜1/{2 ** n}｜{y}（{c[y]}）｜{est:.4f}｜{err:.4f}｜{probs(theta, n)[y]:.3f}')
        print()
    print('能整除（3/8）時每次都讀對；除不盡（1/3）時會散開，但每多一個位元，誤差大約減半。')


def histogram(theta, seed=61):
    rng = random.Random(seed)
    for n in (3, 4, 5):
        c = run(theta, n, 1000, rng)
        y, est, err = report(theta, n, c)
        print(f'--- {n} 個計數位元（格子 1/{2 ** n} 圈）：最多次 y = {y}，估計 {est:.4f}，誤差 {err:.4f}')
        for k, v in enumerate(c):
            if v:
                print(f'y = {k:2d}（{k}/{2 ** n} = {k / 2 ** n:.4f}）{v:4d} ' + '█' * (v // 20))
    print('看一看：哪一種位元數最集中？θ 離最近的格子有多遠（θ × 2ⁿ 和整數差多少）？')


def achievement():
    n = random.choice((3, 4, 5))
    theta = random.choice((random.randrange(2 ** n) / 2 ** n, random.random()))
    c = run(theta, n, 1000)
    print(f'電腦偷偷選了一個相位，用 {n} 個計數位元跑了 1000 次：')
    for k, v in enumerate(c):
        if v >= 10:
            print(f'  y = {k}：{v} 次')
    guess = input(f'你猜 θ 是幾圈？（可以寫成分數，例如 3/{2 ** n}）：').strip()
    try:
        a, _, b = guess.partition('/')
        g = float(a) / float(b) if b else float(a)
    except ValueError:
        print('看不懂這個答案。'); return
    ok = abs(g - theta) <= 1 / 2 ** n
    print(f'真正的 θ = {theta:.4f} 圈；你猜 {g:.4f}。', '解鎖成就！蓋一個章。' if ok else '差了超過一格，再試一次。')


def with_qiskit(theta):
    from qiskit import QuantumCircuit, transpile
    from qiskit.circuit.library import QFTGate
    from qiskit_aer import AerSimulator
    sim = AerSimulator(seed_simulator=61)
    for n in (3, 4, 5):
        qc = QuantumCircuit(n + 1, n)
        qc.x(n)                                   # 目標位元放在 |1⟩：受控相位閘的「本徵態」
        qc.h(range(n))                            # ① 疊加
        for j in range(n):                        # ② 相位回踢：第 j 顆控制 U 的 2^j 次方
            qc.cp(2 * math.pi * theta * 2 ** j, j, n)
        qc.append(QFTGate(n).inverse(), range(n))  # ③ 反向 QFT
        qc.measure(range(n), range(n))            # ④ 量測
        counts = sim.run(transpile(qc, sim), shots=1000).result().get_counts()
        top = sorted(((int(k, 2), v) for k, v in counts.items()), key=lambda kv: -kv[1])[:4]
        print(f'{n} 個計數位元：前幾名 (y, 次數) = {top}；估計 {top[0][0] / 2 ** n:.4f}')


if __name__ == '__main__':
    arg = sys.argv[1] if len(sys.argv) > 1 else ''
    val = float(sys.argv[2]) if len(sys.argv) > 2 else 0.3
    if arg in ('分布', 'hist'):
        histogram(val)
    elif arg in ('成就', 'game'):
        achievement()
    elif arg == 'qiskit':
        with_qiskit(val)
    else:
        table()
