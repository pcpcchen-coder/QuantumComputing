"""父子科技學院 量子電腦學程 Q024：單擺與約瑟夫森接面的「近似失效」小實驗。

不用安裝任何套件，只要 Python 3。執行：  python pendulum_check.py
一、單擺：大角度的週期比小角度長（維基百科 Pendulum (mechanics)，AGM 公式 T = T0 / M(1, cos(θ0/2))）
二、接面電感：L_J = L_J0 / cos φ = L_J0 / √(1 − (I/Ic)²)（學程簡報 JJ_Microwave_Readout_Talk p14、transmon p4–5）
三、小電流電感 L_J0 = Φ0 / (2π Ic)，Ic = 30 nA 的例子（同上）
"""
from math import sqrt, pi, cos, radians

G = 9.81              # 重力加速度（m/s²）
ROPE = 1.0            # 擺繩（m）
H = 6.62607015e-34    # 普朗克常數（SI 定義值）
E = 1.602176634e-19   # 基本電荷（SI 定義值）


def agm(a, b):
    for _ in range(40):
        a, b = (a + b) / 2, sqrt(a * b)
    return a


T0 = 2 * pi * sqrt(ROPE / G)
print(f'一、單擺（擺繩 {ROPE} m）：小角度週期 T0 = {T0:.3f} 秒')
PEND = {}
for deg in (5, 10, 20, 30, 45, 60, 90):
    PEND[deg] = T0 / agm(1, cos(radians(deg) / 2))
    print(f'  放手角度 {deg:3d} 度  →  週期 {PEND[deg]:.3f} 秒（比小角度多 {(PEND[deg] / T0 - 1) * 100:5.2f} %），十次來回 {10 * PEND[deg]:6.2f} 秒')

print()
print('二、接面電感隨電流變大：L_J / L_J0 = 1 / √(1 − (I/Ic)²)')
LJ = {}
for r in (0.1, 0.3, 0.5, 0.7, 0.87, 0.95, 0.98, 0.99):
    LJ[r] = 1 / sqrt(1 - r * r)
    print(f'  電流 = {r:4.2f} Ic  →  電感 = {LJ[r]:6.2f} 倍')
print('  電流到 Ic：電感變成無限大；超過 Ic，接面跳到有電壓、會耗能的狀態。')

print()
IC = 30e-9
LJ0_NH = H / (2 * E) / (2 * pi * IC) * 1e9
print(f'三、Ic = 30 nA 時，小電流電感 L_J0 = Φ0 / (2π Ic) = {LJ0_NH:.1f} nH')
