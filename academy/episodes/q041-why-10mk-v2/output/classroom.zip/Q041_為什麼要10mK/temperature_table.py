"""父子科技學院 量子電腦學程 Q041：為什麼要 10 mK——溫度換算驗算程式（只用標準函式庫）

執行：python temperature_table.py
先自己用計算機算完，再用這個程式對答案。
"""
import math

h = 6.62607015e-34      # 普朗克常數 J·s（定義值）
k = 1.380649e-23        # 波茲曼常數 J/K（定義值）
eV = 1.602176634e-19    # 1 電子伏特是多少焦耳

TEMPS = [("室溫", 300), ("液氮", 77), ("液氦", 4.2), ("稀釋冷凍機", 0.01)]

for f_ghz in (3, 5, 8):                       # 想試別的頻率，改這一行
    E = h * f_ghz * 1e9                       # 量子位元的一份能量（焦耳）
    T_star = E / k                            # 換成溫度（克耳文）
    print(f"{f_ghz} GHz：hf = {E / eV * 1e6:.2f} μeV ≈ {T_star:.3f} K")
    for name, T in TEMPS:
        x = E / (k * T)                       # 比值 hf / kT
        print(f"   {name:>5} {T:>7} K   hf/kT = {x:10.4g}   exp(-hf/kT) = {math.exp(-x):.4g}")
    print(f"   熱激發 < 1% 要低於 {T_star / math.log(100) * 1000:.0f} mK\n")
