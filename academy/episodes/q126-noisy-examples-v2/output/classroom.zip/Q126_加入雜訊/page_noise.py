"""父子科技學院 量子電腦學程 Q126：頁面的雜訊規則，算出期望值（純 Python，不需要安裝任何套件，也沒有亂數）

執行：  python page_noise.py
animations/operation.html 的「量子線路」場景有一個開關「加入雜訊（每閘 1%、讀取 3%）」，它的規則是：
  1. 線路有 G 個閘，每個閘有 1% 的機會出錯；只要有一個出錯，這一次的結果就變成「完全隨機」
     → 每次變成隨機的機會 = 1 − 0.99 的 G 次方
  2. 讀取時，每顆位元再各有 3% 的機會讀錯（0、1 對調）
這個程式不抽樣，直接把「跑很多很多次」會得到的比例算出來。SCALE 把 1% 和 3% 一起放大：2 = 雜訊加倍。
八個範例的閘數照 Q124 eight_examples.py 的線路數（不含量測）；理想機率照 basic-circuits.html 預設選項。
"""

# 範例名稱、閘數 G、理想機率（位元字串最右邊是 q0）
EXAMPLES = [
    ('1 疊加', 1, {'0': 0.5, '1': 0.5}),
    ('2 干涉', 3, {'1': 1.0}),
    ('3 Bell 態', 2, {'00': 0.5, '11': 0.5}),
    ('4 GHZ 態', 3, {'000': 0.5, '111': 0.5}),
    ('5 隱形傳態', 7, {'0': 0.75, '1': 0.25}),
    ('6 Deutsch', 5, {'1': 1.0}),
    ('7 BV', 10, {'101': 1.0}),
    ('8 Grover', 12, {'11': 1.0}),
]

GATE, READ = 0.01, 0.03   # 頁面的參數：每閘 1%、每顆位元讀取 3%
MY_SCALE = 2              # 改造區：雜訊放大幾倍


def expected(G, theory, scale=1):
    """照頁面的規則，算出每個結果的期望比例"""
    n = len(next(iter(theory)))
    keys = [format(i, f'0{n}b') for i in range(2 ** n)]
    pg = 1 - (1 - GATE * scale) ** G           # 這一次變成完全隨機的機會
    pr = READ * scale                          # 每顆位元讀錯的機會
    before = {k: (1 - pg) * theory.get(k, 0) + pg / 2 ** n for k in keys}
    after = {}
    for k in keys:
        total = 0
        for j, p in before.items():
            d = sum(a != b for a, b in zip(j, k))      # 要讀錯幾顆位元，j 才會變成 k
            total += p * pr ** d * (1 - pr) ** (n - d)
        after[k] = total
    return pg, after


def off(theory, p):
    """跑掉的比例：把有雜訊的直方圖搬回理想的樣子，最少要搬走幾成"""
    return sum(abs(theory.get(k, 0) - v) for k, v in p.items()) / 2


if __name__ == '__main__':
    print('一、加入雜訊（每閘 1%、讀取 3%）：每次變成隨機的機會，和答案還剩多少')
    for name, G, th in EXAMPLES:
        pg, p = expected(G, th)
        ans = '、'.join(f'{k} {p[k]:.1%}' for k in sorted(th))
        print(f'  {name}：{G} 個閘 → 變成隨機 {pg:.1%}；{ans}；跑掉 {off(th, p):.1%}')
    print('二、雜訊一直加倍：跑掉的比例')
    print('  範例           ×1      ×2      ×4      ×8')
    for name, G, th in EXAMPLES:
        print(f'  {name:<10}' + ''.join(f'{off(th, expected(G, th, s)[1]):8.1%}' for s in (1, 2, 4, 8)))
    print(f'三、改造區：雜訊 ×{MY_SCALE}（每閘 {GATE * MY_SCALE:.0%}、讀取 {READ * MY_SCALE:.0%}）')
    for name, G, th in EXAMPLES:
        if name in ('3 Bell 態', '4 GHZ 態', '8 Grover'):
            pg, p = expected(G, th, MY_SCALE)
            print(f'  {name}：' + '、'.join(f'{k} {v:.1%}' for k, v in p.items()))
