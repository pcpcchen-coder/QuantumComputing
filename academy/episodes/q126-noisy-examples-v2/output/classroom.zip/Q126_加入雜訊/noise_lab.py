"""父子科技學院 量子電腦學程 Q126：加入雜訊——八個範例在真實世界會怎樣（雜訊模型 notebook 的程式版）

安裝（只要一次）：  pip install qiskit qiskit-aer
執行：              python noise_lab.py
八個範例的線路和 Q124 的 eight_examples.py 一樣（照 basic-circuits.html 預設選項抄寫）。
雜訊模型是「假設」，不代表任何一台真實的量子電腦；三個參數寫在下面，要改就改這裡：
  P1：單位元閘（h、x、z、ry）做完後，有 P1 的機會被「去極化」（狀態被隨機打亂）
  P2：雙位元閘（cx、cz）做完後，兩顆位元一起有 P2 的機會被去極化
  PR：讀取時，每顆位元有 PR 的機會讀錯（0 讀成 1，或 1 讀成 0）
位元字串的最右邊是 q0。固定亂數種子，所以每次執行結果相同；拿掉 seed_simulator 就每次不同。
"""
# %% 匯入
from math import pi

from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector
from qiskit_aer import AerSimulator
from qiskit_aer.noise import NoiseModel, ReadoutError, depolarizing_error

# %% 雜訊模型的三個參數（假設值）與改造區
P1, P2, PR = 0.01, 0.02, 0.03
MY_SCALE = 2        # 改造區：把三個參數一起乘上幾倍（1 = 原本、2 = 加倍）
SHOTS = 1000


def noise_model(scale=1):
    """照 P1、P2、PR 乘上 scale，建立一個雜訊模型"""
    nm = NoiseModel(basis_gates=['h', 'x', 'z', 'ry', 'cx', 'cz'])
    nm.add_all_qubit_quantum_error(depolarizing_error(P1 * scale, 1), ['h', 'x', 'z', 'ry'])
    nm.add_all_qubit_quantum_error(depolarizing_error(P2 * scale, 2), ['cx', 'cz'])
    r = PR * scale
    nm.add_all_qubit_readout_error(ReadoutError([[1 - r, r], [r, 1 - r]]))
    return nm


# %% 八個範例（同 Q124）
def superposition():
    qc = QuantumCircuit(1, 1)
    qc.h(0)
    qc.measure(0, 0)
    return qc


def interference():
    qc = QuantumCircuit(1, 1)
    qc.h(0)
    qc.z(0)
    qc.h(0)
    qc.measure(0, 0)
    return qc


def bell():
    qc = QuantumCircuit(2, 2)
    qc.h(0)
    qc.cx(0, 1)
    qc.measure([0, 1], [0, 1])
    return qc


def ghz():
    qc = QuantumCircuit(3, 3)
    qc.h(0)
    qc.cx(0, 1)
    qc.cx(1, 2)
    qc.measure([0, 1, 2], [0, 1, 2])
    return qc


def teleport(angle=pi / 3):
    qc = QuantumCircuit(3, 1)
    qc.ry(angle, 0)
    qc.h(1)
    qc.cx(1, 2)
    qc.cx(0, 1)
    qc.h(0)
    qc.cx(1, 2)
    qc.cz(0, 2)
    qc.measure(2, 0)
    return qc


def deutsch():
    qc = QuantumCircuit(2, 1)
    qc.x(1)
    qc.h([0, 1])
    qc.cx(0, 1)
    qc.h(0)
    qc.measure(0, 0)
    return qc


def bv(secret='101'):
    qc = QuantumCircuit(4, 3)
    qc.x(3)
    qc.h([0, 1, 2, 3])
    for q in range(3):
        if secret[2 - q] == '1':
            qc.cx(q, 3)
    qc.h([0, 1, 2])
    qc.measure([0, 1, 2], [0, 1, 2])
    return qc


def grover():
    qc = QuantumCircuit(2, 2)
    qc.h([0, 1])
    qc.cz(0, 1)
    qc.h([0, 1])
    qc.x([0, 1])
    qc.cz(0, 1)
    qc.x([0, 1])
    qc.h([0, 1])
    qc.measure([0, 1], [0, 1])
    return qc


CIRCUITS = {'1 疊加': superposition, '2 干涉': interference, '3 Bell 態': bell, '4 GHZ 態': ghz,
            '5 隱形傳態': teleport, '6 Deutsch': deutsch, '7 BV': bv, '8 Grover': grover}


def ideal(qc):
    """理想機率（Statevector，不含雜訊）"""
    measured = sorted(qc.find_bit(i.qubits[0]).index for i in qc.data if i.operation.name == 'measure')
    sv = Statevector(qc.remove_final_measurements(inplace=False))
    return {k: v for k, v in sv.probabilities_dict(qargs=measured).items() if v > 1e-12}


def noisy(qc, scale=1, shots=SHOTS, seed=126):
    """有雜訊的模擬：回傳每個結果的比例"""
    sim = AerSimulator(noise_model=noise_model(scale), seed_simulator=seed)
    counts = sim.run(qc, shots=shots).result().get_counts()
    return {k: v / shots for k, v in counts.items()}


def gates(qc):
    one = sum(1 for i in qc.data if i.operation.name in ('h', 'x', 'z', 'ry'))
    two = sum(1 for i in qc.data if i.operation.name in ('cx', 'cz'))
    return one, two


def off(p, q):
    """跑掉的比例：把有雜訊的直方圖搬回理想的樣子，最少要搬走幾成（兩邊差的一半）"""
    return sum(abs(p.get(k, 0) - q.get(k, 0)) for k in set(p) | set(q)) / 2


def compare(name, scale=1):
    """理想 vs 雜訊比較圖（文字版）：每個結果兩條，上面理想、下面有雜訊"""
    qc = CIRCUITS[name]()
    p, q = ideal(qc), noisy(qc, scale)
    n = qc.num_clbits
    one, two = gates(qc)
    print(f'  {name}（單位元閘 {one} 個、雙位元閘 {two} 個；雜訊 ×{scale}）')
    for i in range(2 ** n):
        k = format(i, f'0{n}b')
        a, b = p.get(k, 0), q.get(k, 0)
        print(f'    {k}  理想 {"█" * round(a * 40):<40} {a:6.1%}')
        print(f'    {" " * n}  雜訊 {"▒" * round(b * 40):<40} {b:6.1%}')
    print(f'    跑掉的比例 {off(p, q):.1%}')


# %% 一、理想 vs 雜訊比較圖：Bell、GHZ、Grover
print(f'雜訊模型（假設）：單位元閘 {P1:.0%}、雙位元閘 {P2:.0%}、讀取 {PR:.0%}；每種跑 {SHOTS} 次')
print('一、理想 vs 雜訊比較圖（雜訊 ×1）')
for name in ('3 Bell 態', '4 GHZ 態', '8 Grover'):
    compare(name)

# %% 二、把雜訊加倍：八個範例跑掉的比例
print('二、把雜訊一直加倍：八個範例跑掉的比例（每格 10000 次）')
print('  範例          閘數(單/雙)   ×1      ×2      ×4      ×8   ×8 時最高的結果')
for name, make in CIRCUITS.items():
    qc = make()
    p = ideal(qc)
    row = []
    for s in (1, 2, 4, 8):
        q = noisy(qc, s, shots=10000)
        row.append(off(p, q))
    top = max(q, key=q.get)
    one, two = gates(qc)
    right = '仍是答案' if p.get(top, 0) == max(p.values()) else '已經不是答案'
    print(f'  {name:<10}  {one:>3} / {two}   ' + '  '.join(f'{x:6.1%}' for x in row) + f'   {top}（{right}）')

# %% 三、沒有單一答案的兩個範例：疊加與隱形傳態
print('三、沒有單一答案的兩個範例（雜訊 ×1 與 ×8，各 10000 次）')
for name in ('1 疊加', '5 隱形傳態'):
    qc = CIRCUITS[name]()
    p = ideal(qc)
    q1, q8 = noisy(qc, 1, shots=10000), noisy(qc, 8, shots=10000)
    print(f'  {name}：理想 0 是 {p.get("0", 0):.1%}；雜訊 ×1 是 {q1.get("0", 0):.1%}；×8 是 {q8.get("0", 0):.1%}')


# %% 四、改造區：MY_SCALE
print(f'四、改造區：雜訊 ×{MY_SCALE}')
compare('8 Grover', MY_SCALE)

# %% 五、延伸：零雜訊外插（簡報第 48 頁 ZNE 的最簡單版本）
print('五、延伸：故意把雜訊加倍，再往回推到「沒有雜訊」')
qc = grover()
a = noisy(qc, 1, shots=10000).get('11', 0)
b = noisy(qc, 2, shots=10000).get('11', 0)
print(f'  Grover 答案 11 的比例：雜訊 ×1 是 {a:.1%}，×2 是 {b:.1%}')
print(f'  直線往回推到 ×0：2 × {a:.3f} − {b:.3f} = {2 * a - b:.1%}（理想是 100%）')
