"""父子科技學院 量子電腦學程 Q026：傾斜洗衣板（電阻電容分路接面模型，和動畫 index.html#washboard 同一條方程式）。

不用安裝任何套件，只要 Python 3。執行：  python washboard_sim.py
- 方程式（無因次）：相位粒子的加速度 = I − sin φ − (速度)/Q
  I 是偏壓電流（以臨界電流 Ic 為單位）；Q 是品質因子，摩擦越小 Q 越大；動畫預設 Q = 8。
- 平均電壓（以 Ic·R 為單位）= 平均速度 ÷ Q；和動畫右下角小圖的橫軸相同。
- 先把電流一格一格往上加（0 → 1.3），再一格一格往回調（1.3 → 0）；
  每一格都從上一格結束時的狀態接著跑，所以會記得「之前發生過什麼」。
- 和動畫不同的地方：這裡沒有加隨機雜訊，每一格跑得夠久才取平均，結果每次都一樣。
- 參考：學程簡報 JJ_Microwave_Readout_Talk p16；animations/js/scenes/05_washboard.js；維基百科 Phase qubit、Josephson effect。
"""
import math

Q = 8.0          # 品質因子（動畫預設值）
DT = 0.01        # 每一步的時間（無因次）
SETTLE = 300.0   # 每一格先跑這麼久，讓小球安定下來
AVG = 200.0      # 再跑這麼久，取平均速度


def run_step(i_bias, phi, v, q=Q):
    """在固定電流下跑一段時間，回傳 (平均電壓, 結束時的 φ, 結束時的速度)。"""
    for _ in range(int(SETTLE / DT)):
        v += (i_bias - math.sin(phi) - v / q) * DT
        phi += v * DT
    start, n = phi, int(AVG / DT)
    for _ in range(n):
        v += (i_bias - math.sin(phi) - v / q) * DT
        phi += v * DT
    return (phi - start) / AVG / q, phi, v


def sweep(q=Q, top=1.3, step=0.01):
    ups = [round(k * step, 2) for k in range(int(round(top / step)) + 1)]
    downs = ups[::-1][1:]
    phi, v, rows = 0.0, 0.0, []
    for direction, currents in (('上升', ups), ('下降', downs)):
        for i_bias in currents:
            volt, phi, v = run_step(i_bias, phi, v, q)
            rows.append((direction, i_bias, volt))
    return rows


def thresholds(rows):
    up = [i for d, i, volt in rows if d == '上升' and volt > 0.02]
    down = [i for d, i, volt in rows if d == '下降' and volt > 0.02]
    return min(up), min(down)


ROWS = sweep()
ESCAPE, RETRAP = thresholds(ROWS)
SHOW = {0.0, 0.3, 0.5, 0.9, 0.99, 1.0, 1.01, 1.1, 1.3, 0.2, 0.17, 0.16, 0.15, 0.1}
print(f'品質因子 Q = {Q:g}（摩擦越小 Q 越大）')
print('方向   電流 I/Ic   平均電壓 ⟨V⟩/IcR   狀態')
for d, i_bias, volt in ROWS:
    if round(i_bias, 2) in SHOW:
        print(f'{d}   {i_bias:8.2f}   {volt:14.3f}      {"電壓態" if volt > 0.02 else "零電壓態"}')
print()
print(f'往上加：電流到 {ESCAPE:.2f} 才滑出山谷（臨界電流是 1）')
print(f'往回調：電流降到 {RETRAP:.2f} 還在滑，再低一格才停下（回捕電流）')
print(f'動畫小圖寫的估計值 4/(πQ) = {4 / (math.pi * Q):.2f}')
print()
print('摩擦變大（Q 變小）時，停下來的電流：')
for q in (2.0, 4.0, 8.0, 16.0):
    e, r = thresholds(sweep(q, step=0.01))
    print(f'  Q = {q:4.1f}：滑出 {e:.2f}、往回調時最後還在滑的電流 {r:.2f}（估計值 4/(πQ) = {min(1.0, 4 / (math.pi * q)):.2f}）')
