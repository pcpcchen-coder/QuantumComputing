"""父子科技學院 量子電腦學程 Q120：用本機 Qiskit 重現 BV 密碼線路（選用，不需要帳號）

安裝（只要一次）：  pip install qiskit
執行：              python qiskit_check.py
線路和 basic-circuits.html#bv 的教科書版相同：q0–q2 是輸入，q3 是輔助位元。
"""
from qiskit import QuantumCircuit
from qiskit.primitives import StatevectorSampler


def bv(s):
    """s 寫成 s2 s1 s0；密碼哪一位是 1，就從那顆位元接一條受控反閘到輔助位元"""
    n = len(s)
    qc = QuantumCircuit(n + 1, n)
    qc.x(n)                                  # 輔助位元翻成 1
    qc.h(range(n + 1))                       # 全部做哈達瑪閘
    for i in range(n):                       # 黑盒子（只查詢這一次）
        if s[n - 1 - i] == '1':
            qc.cx(i, n)
    qc.h(range(n))                           # 輸入位元再做哈達瑪閘
    qc.measure(range(n), range(n))
    return qc


sampler = StatevectorSampler(seed=2026)
for s in ('000', '001', '010', '011', '100', '101', '110', '111', '101101'):
    counts = sampler.run([bv(s)], shots=1000).result()[0].data.c.get_counts()
    print(f'密碼 {s:<6}：量 1000 次 {counts}')    # 位元字串的最右邊是 q0
print(bv('011').draw())
