"""父子科技學院 量子電腦學程 Q120：範例 7 BV——查一次讀出整串密碼（純 Python，不需安裝任何套件）

執行：  python bv_lab.py
它印出：
  一、古典逐位查詢：黑盒子怎麼回答、每問一次還剩幾種可能的密碼
  二、量子線路：哈達瑪閘 → 查詢一次 → 哈達瑪閘，每一步的八個振幅（順序 000～111）
  三、密碼的指紋：八個密碼各自的正負號排列，任兩排剛好 4 格同號、4 格反號
  四、次數表：密碼越長，古典要問幾次、量子要問幾次、線路有幾個閘
  五、讀取雜訊：每顆位元讀錯 3% 時，讀出完整密碼的機率
  六、改造區：換成自己的密碼，先預測，再執行
位元字串寫成 s2 s1 s0（最右邊是 s0），和 basic-circuits.html#bv、Qiskit 一樣。
"""
import random
from math import sqrt

SECRET = '011'      # 影片和教材用的密碼


def answer(s, x):
    """黑盒子：對應位相乘、加起來，只回答奇數（1）或偶數（0）"""
    return sum(int(a) * int(b) for a, b in zip(s, x)) % 2


def all_strings(n):
    return [format(i, f'0{n}b') for i in range(2 ** n)]


def classical(s):
    """古典逐位查詢：依序問 100…、010…、…001，記下每次還剩幾種可能"""
    n, alive, log = len(s), all_strings(len(s)), []
    for k in range(n):
        x = '0' * k + '1' + '0' * (n - k - 1)
        a = answer(s, x)
        alive = [c for c in alive if answer(c, x) == a]
        log.append((x, a, len(alive)))
    return log, alive


def h_all(v):
    """每顆位元都做一次哈達瑪閘（n 顆一起）"""
    n = len(v).bit_length() - 1
    for q in range(n):
        m, new = 1 << q, v[:]
        for i in range(len(v)):
            if not i & m:
                a, b = v[i], v[i | m]
                new[i], new[i | m] = (a + b) / sqrt(2), (a - b) / sqrt(2)
        v = new
    return v


def quantum(s):
    """哈達瑪閘 → 查詢一次（s·x 奇數的翻負號）→ 哈達瑪閘；回傳三步的振幅"""
    n = len(s)
    v = [1.0] + [0.0] * (2 ** n - 1)
    v1 = h_all(v)
    v2 = [(-1) ** answer(s, x) * a for x, a in zip(all_strings(n), v1)]
    v3 = h_all(v2)
    return v1, v2, v3


def show(v):
    return ' '.join(f'{a + 0.0:+.2f}'.replace('-', '−') for a in v)


def signs(v):
    return ''.join('+' if a > 0 else '−' for a in v)


def gates(n, ones):
    """教科書版線路的閘數：輔助位元 1 個翻轉閘、n+1 個哈達瑪閘、每個 1 一條受控反閘、最後 n 個哈達瑪閘"""
    return 1 + (n + 1) + ones + n


def noisy_shots(s, shots, p, rng):
    """理想時每次都讀到 s；每顆位元有 p 的機率讀錯（0、1 對調）"""
    out = {}
    for _ in range(shots):
        r = ''.join(('1' if b == '0' else '0') if rng.random() < p else b for b in s)
        out[r] = out.get(r, 0) + 1
    return out


if __name__ == '__main__':
    print(f'一、古典逐位查詢（密碼 s = {SECRET}）')
    print(f'  例：丟 x = 110 → {"＋".join(str(int(a) * int(b)) for a, b in zip(SECRET, "110"))} = '
          f'{sum(int(a) * int(b) for a, b in zip(SECRET, "110"))} → 回答 {answer(SECRET, "110")}')
    log, alive = classical(SECRET)
    print('  一開始有 8 種可能的密碼')
    for k, (x, a, left) in enumerate(log, 1):
        print(f'  第 {k} 次：丟 x = {x} → 回答 {a} → 還剩 {left} 種可能')
    print(f'  問了 {len(log)} 次，只剩 {alive[0]}')
    split = {x: sum(answer(c, x) for c in all_strings(3)) for x in all_strings(3)[1:]}
    print('  不管丟哪一個 x（000 除外），8 種密碼裡回答 1 的都剛好 '
          f'{set(split.values()).pop()} 種：每問一次，最多只能把可能砍掉一半')

    print(f'二、量子線路（密碼 s = {SECRET}，振幅順序 000 001 010 011 100 101 110 111）')
    v1, v2, v3 = quantum(SECRET)
    print(f'  ①哈達瑪閘：{show(v1)}   每個機率 {v1[0] ** 2:.1%}')
    print(f'  ②查詢一次：{show(v2)}   每個機率 {v2[0] ** 2:.1%}')
    print('    翻成負號的是：' + '、'.join(x for x, a in zip(all_strings(3), v2) if a < 0))
    print(f'  ③哈達瑪閘：{show(v3)}   讀到 {all_strings(3)[max(range(8), key=lambda i: v3[i] ** 2)]} 的機率 {max(a * a for a in v3):.0%}')
    print('  量子只查詢了 1 次')

    print('三、密碼的指紋：查詢一次之後的正負號排列')
    pats = {}
    for s in all_strings(3):
        pats[s] = signs(quantum(s)[1])
        ket = [1.0 if x == s else 0.0 for x in all_strings(3)]
        same = signs(h_all(ket)) == pats[s]
        print(f'  s = {s}：{pats[s]}   和「對 |{s}⟩ 做哈達瑪閘」的正負號{"一樣" if same else "不一樣"}')
    agree = {sum(a == b for a, b in zip(pats[s], pats[t])) for s in pats for t in pats if s < t}
    print(f'  任兩個不同密碼的排列：同號的格數都是 {agree.pop()}，另外 4 格反號 → 再做一次哈達瑪閘就分得開')

    print('四、次數表：密碼越長')
    print('  位數   可能的密碼    古典要問   量子要問   線路的閘（密碼全是 1 時）')
    for n in (1, 2, 3, 4, 5, 6, 8, 10, 20):
        print(f'  {n:>3}   {2 ** n:>10,}   {n:>6} 次   {1:>6} 次   {gates(n, n):>6} 個')

    print('五、讀取雜訊：每顆位元讀錯 3%')
    rng = random.Random(1120)
    for n in (3, 10, 20):
        s = (SECRET * 7)[:n]
        got = noisy_shots(s, 1000, 0.03, rng)
        best = max(got, key=got.get)
        print(f'  {n:>2} 位元：讀出完整密碼的機率 0.97^{n} = {0.97 ** n:.1%}；'
              f'模擬 1000 次（random 種子 1120）讀對 {got.get(s, 0)} 次，最多的{"就是" if best == s else "不是"}密碼')

    # 六、改造區：換成自己的 3 位元密碼（只寫 0 和 1），先預測，再執行
    MY_SECRET = '110'
    log, alive = classical(MY_SECRET)
    v1, v2, v3 = quantum(MY_SECRET)
    print('六、改造區')
    print(f'  我的密碼 {MY_SECRET}：古典問了 {len(log)} 次 → {alive[0]}；量子查詢 1 次')
    print(f'  查詢後的正負號 {signs(v2)}；最後讀到 '
          + '、'.join(f'{x}：{a * a:.0%}' for x, a in zip(all_strings(3), v3) if a * a > 1e-9))
