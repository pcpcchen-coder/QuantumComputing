"""父子科技學院 量子電腦學程 Q070：莫爾默與索倫森閘的相空間迴圈（只用 Python 內建功能，不需要安裝任何套件）

執行：python ms_gate.py
模型（和動畫 atoms.html#ms 相同）：
  振動在相空間的位置 α(t) = A·(e^{iδt} − 1)，畫一個半徑 A 的圓，t = 2πK/δ 時回到原點
  幾何相位 Φ(t) = A²·(δt − sin δt)；A = 1/(4√K)，讓繞完 K 圈時 2Φ = π/4
  從 |00⟩ 出發：P(00) = cos²(2Φ)，P(11) = sin²(2Φ)
"""
import cmath
import math

K = 1                       # 改造區：繞幾圈（1 或 2）
FK = 10                     # 改造區：失諧 δ/2π，單位 kHz
A = 1 / (4 * math.sqrt(K))


def state(frac):
    """閘進行到 frac（0～1）時的位移、相位和機率。"""
    s = 2 * math.pi * K * frac
    alpha = A * (cmath.exp(1j * s) - 1)
    phi = A * A * (s - math.sin(s))
    return abs(alpha), 2 * phi / math.pi, math.cos(2 * phi) ** 2, math.sin(2 * phi) ** 2


print(f'失諧 {FK} kHz，繞 {K} 圈 → 閘時間 = {1000 * K / FK:.0f} μs')
for frac in (0, 0.25, 0.5, 0.75, 1.0):
    a, ph, p00, p11 = state(frac)
    note = '迴圈閉合' if a < 1e-9 and frac > 0 else ('還沒開始' if frac == 0 else '迴圈未閉合：自旋和振動仍糾纏')
    print(f'停在 {frac:4.0%}（{1000 * K * frac / FK:5.1f} μs）：|α| = {a:.3f}，2Φ = {ph:.3f}π，'
          f'P(00) = {p00:.3f}，P(11) = {p11:.3f}　{note}')
for fk in (5, 10, 20, 50):
    print(f'失諧 {fk:2d} kHz → 閘時間 {1000 * K / fk:.0f} μs')
