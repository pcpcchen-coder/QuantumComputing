"""父子科技學院 量子電腦學程 Q040：機房用電小工具。

不用安裝任何套件，只要 Python 3。執行：  python power_budget.py
- 一、典型用電分配：數字和動畫 peripherals.html#overview 右下小圖一樣（js/peripherals/common.js 的 PD.power，「示意，依機型與規模而異」）。
- 二、每一項占幾成，壓縮機加冷卻水占幾成。
- 三、對照：冷凍機最底層（混合腔）的冷卻功率約 19 微瓦（學程簡報 QC_Peripheral_Systems_Talk p7，Krinner et al. 2019 的量測）。
  這是「最底層能帶走多少熱」，不是晶片本身的耗電。
"""

POWER = [  # (設備, kW)
    ('脈衝管壓縮機', 10.7),
    ('冷卻水系統', 10.0),
    ('控制電子機櫃', 3.0),
    ('氣體處理系統（泵）', 1.5),
    ('電腦 / 監控 / 網路', 1.0),
]
MXC_COOLING_W = 19e-6  # 混合腔在 20 mK 的冷卻功率（瓦）

TOTAL = sum(kw for _, kw in POWER)
print('一、典型用電分配（kW，示意）')
for name, kw in POWER:
    print(f'  {name:10s} {kw:5.1f} kW')
print(f'  合計 {TOTAL:.1f} kW（動畫小圖寫「約 {TOTAL:.0f} kW」）')

print()
print('二、每一項占幾成')
SHARE = {name: kw / TOTAL for name, kw in POWER}
for name, s in SHARE.items():
    print(f'  {name:10s} {s * 100:5.1f} %')
COOLING_PAIR = SHARE['脈衝管壓縮機'] + SHARE['冷卻水系統']
print(f'  壓縮機 + 冷卻水：{COOLING_PAIR * 100:.1f} %')

print()
print('三、對照最底層的冷卻功率')
RATIO = TOTAL * 1000 / MXC_COOLING_W
print(f'  機房用電 {TOTAL:.1f} kW ÷ 最底層冷卻功率 {MXC_COOLING_W * 1e6:.0f} 微瓦 ≈ {RATIO:.1e} 倍')
