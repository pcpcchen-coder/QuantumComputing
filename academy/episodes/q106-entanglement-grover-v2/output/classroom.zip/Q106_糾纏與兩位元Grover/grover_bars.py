"""父子科技學院 量子電腦學程 Q106：振幅長條逐步圖——Bell 態與兩位元 Grover（純 Python，不需要安裝任何套件）

執行：  python grover_bars.py
位元順序和學程動畫 transmon-3d.html 第 7 章相同：|Q1 Q2⟩，左邊那位是 Q1。
"""
import math

ANSWER = '10'       # 改造區：把答案換成 00、01、10 或 11，先預測一輪後的長條，再執行
R2 = 1 / math.sqrt(2)


def h(a, q):
    """哈達瑪閘：q = 0 是 Q1（左邊那位），q = 1 是 Q2"""
    bit = 2 if q == 0 else 1
    b = a[:]
    for i in range(4):
        if not i & bit:
            b[i], b[i | bit] = R2 * (a[i] + a[i | bit]), R2 * (a[i] - a[i | bit])
    return b


def cz(a):
    """受控相位翻轉：只把 |11⟩ 的振幅變號"""
    return a[:3] + [-a[3]]


def oracle(a, ans):
    """標記答案：答案那一格變號（硬體上是在受控相位翻轉前後，對答案是 0 的位元夾翻轉閘）"""
    b = a[:]
    b[int(ans, 2)] *= -1
    return b


def diffuse(a):
    """擴散：每個振幅對平均值翻轉，新振幅 = 2 × 平均 − 原振幅"""
    m = sum(a) / len(a)
    return [2 * m - v for v in a]


def sg(v):
    return ('−' if v < -1e-9 else '+') + f'{abs(v):.2f}'


def bar(v):
    n = round(abs(v) * 8)
    return sg(v) + ' ' + ('▇' * n).ljust(8)


def show(name, a):
    pad = 10 - sum(2 if ord(c) > 0x2E80 else 1 for c in name)
    print(name + ' ' * pad + '  '.join(f'{k}:{bar(v)}' for k, v in zip(('00', '01', '10', '11'), a)))


def check(a):
    p1, p2 = a[0] * a[3], a[1] * a[2]
    kind = '乘積態' if abs(p1 - p2) < 1e-9 else '糾纏'
    return f'    a00·a11 = {sg(p1)}，a01·a10 = {sg(p2)} → {kind}'


def grover_prob(n, rounds):
    """n 個位元（N = 2ⁿ 個選項）做 rounds 輪之後，答案的機率"""
    N = 2 ** n
    a = [1 / math.sqrt(N)] * N
    for _ in range(rounds):
        a[0] = -a[0]
        a = diffuse(a)
    return a[0] ** 2


if __name__ == '__main__':
    print('== Bell 態：兩顆哈達瑪閘 → 受控相位翻轉 → Q2 再一個哈達瑪閘 ==')
    a = [1.0, 0.0, 0.0, 0.0]
    show('起點', a)
    a = h(h(a, 0), 1); show('H⊗H', a); print(check(a))
    a = cz(a); show('CZ', a); print(check(a))
    a = h(a, 1); show('H(Q2)', a); print(check(a))
    print()
    print(f'== 兩位元 Grover，答案 = {ANSWER} ==')
    a = h(h([1.0, 0.0, 0.0, 0.0], 0), 1); show('H⊗H', a)
    a = oracle(a, ANSWER); show('標記', a); print(f'    平均 = {sg(sum(a) / 4)}')
    a = diffuse(a); show('擴散', a)
    print(f'    一輪後：量到 {ANSWER} 的機率 {a[int(ANSWER, 2)] ** 2 * 100:.1f} %')
    a = oracle(a, ANSWER); a = diffuse(a); show('第二輪', a)
    print(f'    兩輪後：量到 {ANSWER} 的機率 {a[int(ANSWER, 2)] ** 2 * 100:.1f} %（轉過頭）')
    print()
    print('== 位元多了：答案的機率（%）==')
    print('位元  選項   1 輪    2 輪    3 輪    4 輪')
    for n in (2, 3, 4):
        print(f'{n:>3}  {2 ** n:>4}' + ''.join(f'{grover_prob(n, r) * 100:8.1f}' for r in (1, 2, 3, 4)))
