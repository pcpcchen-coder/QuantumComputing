"""父子科技學院 量子電腦學程 Q130：斷電時間軸——不同備援方案，冷卻鏈會停多久？（純 Python，不需要安裝任何套件）

執行：  python outage_timeline.py
時間數字：冷卻中斷約 2 分鐘晶片超過 1 K、重新降溫 2–5 天，取自 LRZ 公開論文（arXiv:2509.12949）；
發電機啟動＋自動切換約 10–30 秒，取自學程文件「量子電腦供電設計文獻回顧」§2 的推論（這裡取保守的 30 秒）。
"""

TOLERANCE_MIN = 2.0     # 冷卻鏈最多能停幾分鐘（約 2 分鐘就超過 1 K）
GEN_START_MIN = 0.5     # 發電機啟動＋自動切換開關（約 10–30 秒，取 30 秒）
RECOOL = '2–5 天'        # 超過 1 K 之後：重新降溫，再完整校準

# 改造區：(案例名稱, 市電停幾分鐘, 冷卻鏈有沒有接 UPS, UPS 撐幾分鐘, 發電機有沒有起來)
CASES = [
    ('A 只有控制電子接 UPS，市電停 1 分鐘', 1, False, 0, False),
    ('A 只有控制電子接 UPS，市電停 5 分鐘', 5, False, 0, False),
    ('B 冷卻鏈接 UPS＋發電機，市電停 3 小時', 180, True, 15, True),
    ('C 冷卻鏈接 UPS、發電機沒起來，市電停 10 分鐘', 10, True, 15, False),
    ('C 冷卻鏈接 UPS、發電機沒起來，市電停 16 分鐘', 16, True, 15, False),
    ('C 冷卻鏈接 UPS、發電機沒起來，市電停 60 分鐘', 60, True, 15, False),
]


def cooling_gap(outage, cool_on_ups, ups, gen_ok):
    """冷卻鏈真正斷電幾分鐘"""
    if not cool_on_ups:
        return outage                      # 冷卻鏈沒有備援：市電停多久，它就停多久
    if gen_ok and ups >= GEN_START_MIN:
        return 0.0                         # UPS 撐到發電機接手：冷卻鏈不停
    return max(0.0, outage - ups)          # 發電機沒起來：UPS 用完後，停到市電回來


if __name__ == '__main__':
    print(f'容忍時間 {TOLERANCE_MIN:g} 分鐘；發電機接手 {GEN_START_MIN * 60:g} 秒')
    kept = 0
    for name, outage, cool, ups, gen in CASES:
        gap = cooling_gap(outage, cool, ups, gen)
        ok = gap <= TOLERANCE_MIN
        kept += ok
        result = '保住：1 K 以下' if ok else f'超過 1 K：停機 {RECOOL}＋完整校準'
        print(f'{name}：冷卻鏈停 {gap:g} 分鐘 → {result}')
    print(f'{len(CASES)} 個案例，保住 {kept} 個')
