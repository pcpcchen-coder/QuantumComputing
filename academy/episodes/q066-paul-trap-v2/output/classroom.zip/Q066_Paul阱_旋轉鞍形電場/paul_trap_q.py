"""父子科技學院 量子電腦學程 Q066：保羅阱的穩定界線（只用 Python 內建功能，不需要安裝任何套件）

執行：python paul_trap_q.py
方程（a = 0，τ = Ωt/2）：x'' = 2q·cos(2τ)·x
做法：把方程積分一個翻轉週期（τ 從 0 到 π），算出「一週期後放大多少」；
      |跡| < 2 代表每個週期不會越推越遠（穩定），> 2 代表越來越遠（不穩定）。
"""
import math


def one_period(q, x, v, n=2000):
    """用四階 Runge-Kutta 把 (x, v) 積分一個週期 τ = 0 → π。"""
    h, t = math.pi / n, 0.0
    acc = lambda xx, tt: 2 * q * math.cos(2 * tt) * xx
    for _ in range(n):
        k1x, k1v = v, acc(x, t)
        k2x, k2v = v + h / 2 * k1v, acc(x + h / 2 * k1x, t + h / 2)
        k3x, k3v = v + h / 2 * k2v, acc(x + h / 2 * k2x, t + h / 2)
        k4x, k4v = v + h * k3v, acc(x + h * k3x, t + h)
        x += h / 6 * (k1x + 2 * k2x + 2 * k3x + k4x)
        v += h / 6 * (k1v + 2 * k2v + 2 * k3v + k4v)
        t += h
    return x, v


def trace(q):
    x1, _ = one_period(q, 1.0, 0.0)
    _, v2 = one_period(q, 0.0, 1.0)
    return x1 + v2


# 改造區：想看更細的界線，把 0.05 改成 0.01（STEP = 0.01、範圍 range(85, 96)）
STEP = 0.05
print('  q     跡      結果')
for k in range(2, 21):
    q = k * STEP
    tr = trace(q)
    print(f'{q:5.2f}  {tr:+6.3f}  {"穩定" if abs(tr) < 2 else "不穩定"}')

# 二分法找界線
lo, hi = 0.5, 1.0
for _ in range(40):
    mid = (lo + hi) / 2
    lo, hi = (mid, hi) if abs(trace(mid)) < 2 else (lo, mid)
print(f'穩定界線 q ≈ {lo:.3f}')

# 慢擺動頻率的近似公式（q 小時才準）
for q, f_rf in ((0.4, 30), (0.4, 50), (0.7, 30)):
    print(f'q = {q}、射頻 {f_rf} MHz → 慢擺動 ≈ qΩ/(2√2) = {q * f_rf / (2 * math.sqrt(2)):.2f} MHz')
