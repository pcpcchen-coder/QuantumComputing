"""父子科技學院 量子電腦學程 Q103：能階、共振與拉比振盪（有 JJ／沒有 JJ 的十四階模擬）

和 transmon-3d.html 第 3、4 章用同一組數字：E_J/h = 15 GHz、E_C/h = 250 MHz、
驅動頻率對準 0→1、拉比頻率 25 MHz（π 脈衝 20 ns）、只算最低 14 個能階、不含雜訊與衰減。

安裝（只要一次）：  pip install numpy
執行：              python rabi_ladder.py
"""
import numpy as np

EJ, EC, NL, RABI = 15.0, 0.25, 14, 0.025      # GHz；時間單位 ns


def transmon_levels(n_charge=25):
    """電荷基底對角化 H = 4E_C n² − E_J cos φ，回傳最低 NL 個能階（GHz）。"""
    n = np.arange(-n_charge, n_charge + 1)
    H = np.diag(4 * EC * n ** 2) - EJ / 2 * (np.eye(len(n), k=1) + np.eye(len(n), k=-1))
    return np.linalg.eigvalsh(H)[:NL]


E_TR = transmon_levels()
E_LC = np.arange(NL) * np.sqrt(8 * EJ * EC)     # 線性 LC：每一階都一樣寬


def hamiltonian(E):
    """微波對準這個電路自己的 0→1 頻率 f01；在跟著微波旋轉的座標裡：
    失諧 δn = En − E0 − n·f01，加上驅動 (Ω/2)(a + a†)。"""
    f01 = E[1] - E[0]
    det = E - E[0] - np.arange(NL) * f01
    a = np.diag(np.sqrt(np.arange(1, NL)), k=1)
    return np.diag(det) + RABI / 2 * (a + a.T)


def evolve(E, t_ns):
    w, v = np.linalg.eigh(hamiltonian(E))
    psi0 = np.zeros(NL); psi0[0] = 1
    psi = v @ (np.exp(-2j * np.pi * w * t_ns) * (v.T @ psi0))
    return np.abs(psi) ** 2


def report(name, E):
    print(f'== {name} ==')
    print('相鄰兩階的間距（GHz）：', '、'.join(f'{x:.2f}' for x in np.diff(E)[:4]))
    print(' 時間   P(0)   P(1)   P(2)  P(≥3)  平均第幾階')
    for t in (0, 10, 20, 30, 40):
        P = evolve(E, t)
        print(f'{t:3d} ns  {P[0]:.3f}  {P[1]:.3f}  {P[2]:.3f}  {P[3:].sum():.3f}  {np.arange(NL) @ P:5.2f}')
    print()


if __name__ == '__main__':
    report('有 JJ（transmon）', E_TR)
    report('沒有 JJ（線性 LC）', E_LC)
    print('有 JJ：20 ns 是 π 脈衝（停在 1），40 ns 轉一整圈回到 0。沒有 JJ：一路往上爬。')
