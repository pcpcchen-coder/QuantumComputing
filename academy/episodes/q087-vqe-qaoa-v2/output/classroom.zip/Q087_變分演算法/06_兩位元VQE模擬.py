"""兩位元變分量子特徵值求解器（VQE）的本機模擬器（父子科技學院 Q087）。
只用 Python 標準函式庫：python3 06_兩位元VQE模擬.py 20 20
（兩個數字是兩顆量子位元的起始角度，單位是度；不填就用 20 20）

玩具題目（教學用，不是真實分子）：
    能量算符 H = −Z0·Z1 + 0.3·(Z0 + Z1)
    試探線路：兩顆量子位元都從 |0⟩ 出發，各做一個 Ry(角度) 旋轉閘
迴圈：古典電腦給角度 → 「量子電腦」跑線路、量 SHOTS 次估計能量 → 用參數平移規則算斜率 → 角度往下坡走一步
"""
import math
import random
import sys

SHOTS = 1000      # 每次估計能量量幾次；改成 0 代表「無限多次」（直接算理論值，沒有統計誤差）
LR = 0.4          # 每一步走多大（學習率）
ITERS = 40        # 迭代次數
SEED = None       # 想讓每次結果一樣，就填一個整數


def probs(a, b):
    """兩顆位元各自 Ry 之後，量到 0 的機率（沒有糾纏，兩顆獨立）。"""
    return math.cos(a / 2) ** 2, math.cos(b / 2) ** 2


def energy(a, b, rng):
    p0, q0 = probs(a, b)
    if SHOTS == 0:
        z0, z1 = 2 * p0 - 1, 2 * q0 - 1
        return -z0 * z1 + 0.3 * (z0 + z1)
    total = 0.0
    for _ in range(SHOTS):
        z0 = 1 if rng.random() < p0 else -1     # 量到 0 記 +1，量到 1 記 −1
        z1 = 1 if rng.random() < q0 else -1
        total += -z0 * z1 + 0.3 * (z0 + z1)
    return total / SHOTS


def main():
    rng = random.Random(SEED)
    a_deg = float(sys.argv[1]) if len(sys.argv) > 1 else 20.0
    b_deg = float(sys.argv[2]) if len(sys.argv) > 2 else 20.0
    a, b = math.radians(a_deg), math.radians(b_deg)
    rows = []
    for it in range(ITERS + 1):
        e = energy(a, b, rng)
        rows.append((it, math.degrees(a), math.degrees(b), e))
        ga = (energy(a + math.pi / 2, b, rng) - energy(a - math.pi / 2, b, rng)) / 2
        gb = (energy(a, b + math.pi / 2, rng) - energy(a, b - math.pi / 2, rng)) / 2
        a, b = a - LR * ga, b - LR * gb
    print("迭代  角度一   角度二    能量    （每個 # 代表 0.05）")
    for it, x, y, e in rows:
        bar = "#" * max(0, round((e + 1.8) / 0.05))
        print(f"{it:4d} {x:7.1f} {y:7.1f} {e:+7.3f}  {bar}")
    with open("能量曲線.csv", "w", encoding="utf-8") as f:
        f.write("迭代,角度一,角度二,能量\n")
        for it, x, y, e in rows:
            f.write(f"{it},{x:.1f},{y:.1f},{e:.4f}\n")
    print("最後能量：%+.3f（真正最低是 −1.600）；已存成 能量曲線.csv，可以用試算表畫圖" % rows[-1][3])


if __name__ == "__main__":
    main()
