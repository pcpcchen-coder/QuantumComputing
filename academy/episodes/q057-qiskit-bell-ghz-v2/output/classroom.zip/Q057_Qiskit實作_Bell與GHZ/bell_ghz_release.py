"""父子科技學院 量子電腦學程 Q057：程式實作——貝爾態與 GHZ 態（本機模擬器，不需要帳號）

安裝（只要一次）：  pip install qiskit qiskit-aer        （想畫圖再加 matplotlib）
執行：              python bell_ghz_release.py
同一份程式也做成筆記本：bell_ghz_release.ipynb（Jupyter 或 VS Code 開啟，按「全部重新執行」）
"""
# ── 第 0 格：記錄版本（Release 檢查清單第 2 項）──────────────────────────
import sys
import qiskit
import qiskit_aer
print('Python', sys.version.split()[0], '| qiskit', qiskit.__version__, '| qiskit-aer', qiskit_aer.__version__)
# 影片與解答用的版本：Python 3.13.18、qiskit 2.6.2、qiskit-aer 0.18.4

# ── 第 1 格：建線路 ───────────────────────────────────────────────────────
from qiskit import QuantumCircuit, transpile


def ghz(n):
    """n 顆位元的 GHZ 態；n = 2 就是貝爾態。"""
    qc = QuantumCircuit(n, n)
    qc.h(0)                       # 哈達瑪閘：q0 進入疊加
    for i in range(n - 1):
        qc.cx(i, i + 1)           # 受控反閘一路串下去：q0→q1、q1→q2…
    qc.measure(range(n), range(n))
    return qc


print(ghz(3).draw())

# ── 第 2 格：兩台模擬器，一台理想、一台加雜訊模型 ─────────────────────────
from qiskit_aer import AerSimulator
from qiskit_aer.noise import NoiseModel, depolarizing_error, ReadoutError

P_GATE, P_READ = 0.01, 0.03       # 每個閘 1% 被打亂、每次讀取 3% 讀反（教學用的假設值）
noise = NoiseModel()
noise.add_all_qubit_quantum_error(depolarizing_error(P_GATE, 1), ['h'])
noise.add_all_qubit_quantum_error(depolarizing_error(P_GATE, 2), ['cx'])
noise.add_all_qubit_readout_error(ReadoutError([[1 - P_READ, P_READ], [P_READ, 1 - P_READ]]))
ideal_sim = AerSimulator()
noisy_sim = AerSimulator(noise_model=noise)

SHOTS, SEED = 1024, 2026          # 固定種子：每次重跑都得到同一組數字（Release 檢查清單第 3 項）


def run(sim, qc, seed=SEED):
    counts = sim.run(transpile(qc, sim), shots=SHOTS, seed_simulator=seed).result().get_counts()
    return dict(sorted(counts.items()))


def wrong(counts, n):
    """全 0、全 1 以外的結果一共幾次。"""
    return SHOTS - counts.get('0' * n, 0) - counts.get('1' * n, 0)


# ── 第 3 格：跑、比、自動檢查 ─────────────────────────────────────────────
N = 2                             # 改造區：改成 3、4、5 試試看
qc = ghz(N)
ideal = run(ideal_sim, qc)
noisy = run(noisy_sim, qc)
print('理想  ', ideal)
print('有雜訊', noisy, '→ 錯誤結果', wrong(noisy, N), '次，出現', len(noisy), '種')

# 自動檢查（Release 檢查清單第 4 項）：沒過就會停下來
assert sum(ideal.values()) == SHOTS and sum(noisy.values()) == SHOTS
assert set(ideal) <= {'0' * N, '1' * N}, '理想模擬只該出現全 0 和全 1'
assert run(ideal_sim, qc) == ideal, '同一個種子重跑，數字應該一模一樣'
print('自動檢查全部通過')

# ── 第 4 格（選用）：畫成兩張並排的直方圖 ─────────────────────────────────
try:
    import matplotlib.pyplot as plt
    keys = [format(i, f'0{N}b') for i in range(2 ** N)]
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.5), sharey=True)
    for a, (title, c) in zip(ax, [('ideal', ideal), ('noisy', noisy)]):
        a.bar(keys, [c.get(k, 0) for k in keys])
        a.set_title(f'GHZ n={N} {title}')
        a.tick_params(axis='x', rotation=90 if N > 3 else 0)
    plt.tight_layout()
    plt.savefig(f'ghz{N}_histograms.png')
    print('直方圖存成', f'ghz{N}_histograms.png')
except ImportError:
    print('沒有安裝 matplotlib：跳過畫圖，用上面的數字畫在列印包上就好')

# 影片中的結果（seed=2026）：
#   N=2 理想 {'00': 516, '11': 508}；有雜訊 {'00': 478, '01': 49, '10': 32, '11': 465}，錯誤 81 次
#   N=3 有雜訊錯誤 109 次（8 種結果都出現）；N=5 有雜訊錯誤 173 次（32 種裡出現 21 種）
