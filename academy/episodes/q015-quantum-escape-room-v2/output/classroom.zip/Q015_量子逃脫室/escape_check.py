"""父子科技學院 量子電腦學程 Q015：量子逃脫室——五關答案的驗算。

不用安裝任何套件，只要 Python 3。執行：  python escape_check.py
每一關都用和學程動畫 operation.html 相同的規則計算（只算理想狀況，沒有雜訊）。
自己設計新關卡時，可以照同樣的方法先算一次，確定答案只有一個。
"""
import cmath
import itertools
import math

S = 1 / math.sqrt(2)
H = [[S, S], [S, -S]]          # 哈達瑪閘
Z = [[1, 0], [0, -1]]          # 相位翻轉閘
GATES = {'H': H, 'Z': Z}


def apply(m, v):
    return [m[0][0] * v[0] + m[0][1] * v[1], m[1][0] * v[0] + m[1][1] * v[1]]


def p1(v):
    return abs(v[1]) ** 2


# 第一關：箭頭從北極往下傾斜 theta 度，得到 0 的機率 = cos²(theta/2)（01_qubit.js）
theta = 60
P0_LEVEL1 = math.cos(math.radians(theta) / 2) ** 2
print(f'第一關：傾斜 {theta} 度，得到 0 的機率 {P0_LEVEL1:.3f}；量 1000 次，平均約 {1000 * P0_LEVEL1:.0f} 次是 0'
      f'（一個標準差約 {math.sqrt(1000 * P0_LEVEL1 * (1 - P0_LEVEL1)):.0f} 次）')

# 第二關：哈達瑪閘 → 在 |1> 路徑加相位 phi → 哈達瑪閘（08_interference.js）
LEVEL2 = {}
for phi in (0, 90, 180, 270):
    v = apply(H, [1, 0])
    v = [v[0], v[1] * cmath.exp(1j * math.radians(phi))]
    v = apply(H, v)
    LEVEL2[phi] = p1(v)
    print(f'第二關：相位 {phi:3d} 度，得到 1 的機率 {LEVEL2[phi]:.3f}')

# 第三關：兩顆量子位元，哈達瑪閘 + 受控反閘 → 貝爾態（04_register.js 的「Bell 態」按鈕）
amp = {'00': 1.0, '01': 0.0, '10': 0.0, '11': 0.0}            # 兩顆都從 0 開始；左邊那一位是控制位元
new = dict.fromkeys(amp, 0.0)
for k, x in amp.items():                                          # 對控制位元做哈達瑪閘
    for b, sign in (('0', 1), ('1', 1 if k[0] == '0' else -1)):
        new[b + k[1]] += S * sign * x
amp = {(k if k[0] == '0' else k[0] + str(1 - int(k[1]))): x for k, x in new.items()}   # 受控反閘
BELL = {k: round(abs(a) ** 2, 3) for k, a in amp.items()}
print('第三關：貝爾態的四種結果機率', BELL)

# 第四關：16 個抽屜的格羅弗搜尋（09_grover.js：標記＝寶藏變號；擴散＝a → 2×平均 − a）
N, TREASURE = 16, 11
a = [1 / math.sqrt(N)] * N
GROVER = [a[TREASURE] ** 2]
for r in range(1, 6):
    a[TREASURE] = -a[TREASURE]
    mean = sum(a) / N
    a = [2 * mean - x for x in a]
    GROVER.append(a[TREASURE] ** 2)
print('第四關：第 0–5 輪寶藏的機率', [round(p, 3) for p in GROVER])

# 魔王關：只用 H 和 Z，從 |0> 出發，最少幾個閘能「一定得到 1」？列出所有答案
BOSS = {}
for k in range(1, 5):
    BOSS[k] = []
    for seq in itertools.product('HZ', repeat=k):
        v = [1, 0]
        for g in seq:
            v = apply(GATES[g], v)
        if p1(v) > 0.999:
            BOSS[k].append('→'.join(seq))
    print(f'魔王關：{k} 個閘時，一定得到 1 的排法：{BOSS[k] or "沒有"}')
v = apply(H, apply(H, [1, 0]))
HH_P1 = p1(v)
print(f'魔王關對照：只按 H→H，得到 1 的機率 {HH_P1:.3f}（回到 0）')
