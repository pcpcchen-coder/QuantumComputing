"""父子科技學院 量子電腦學程 Q050：初始化與校準——重置時間預算（只用 Python 標準函式庫）

執行：python reset_budget.py
數字是學程簡報（如何操作量子電腦 第 13 頁）整理的代表值，依晶片與平台而異，只用來練習估算。
"""
import math

H = 6.62607015e-34      # 普朗克常數 J·s
KB = 1.380649e-23       # 波茲曼常數 J/K


def thermal_p1(f_ghz, t_mk):
    """兩能階在溫度 T 下停在 |1⟩ 的機率（約等於 exp(−hf/kBT)）。"""
    x = H * f_ghz * 1e9 / (KB * t_mk * 1e-3)
    return 1 / (1 + math.exp(x))


print('一、殘留熱激發（5 GHz 量子位元）')
for t in (10, 40, 50, 60):
    print(f'  等效溫度 {t:>2} mK → 約 {thermal_p1(5, t):.2e}（{thermal_p1(5, t):.2%}）停在 |1⟩')

# 一輪（shot）＝ 線路 + 讀取 + 重置；單位 μs
CIRCUIT, READOUT = 1.0, 1.0
T1 = 50.0                       # 能量弛豫時間 μs（改造區：改成 100 試試）
passive = 5 * T1                # 被動：等 5 T₁
active = READOUT + 0.3 + 0.04 + READOUT   # 主動：讀取、FPGA 判斷、π 脈衝、確認讀取

print('\n二、被動重置 vs 主動重置')
for name, reset in (('被動等待 5 T₁', passive), ('主動重置', active)):
    shot = CIRCUIT + READOUT + reset
    print(f'  {name:<10} 重置 {reset:7.2f} μs，一輪 {shot:7.2f} μs，重置佔 {reset / shot:5.1%}，'
          f'每秒約 {1e6 / shot:,.0f} 輪')
print(f'  被動等待後殘留在 |1⟩：e^-5 ≈ {math.exp(-5):.2%}')
print(f'  主動重置快約 {passive / active:.0f} 倍')
