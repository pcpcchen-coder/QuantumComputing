"""父子科技學院 量子電腦學程 Q128：用本機 Qiskit 重現展覽的八個範例（理想機率，沒有亂數）

安裝（只要一次）：  pip install qiskit
執行：              python qiskit_check.py
用 Qiskit 的 Statevector 算出八個範例（basic-circuits.html 預設選項）最後的理想機率，
結果應該和 exhibit_helper.py 第一段、以及動畫頁面完全一樣。位元字串最右邊是 q0。
Grover 的擴散用 H、X、CZ、X、H 接成，會多一個整體負號，機率完全相同。
"""
from math import pi

from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector


def superposition():
    qc = QuantumCircuit(1); qc.h(0); return qc, [0]


def interference():
    qc = QuantumCircuit(1); qc.h(0); qc.z(0); qc.h(0); return qc, [0]


def bell():
    qc = QuantumCircuit(2); qc.h(0); qc.cx(0, 1); return qc, [0, 1]


def ghz():
    qc = QuantumCircuit(3); qc.h(0); qc.cx(0, 1); qc.cx(1, 2); return qc, [0, 1, 2]


def teleport():
    qc = QuantumCircuit(3); qc.ry(pi / 3, 0); qc.h(1); qc.cx(1, 2); qc.cx(0, 1); qc.h(0); qc.cx(1, 2); qc.cz(0, 2)
    return qc, [2]


def deutsch():
    qc = QuantumCircuit(2); qc.x(1); qc.h([0, 1]); qc.cx(0, 1); qc.h(0); return qc, [0]


def bv():
    qc = QuantumCircuit(4); qc.x(3); qc.h([0, 1, 2, 3]); qc.cx(0, 3); qc.cx(2, 3); qc.h([0, 1, 2]); return qc, [0, 1, 2]


def grover():
    qc = QuantumCircuit(2); qc.h([0, 1]); qc.cz(0, 1)
    qc.h([0, 1]); qc.x([0, 1]); qc.cz(0, 1); qc.x([0, 1]); qc.h([0, 1])
    return qc, [0, 1]


EXAMPLES = [('疊加', superposition), ('干涉', interference), ('Bell 態 Φ⁺', bell), ('GHZ 態（3 顆）', ghz),
            ('隱形傳態', teleport), ('Deutsch', deutsch), ('BV（密碼 101）', bv), ('Grover（答案 11）', grover)]

if __name__ == '__main__':
    for i, (name, f) in enumerate(EXAMPLES, 1):
        qc, meas = f()
        pr = Statevector(qc).probabilities_dict(qargs=meas, decimals=6)
        txt = '、'.join(f'{k} {v * 100:.1f}%' for k, v in sorted(pr.items()) if v > 1e-9)
        print(f'範例 {i} {name}：{qc.num_qubits} 顆位元、{qc.size()} 個閘 → {txt}')
