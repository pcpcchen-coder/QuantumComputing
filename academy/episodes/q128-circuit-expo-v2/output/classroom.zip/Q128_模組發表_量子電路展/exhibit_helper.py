"""父子科技學院 量子電腦學程 Q128：模組發表——量子電路展（純 Python，不需要安裝任何套件，沒有亂數）

執行：  python exhibit_helper.py
一、八張展品卡：照 basic-circuits.html（量子電路入門互動動畫）八個範例的預設選項，
    一步一步算出狀態向量，印出每個範例的位元數、步驟數、量哪幾顆、理想機率，並和頁面上讀到的理想機率比對。
二、振幅逐步：把 MY_EXHIBIT 改成你要發表的範例，印出起點和每一步之後的振幅（發表時的「振幅逐步」那一段）。
三、海報檢查：把海報內容寫進 MY_POSTER，檢查該有的欄位是否齊全、出處有沒有寫、觀眾的問題是不是三個都有回答。
位元字串最右邊是 q0（和動畫、Qiskit 相同）。
"""

# 改造區 1：你要發表的範例（superposition、interference、bell、ghz、teleport、deutsch、bv、grover）
MY_EXHIBIT = 'bell'

# 改造區 2：你的海報（每一行用「標記：內容」）
MY_POSTER = '''
作品名：兩顆位元的默契——貝爾態
一句話：一個哈達瑪閘加一個受控反閘，兩顆位元量起來永遠一樣
線路：q0 做 H，再做 CNOT（q0 控制、q1 目標），最後量 q1 q0
振幅逐步：起點 |00⟩；H 之後 |00⟩、|01⟩ 各 0.707；CNOT 之後 |00⟩、|11⟩ 各 0.707
量測結果：理想 00、11 各 50%；動畫量 1,000 次只出現 00 和 11
出處：量子電路入門互動動畫 basic-circuits.html#bell 範例 3；程式 exhibit_helper.py（Q128 教材）
問題 1：為什麼不會出現 01？
回答 1：CNOT 讓 q1 跟著 q0 翻，所以兩顆永遠一樣
問題 2：如果先把 q1 翻成 1 會怎樣？
回答 2：變成第三種貝爾態，只出現 01 和 10，兩顆永遠相反
問題 3：真的量子電腦也一樣嗎？
回答 3：真實機器有雜訊，會冒出少量 01、10，要量很多次看比例
注意事項：這是理想模擬的結果，不是真實機器的實測
'''

from math import cos, sin, pi, sqrt

R = 1 / sqrt(2)


def apply(st, op):
    """把一個閘作用在狀態向量上（振幅都是實數）"""
    n = len(st)
    g = op[0]
    out = st[:]
    if g in ('h', 'x', 'z', 'ry'):
        q = op[1]
        if g == 'h':
            m = (R, R, R, -R)
        elif g == 'x':
            m = (0, 1, 1, 0)
        elif g == 'z':
            m = (1, 0, 0, -1)
        else:
            th = op[2]
            m = (cos(th / 2), -sin(th / 2), sin(th / 2), cos(th / 2))
        for i in range(n):
            if not (i >> q) & 1:
                j = i | (1 << q)
                a, b = st[i], st[j]
                out[i], out[j] = m[0] * a + m[1] * b, m[2] * a + m[3] * b
    elif g == 'cx':
        c, t = op[1], op[2]
        for i in range(n):
            if (i >> c) & 1:
                out[i] = st[i ^ (1 << t)]
    elif g == 'cz':
        for i in range(n):
            if all((i >> q) & 1 for q in op[1:]):
                out[i] = -st[i]
    elif g == 'diff':
        mean = sum(st) / n
        out = [2 * mean - a for a in st]
    return out


# 八個範例（照 basic-circuits.html 的預設選項；每一步可以有好幾個閘）
EXAMPLES = {
    'superposition': ('疊加（量子硬幣）', 1, [0], [('H 閘：做出疊加', [('h', 0)])]),
    'interference': ('干涉（H‑Z‑H = X）', 1, [0], [('第一個 H', [('h', 0)]), ('Z 閘：只改正負號', [('z', 0)]), ('第二個 H：干涉', [('h', 0)])]),
    'bell': ('Bell 態 Φ⁺', 2, [0, 1], [('H 閘：q0 進入疊加', [('h', 0)]), ('CNOT：糾纏', [('cx', 0, 1)])]),
    'ghz': ('GHZ 態（3 顆）', 3, [0, 1, 2], [('H 閘：q0 進入疊加', [('h', 0)]), ('CNOT q0→q1', [('cx', 0, 1)]), ('CNOT q1→q2', [('cx', 1, 2)])]),
    'teleport': ('隱形傳態（ψ = √¾|0⟩+½|1⟩）', 3, [2], [
        ('準備 ψ（q0）', [('ry', 0, pi / 3)]), ('建立糾纏對（q1、q2）', [('h', 1), ('cx', 1, 2)]),
        ('Alice：CNOT 與 H', [('cx', 0, 1), ('h', 0)]), ('Bob：依 2 個位元修正', [('cx', 1, 2), ('cz', 0, 2)])]),
    'deutsch': ('Deutsch（f(x) = x）', 2, [0], [('X：輔助位元', [('x', 1)]), ('H：兩顆都疊加', [('h', 0), ('h', 1)]),
                                              ('黑盒（只查一次）', [('cx', 0, 1)]), ('H：把相位轉成 0/1', [('h', 0)])]),
    'bv': ('BV（密碼 101）', 4, [0, 1, 2], [('X：輔助位元', [('x', 3)]), ('H：全部疊加', [('h', 0), ('h', 1), ('h', 2), ('h', 3)]),
                                          ('黑盒（只查一次）', [('cx', 0, 3), ('cx', 2, 3)]), ('H：干涉讀出密碼', [('h', 0), ('h', 1), ('h', 2)])]),
    'grover': ('Grover（2 顆，答案 11，1 輪）', 2, [0, 1], [('H：所有答案一樣大', [('h', 0), ('h', 1)]),
                                                     ('第 1 輪・標記', [('cz', 0, 1)]), ('第 1 輪・擴散（對平均值翻轉）', [('diff',)])]),
}

# 製作時在 basic-circuits.html 讀到的理想機率（預設選項，跑到最後一步）
PAGE = {
    'superposition': {'0': 0.5, '1': 0.5}, 'interference': {'1': 1.0}, 'bell': {'00': 0.5, '11': 0.5},
    'ghz': {'000': 0.5, '111': 0.5}, 'teleport': {'0': 0.75, '1': 0.25}, 'deutsch': {'1': 1.0},
    'bv': {'101': 1.0}, 'grover': {'11': 1.0},
}


def run(key):
    name, n, meas, steps = EXAMPLES[key]
    st = [0.0] * (1 << n)
    st[0] = 1.0
    hist = [st]
    for _, ops in steps:
        for op in ops:
            st = apply(st, op)
        hist.append(st)
    return hist


def probs(st, meas):
    out = {}
    for i, a in enumerate(st):
        p = a * a
        if p < 1e-12:
            continue
        k = ''.join(str((i >> q) & 1) for q in sorted(meas, reverse=True))
        out[k] = out.get(k, 0) + p
    return dict(sorted(out.items()))


def ket(st, n):
    return '  '.join(f'{a:+.3f}|{i:0{n}b}⟩' for i, a in enumerate(st) if abs(a) > 1e-9)


def fmt(pr):
    return '、'.join(f'{k} {v * 100:.1f}%' for k, v in pr.items())


FIELDS = ['作品名', '一句話', '線路', '振幅逐步', '量測結果', '注意事項']


def check_poster(text):
    lines = [s.strip() for s in text.strip().splitlines() if s.strip()]
    tags = {}
    for s in lines:
        k, _, v = s.partition('：')
        tags.setdefault(k, v)
    res = [(f'有「{f}」', bool(tags.get(f))) for f in FIELDS[:5]]
    src = tags.get('出處', '')
    res.append(('出處寫了動畫或程式的檔名（.html# 或 .py）', '.html#' in src or '.py' in src))
    q = [k for k in tags if k.startswith('問題')]
    a = [k for k in tags if k.startswith('回答') and tags[k]]
    res.append((f'觀眾問題 {len(q)} 個、回答 {len(a)} 個（要三個都有回答）', len(q) == 3 and len(a) == 3))
    res.append(('有「注意事項」（錯誤、限制或提醒）', bool(tags.get('注意事項'))))
    return res


if __name__ == '__main__':
    print('一、八張展品卡（basic-circuits.html 預設選項，理想機率）')
    ok = 0
    for i, key in enumerate(EXAMPLES, 1):
        name, n, meas, steps = EXAMPLES[key]
        pr = probs(run(key)[-1], meas)
        same = pr.keys() == PAGE[key].keys() and all(abs(pr[k] - PAGE[key][k]) < 1e-9 for k in pr)
        ok += same
        who = ' '.join(f'q{q}' for q in sorted(meas, reverse=True))
        print(f'  範例 {i} {name}：{n} 顆位元、{len(steps)} 步；量 {who} → {fmt(pr)}  {"✓ 和頁面一樣" if same else "✗ 和頁面不同"}')
    print(f'  結果：{ok}/{len(EXAMPLES)} 個範例和頁面一樣')
    name, n, meas, steps = EXAMPLES[MY_EXHIBIT]
    hist = run(MY_EXHIBIT)
    print(f'二、振幅逐步（MY_EXHIBIT = {MY_EXHIBIT!r}：{name}）')
    print(f'  起點：{ket(hist[0], n)}')
    for k, (label, _) in enumerate(steps, 1):
        print(f'  步驟 {k} {label}：{ket(hist[k], n)}')
    print(f'  量測 {" ".join(f"q{q}" for q in sorted(meas, reverse=True))} 的理想機率：{fmt(probs(hist[-1], meas))}')
    print('三、海報檢查（MY_POSTER）')
    res = check_poster(MY_POSTER)
    for label, good in res:
        print(f'  {"✓" if good else "✗"} {label}')
    print(f'  結果：{sum(g for _, g in res)}/{len(res)} 項通過')
