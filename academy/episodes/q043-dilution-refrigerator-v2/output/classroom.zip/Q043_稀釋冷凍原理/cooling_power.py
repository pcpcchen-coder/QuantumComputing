"""父子科技學院 量子電腦學程 Q043：稀釋冷凍原理——冷卻功率計算（任何 Python 3 都能跑，不需安裝套件）

公式：Q = 84 × n × T²     Q：瓦特（W）  n：氦三循環率（mol/s）  T：混合腔溫度（K）
執行：python cooling_power.py
"""

N_MMOL = 0.5            # 氦三循環率，單位 mmol/s（典型值；動畫預設也是 0.5）


def cooling_power_uw(t_mk, n_mmol=N_MMOL):
    n = n_mmol / 1000   # mmol/s → mol/s
    t = t_mk / 1000     # mK → K
    q = 84 * n * t ** 2  # 瓦特
    return q * 1e6      # W → μW


def balance_temp_mk(load_uw, n_mmol=N_MMOL):
    """冷卻功率剛好等於熱負載時的溫度：T = √(Q ÷ 84n)"""
    q = load_uw / 1e6
    n = n_mmol / 1000
    return (q / (84 * n)) ** 0.5 * 1000


print('溫度 (mK)   冷卻功率 (μW)')
for t in [100, 50, 40, 30, 20, 10, 5]:
    print(f'{t:>8}   {cooling_power_uw(t):>10.2f}')

print()
print('溫度減半大魔王：')
for a, b in [(40, 20), (20, 10), (10, 5)]:
    print(f'{a} mK → {b} mK：{cooling_power_uw(a):.2f} → {cooling_power_uw(b):.2f} μW，'
          f'剩 {cooling_power_uw(b) / cooling_power_uw(a):.2f} 倍')

print()
for load in [10, 40]:
    print(f'熱負載 {load} μW → 平衡溫度約 {balance_temp_mk(load):.1f} mK')

# 改造區：把 N_MMOL 改成 1.0 或 1.5，看冷卻功率和平衡溫度怎麼變
