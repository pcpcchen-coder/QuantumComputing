"""父子科技學院 量子電腦學程 Q113：讀圖之前——三個約定與今天用到的閘（純 Python，不需安裝任何套件）

執行：  python read_order.py
它用一個很小的狀態向量模擬器（只認得 H、X、Z、CX 四種閘），印出：
  一、約定二：位元字串裡 q0 寫在最右邊
  二、約定三：振幅有正有負，機率 = 振幅²
  三、四種閘把 |0⟩、|1⟩ 變成什麼
  四、改造區：你自己畫的兩閘線路
"""
from math import sqrt

R2 = 1 / sqrt(2)


def run(n, gates):
    """n 顆位元都從 |0⟩ 出發，由左往右依序做 gates，回傳 2ⁿ 個振幅（第 i 個對應位元字串 bits(i)）"""
    s = [0.0] * (1 << n)
    s[0] = 1.0
    for g in gates:
        name, q = g[0], g[1]
        m = 1 << q
        if name == 'h':
            for i in range(len(s)):
                if not i & m:
                    a, b = s[i], s[i | m]
                    s[i], s[i | m] = (a + b) * R2, (a - b) * R2
        elif name == 'x':
            for i in range(len(s)):
                if not i & m:
                    s[i], s[i | m] = s[i | m], s[i]
        elif name == 'z':
            for i in range(len(s)):
                if i & m:
                    s[i] = -s[i]
        elif name == 'cx':  # ('cx', 控制, 目標)
            mt = 1 << g[2]
            for i in range(len(s)):
                if i & m and not i & mt:
                    s[i], s[i | mt] = s[i | mt], s[i]
        else:
            raise ValueError('只認得 h、x、z、cx：' + name)
    return s


def bits(i, n):
    """位元字串：最左邊是編號最大的位元，最右邊是 q0（和 Qiskit 相同）"""
    return ''.join(str((i >> q) & 1) for q in range(n - 1, -1, -1))


def amp(a):
    return '0' if abs(a) < 1e-9 else ('+' if a > 0 else '−') + f'{abs(a):.3f}'


def show(title, n, gates):
    s = run(n, gates)
    line = '  '.join(f'|{bits(i, n)}⟩ {amp(a)}（{a * a * 100:.0f}%）' for i, a in enumerate(s) if abs(a) > 1e-9)
    print(f'  {title:<16} {line}')


def label(gates):
    return ' → '.join(f'{g[0].upper()}(q{g[1]})' if g[0] != 'cx' else f'CX(q{g[1]}→q{g[2]})' for g in gates) or '（沒有閘）'


if __name__ == '__main__':
    print('一、約定二：位元字串裡 q0 寫在最右邊（兩顆位元，字串是 q1 q0）')
    show('X(q0)', 2, [('x', 0)])
    show('X(q1)', 2, [('x', 1)])
    print('二、約定三：振幅有正有負，機率 = 振幅²，負號量不到')
    show('H', 1, [('h', 0)])
    show('H → Z', 1, [('h', 0), ('z', 0)])
    print('三、四種閘（由左往右：先準備起點，再做這個閘）')
    show('H：|0⟩ 起點', 1, [('h', 0)])
    show('H：|1⟩ 起點', 1, [('x', 0), ('h', 0)])
    show('X：|0⟩ 起點', 1, [('x', 0)])
    show('X：|1⟩ 起點', 1, [('x', 0), ('x', 0)])
    show('Z：|0⟩ 起點', 1, [('z', 0)])
    show('Z：|1⟩ 起點', 1, [('x', 0), ('z', 0)])
    show('CX：控制 q0 = 0', 2, [('cx', 0, 1)])
    show('CX：控制 q0 = 1', 2, [('x', 0), ('cx', 0, 1)])

    # 四、改造區：自己畫一條兩閘線路。每個閘寫成 ('h', 位元)、('x', 位元)、('z', 位元) 或 ('cx', 控制, 目標)
    MY_N = 2
    MY_CIRCUIT = [('x', 1), ('h', 0)]
    print(f'四、改造區：{MY_N} 顆位元，{label(MY_CIRCUIT)}')
    show('我的線路', MY_N, MY_CIRCUIT)
