"""父子科技學院 量子電腦學程 Q113：用本機 Qiskit 確認位元順序（選用，不需要帳號）

安裝（只要一次）：  pip install qiskit
執行：              python qiskit_check.py
"""
from qiskit import QuantumCircuit
from qiskit.primitives import StatevectorSampler
from qiskit.quantum_info import Statevector

for name, q in (('只翻 q0', 0), ('只翻 q1', 1)):
    qc = QuantumCircuit(2, 2)
    qc.x(q)                       # 翻轉閘：只作用在一顆位元
    sv = Statevector.from_instruction(qc)
    qc.measure([0, 1], [0, 1])
    counts = StatevectorSampler(seed=2026).run([qc], shots=1000).result()[0].data.c.get_counts()
    print(name, '機率', {str(k): round(float(v), 3) for k, v in sv.probabilities_dict().items()}, '量測 1000 次', counts)   # 位元字串最右邊是 q0

qc = QuantumCircuit(1)
qc.h(0)
qc.z(0)                           # 哈達瑪閘之後再做相位翻轉閘
sv = Statevector.from_instruction(qc)
print('H → Z 振幅', [round(float(a.real), 3) for a in sv.data], '機率', {str(k): round(float(v), 3) for k, v in sv.probabilities_dict().items()})
print(qc.draw())
