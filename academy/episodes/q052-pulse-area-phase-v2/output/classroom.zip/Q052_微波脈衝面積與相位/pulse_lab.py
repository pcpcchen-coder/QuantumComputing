"""父子科技學院 量子電腦學程 Q052：微波脈衝——面積與相位的小實驗室（只用 Python 標準函式庫）

執行：python pulse_lab.py
模型：旋轉座標中的方波脈衝，旋轉軸 = (cos φ, sin φ, Δ/Ω)。和動畫一樣忽略退相干，只用來練習「面積轉幾度、相位繞哪軸」。
"""
import math


def rotate(v, axis, angle):
    """把布洛赫向量 v 繞 axis 轉 angle（弧度），羅德里格斯公式。"""
    n = math.sqrt(sum(a * a for a in axis))
    a, b, c = (x / n for x in axis)
    x, y, z = v
    co, si = math.cos(angle), math.sin(angle)
    d = a * x + b * y + c * z
    return (x * co + (b * z - c * y) * si + a * d * (1 - co),
            y * co + (c * x - a * z) * si + b * d * (1 - co),
            z * co + (a * y - b * x) * si + c * d * (1 - co))


def pulse(v, area_deg, phase_deg=0, detune_mhz=0, t_ns=40):
    """送一個方波脈衝：面積 area_deg（度）、相位 phase_deg（度）、失諧 detune_mhz、時間 t_ns。"""
    omega = math.radians(area_deg) / t_ns            # 拉比角頻率 rad/ns
    delta = 2 * math.pi * detune_mhz * 1e-3          # 失諧角頻率 rad/ns
    ph = math.radians(phase_deg)
    axis = (omega * math.cos(ph), omega * math.sin(ph), delta)
    return rotate(v, axis, math.sqrt(omega ** 2 + delta ** 2) * t_ns)


def show(name, v):
    p1 = (1 - v[2]) / 2
    print(f'  {name:<22} 箭頭 (x, y, z) = ({v[0]:+.2f}, {v[1]:+.2f}, {v[2]:+.2f})  量到 1 的機率 {p1:.3f}')


NORTH = (0.0, 0.0, 1.0)
print('一、面積決定轉幾度（相位 0°）')
for a in (45, 90, 180, 270, 360):
    show(f'面積 {a}°', pulse(NORTH, a))

print('\n二、相位決定繞哪條軸（面積 90°）')
for ph in (0, 90, 180, 270):
    show(f'相位 {ph}°', pulse(NORTH, 90, ph))

print('\n三、闖關檢查')
v = NORTH
for _ in range(4):
    v = pulse(v, 45)
show('45° 送四次', v)
show('90°@0° 再 90°@180°', pulse(pulse(NORTH, 90, 0), 90, 180))

print('\n四、控制變因：面積 180°、相位 0°，只改失諧（方波 40 ns，平均拉比頻率 12.5 MHz）')
for d in (0, 5, 10, 20):   # 改造區：自己加 2.5、15 試試
    tilt = math.degrees(math.atan2(d, 12.5))
    v = pulse(NORTH, 180, 0, d)
    print(f'  失諧 {d:>4} MHz  軸翹起 {tilt:4.1f}°  量到 1 的機率 {(1 - v[2]) / 2:.3f}')
