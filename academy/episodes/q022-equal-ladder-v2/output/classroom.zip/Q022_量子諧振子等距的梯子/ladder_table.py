"""父子科技學院 量子電腦學程 Q022：能階梯子表——等距（LC）與不等距（約瑟夫森接面）。

不用安裝任何套件，只要 Python 3。執行：  python ladder_table.py
一、LC 電路：f = 1/(2π√(LC))（維基百科 LC circuit），量子化後 E_n = hf(n + ½)，每一階的間距都是 hf。
二、約瑟夫森接面做的量子位元（transmon）：H = 4E_C n² − E_J cos φ 在電荷基底上算出前幾個能階
    （和學程動畫 lc-vs-jj.html 第 3 步同一種算法：三對角矩陣 + 二分法數特徵值），E_C/h = 0.25 GHz。
能量都用「除以普朗克常數 h」之後的頻率（GHz）表示。
"""
from math import pi, sqrt

EC = 0.25  # GHz


def lc_frequency(L, C):
    return 1 / (2 * pi * sqrt(L * C))


def lc_levels(f, k=5):
    return [f * (n + 0.5) for n in range(k)]


def transmon_levels(EJ, k=5, N=25):
    """H = 4E_C n² − (E_J/2)(|n⟩⟨n+1| + h.c.)，n = −N…N；回傳最低 k 個能量（加 E_J，讓谷底為 0）。"""
    d = [4 * EC * (i - N) ** 2 for i in range(2 * N + 1)]
    e2 = (EJ / 2) ** 2

    def count(x):  # 小於 x 的特徵值個數（Sturm 序列）
        c, q = 0, d[0] - x
        if q < 0:
            c += 1
        for i in range(1, len(d)):
            q = d[i] - x - e2 / (q if q != 0 else 1e-300)
            if q < 0:
                c += 1
        return c

    out = []
    for j in range(k):
        lo, hi = -EJ - 1, 4 * EC * N * N + EJ + 1
        for _ in range(70):
            m = (lo + hi) / 2
            if count(m) > j:
                hi = m
            else:
                lo = m
        out.append((lo + hi) / 2 + EJ)
    return out


def gaps(levels):
    return [b - a for a, b in zip(levels, levels[1:])]


def z(x):
    """浮點誤差造成的 −0.000 顯示成 0"""
    return 0.0 if abs(x) < 1e-9 else x


print('一、LC 電路：每一階的間距（GHz）')
LC = {}
for L, C, name in ((1e-9, 1e-12, '1 nH、1 pF'), (4e-9, 1e-12, '4 nH、1 pF（電感換大）'), (0.25e-9, 1e-12, '0.25 nH、1 pF（電感換小）')):
    f = lc_frequency(L, C) / 1e9
    g = gaps(lc_levels(f))
    LC[name] = g
    print(f'  {name:<22} 0→1 {g[0]:.3f}　1→2 {g[1]:.3f}　2→3 {g[2]:.3f}　3→4 {g[3]:.3f}　差 {z(1000 * (g[1] - g[0])):.0f} MHz')

print()
print('二、約瑟夫森接面做的量子位元（E_C/h = 0.25 GHz）')
TR = {}
for ratio in (50, 80):
    g = gaps(transmon_levels(ratio * EC))
    TR[ratio] = g
    print(f'  E_J/E_C = {ratio:<3}  0→1 {g[0]:.3f}　1→2 {g[1]:.3f}　2→3 {g[2]:.3f}　3→4 {g[3]:.3f}　非諧性 {z(1000 * (g[1] - g[0])):.0f} MHz')

print()
print('三、微波對準 0→1 時，其他跳躍差多遠（GHz）')
for name, g in (('LC 1 nH、1 pF', LC['1 nH、1 pF']), ('transmon E_J/E_C = 50', TR[50])):
    print(f'  {name:<22} ' + '　'.join(f'{k}→{k + 1} 差 {z(g[k] - g[0]):.3f}' for k in range(1, 4)))
