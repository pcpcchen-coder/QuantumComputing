"""父子科技學院 量子電腦學程 Q014：量子態很怕吵——用數字看雜訊。

不用安裝任何套件，只要 Python 3。執行：  python noise_numbers.py
可以改下面的 FREQ_GHZ（量子位元頻率）、FRIDGE_MK（冰箱溫度）、T2_US、GATE_NS 看看數字怎麼變。
"""
import math

FREQ_GHZ = 5       # 量子位元頻率（吉赫）
FRIDGE_MK = 10     # 冰箱最底層的溫度（毫克耳文）
T2_US = 100        # 相位相干時間（微秒）
GATE_NS = 25       # 一個閘要多久（奈秒）

h, kB = 6.62607015e-34, 1.380649e-23
qubit_mK = h * FREQ_GHZ * 1e9 / kB * 1000
ratio = qubit_mK / FRIDGE_MK
print(f'{FREQ_GHZ} GHz 量子位元的能量，約等於 {qubit_mK:.0f} mK 的熱')
print(f'冰箱 {FRIDGE_MK} mK：量子位元能量是熱的 {ratio:.1f} 倍，被熱踢上去的機會約 e^-{ratio:.1f} ≈ {math.exp(-ratio):.1e}')
print(f'相位相干時間 {T2_US} 微秒 ÷ 閘時間 {GATE_NS} 奈秒 ≈ {T2_US * 1000 / GATE_NS:.0f} 個閘')
print()
print('動畫 index.html#bloch 的示意（相對時間）：')
for t in (0, 3, 6, 9, 12):
    print(f'  t = {t:2d}：能量弛豫模式 P(1) = {math.exp(-t / 5):.2f}；拉姆齊模式 箭頭大小 = {math.exp(-t / 6):.2f}')
