"""父子科技學院 量子電腦學程 Q021：彈簧、單擺、LC 電路的週期對照。

不用安裝任何套件，只要 Python 3。執行：  python oscillation_table.py
公式（維基百科 Simple harmonic motion、Pendulum (mechanics)、LC circuit）：
  彈簧    T = 2π√(m/k)
  單擺    T0 = 2π√(ℓ/g)（小角度）；任意振幅 T = T0 / AGM(1, cos(θ0/2))（算術幾何平均）
  LC 電路 T = 2π√(LC)，f = 1/T
把下面的數字換成你家量到的值，再跑一次。
"""
from math import pi, sqrt, cos, radians

G = 9.81  # 重力加速度（m/s²）


def spring_period(m, k):
    return 2 * pi * sqrt(m / k)


def pendulum_small(length):
    return 2 * pi * sqrt(length / G)


def agm(a, b):
    while abs(a - b) > 1e-15:
        a, b = (a + b) / 2, sqrt(a * b)
    return a


def pendulum_ratio(theta_deg):
    """大振幅週期 ÷ 小角度週期"""
    return 1 / agm(1.0, cos(radians(theta_deg) / 2))


def lc_period(L, C):
    return 2 * pi * sqrt(L * C)


print('一、彈簧（彈簧常數 k = 20 N/m）')
SPRING = []
for m in (0.1, 0.2, 0.4, 0.8):
    SPRING.append((m, spring_period(m, 20)))
    print(f'  重物 {m * 1000:4.0f} g  →  週期 {spring_period(m, 20):.3f} 秒')
print('  質量變成 4 倍（0.1 → 0.4 kg），週期變成', round(spring_period(0.4, 20) / spring_period(0.1, 20), 3), '倍')

print()
print('二、單擺（小角度）')
PEND = []
for length in (0.25, 0.5, 1.0):
    PEND.append((length, pendulum_small(length)))
    print(f'  擺長 {length:4.2f} m  →  週期 {pendulum_small(length):.3f} 秒（和重物多重無關）')
print('  擺長變成 1/4（1 → 0.25 m），週期變成', round(pendulum_small(0.25) / pendulum_small(1.0), 3), '倍')

print()
print('三、單擺拉到大角度：週期是小角度時的幾倍')
RATIO = {}
for th in (5, 10, 20, 30, 45, 60, 90):
    RATIO[th] = pendulum_ratio(th)
    print(f'  從 {th:2d} 度放手  →  {RATIO[th]:.4f} 倍')

print()
print('四、LC 電路')
LC = []
for L, C, name in ((1e-3, 1e-6, '1 mH、1 μF'), (1e-9, 1e-12, '1 nH、1 pF')):
    T = lc_period(L, C)
    LC.append((name, 1 / T))
    print(f'  {name}  →  週期 {T:.3e} 秒，每秒振盪 {1 / T:.3e} 次')
print('  電感變成 4 倍（1 nH → 4 nH），週期變成', round(lc_period(4e-9, 1e-12) / lc_period(1e-9, 1e-12), 3), '倍')
