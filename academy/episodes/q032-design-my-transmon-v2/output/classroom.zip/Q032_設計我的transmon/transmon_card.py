"""父子科技學院 量子電腦學程 Q032：transmon 參數設計器（只要 Python 3，不用安裝套件）。

執行：  python transmon_card.py
用電荷基底哈密頓量 H = 4E_C(n − n_g)² − (E_J/2)(|n⟩⟨n+1| + h.c.) 求能階（和動畫 index.html#potential、
transmon-3d.html 第 1 章電容分頁同一條公式）。能量都用「除以 h 之後的頻率」，單位 GHz。
想設計自己的卡：改最下面 MY_EJ、MY_EC、MY_FR 三個數字再執行。
"""
import math

EC_PER_FF = 19.37     # E_C/h [GHz] = e²/(2hC) = 19.37 / C[fF]（transmon-3d.html 第 359 行）
EJ_PER_NA = 0.4966    # E_J/h [GHz] = Φ₀I_c/(2πh) ≈ 0.4966 × I_c[nA]


def levels(ej, ec, ng=0.0, k=4, n=25):
    """最低 k 個能階（Sturm 序列二分法，三對角矩陣）。"""
    d = [4 * ec * (m - ng) ** 2 for m in range(-n, n + 1)]
    e2 = (ej / 2) ** 2

    def count(x):
        q = d[0] - x
        c = 1 if q < 0 else 0
        for di in d[1:]:
            q = di - x - e2 / (q if q != 0 else 1e-300)
            if q < 0:
                c += 1
        return c
    out = []
    for j in range(k):
        lo, hi = -ej - 1, 4 * ec * (n + 1) ** 2 + ej + 1
        for _ in range(90):
            mid = (lo + hi) / 2
            if count(mid) > j:
                hi = mid
            else:
                lo = mid
        out.append((lo + hi) / 2)
    return out


def card(ej, ec, fr=None, g=0.1):
    e = levels(ej, ec)
    f01, f12 = e[1] - e[0], e[2] - e[1]
    h = levels(ej, ec, 0.5)
    c = {'E_J/h (GHz)': ej, 'E_C/h (GHz)': ec, 'E_J/E_C': ej / ec, 'f01 (GHz)': f01, 'f12 (GHz)': f12,
         'alpha (MHz)': (f12 - f01) * 1000, '近似 f01 (GHz)': math.sqrt(8 * ej * ec) - ec,
         '電荷色散 (kHz)': abs(f01 - (h[1] - h[0])) * 1e6, 'C_sigma (fF)': EC_PER_FF / ec, 'I_c (nA)': ej / EJ_PER_NA}
    if fr is not None:
        delta, a = f01 - fr, (f12 - f01)
        chi = g * g * a / (delta * (delta + a))          # 簡報 p37：χ = g²α / [Δ(Δ+α)]
        kappa = 2 * abs(chi)                             # 令 κ ≈ 2|χ|
        c.update({'讀取腔 (GHz)': fr, '失諧 Δ (GHz)': delta, '|Δ|/g': abs(delta) / g, 'chi (MHz)': chi * 1000,
                  'kappa (MHz)': kappa * 1000, 'Purcell T1 上限 (us)': 1 / (2 * math.pi * kappa * 1e9 * (g / delta) ** 2) * 1e6})
    return c


def show(name, c):
    print(name)
    for k, v in c.items():
        print(f'  {k:>18}: {v:,.4g}')


def ej_for(target, ec):
    """E_C 固定時，找出讓 f01 = target 的 E_J（二分法）。"""
    lo, hi = ec, 400 * ec
    for _ in range(60):
        mid = (lo + hi) / 2
        e = levels(mid, ec, k=2)
        if e[1] - e[0] < target:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2


print('一、範例卡（transmon 簡報 p12：E_J/h = 15 GHz、E_C/h = 250 MHz）＋讀取腔 7 GHz')
EXAMPLE = card(15, 0.25, fr=7.0)
show('  範例', EXAMPLE)

print()
print('二、製程誤差：E_J 多 2%（15 → 15.3 GHz）')
SHIFT = card(15.3, 0.25)['f01 (GHz)'] - EXAMPLE['f01 (GHz)']
print(f'  f01 偏移 {SHIFT * 1000:+.0f} MHz（{SHIFT / EXAMPLE["f01 (GHz)"] * 100:+.2f}%）')

print()
print('三、目標 5 GHz、E_C/h = 250 MHz：需要的 E_J')
EJ5 = ej_for(5.0, 0.25)
show(f'  E_J/h = {EJ5:.2f} GHz', card(EJ5, 0.25, fr=7.0))

print()
print('四、簡報 p37 的讀取範例（f01 5.0 GHz、α −250 MHz、讀取腔 7.0 GHz、g 100 MHz）')
d, a, g = -2.0, -0.25, 0.1
chi = g * g * a / (d * (d + a))
P37 = 1 / (2 * math.pi * 2 * abs(chi) * 1e9 * (g / d) ** 2) * 1e6
print(f'  χ = {chi * 1000:.2f} MHz，κ = 2|χ| = {2 * abs(chi) * 1000:.2f} MHz，Purcell T1 上限 ≈ {P37:.0f} μs，臨界光子數 Δ²/4g² = {d * d / (4 * g * g):.0f}')
for dd in (-1.0, -2.0, -3.0):
    t = 1 / (2 * math.pi * 2 * abs(chi) * 1e9 * (g / dd) ** 2) * 1e6
    print(f'  同樣 κ，失諧 {dd:+.1f} GHz → Purcell T1 上限 ≈ {t:.0f} μs')

print()
print('五、動畫 index.html#potential（E_C/h 固定 250 MHz）的讀數')
SCENE = {}
for r in (10, 50, 100):
    c = card(r * 0.25, 0.25)
    SCENE[r] = c
    print(f'  E_J/E_C = {r:3d}：f01 = {c["f01 (GHz)"]:.3f} GHz、f12 = {c["f12 (GHz)"]:.3f} GHz、α = {c["alpha (MHz)"]:.0f} MHz、近似 {c["近似 f01 (GHz)"]:.3f} GHz')

# 想設計自己的卡：改這三個數字
MY_EJ, MY_EC, MY_FR = 15.0, 0.25, 7.0
print()
show('六、我的卡', card(MY_EJ, MY_EC, fr=MY_FR))
