"""父子科技學院 量子電腦學程 Q023：約瑟夫森接面的三個數字小實驗。

不用安裝任何套件，只要 Python 3。執行：  python tunnel_check.py
一、直流約瑟夫森效應  I = Ic sin φ（學程簡報 JJ_Microwave_Readout_Talk p13）
二、交流約瑟夫森效應  f = (2e/h) V，約 483.6 GHz/mV（同上；維基百科 Josephson voltage standard）
三、穿隧和厚度：穿過去的比例隨厚度「指數」變小（維基百科 Quantum tunnelling）
    這裡的 1 % 只是好算的例子，不是真實氧化鋁的數值。
"""
from math import sin, asin, radians, degrees

E = 1.602176634e-19   # 基本電荷（庫侖，SI 定義值）
H = 6.62607015e-34    # 普朗克常數（焦耳·秒，SI 定義值）
IC_NA = 40            # 臨界電流的例子（nA）：簡報的典型值是 20–60 nA

print('一、直流效應：I = Ic sin φ（Ic =', IC_NA, 'nA）')
DC = {}
for deg in (0, 30, 60, 78.5, 90):
    DC[deg] = IC_NA * sin(radians(deg))
    print(f'  相位差 {deg:5.1f} 度  →  電流 {DC[deg]:5.1f} nA')
PHASE = {r: degrees(asin(r)) for r in (0.5, 0.98)}
print('  反過來：電流是 0.5 Ic → 相位差', round(PHASE[0.5], 1), '度；0.98 Ic →', round(PHASE[0.98], 1), '度')
print('  電流想超過 Ic？sin φ 最大只有 1，相位差鎖不住，接面兩端就會出現電壓。')

print()
print('二、交流效應：f = (2e/h) × V')
KJ_GHZ_PER_MV = 2 * E / H / 1e9 / 1e3
print(f'  2e/h = {KJ_GHZ_PER_MV:.4f} GHz / mV')
AC = {}
for uv in (1, 10, 100, 1000):
    AC[uv] = KJ_GHZ_PER_MV * uv / 1000
    print(f'  電壓 {uv:5d} μV  →  電流振盪 {AC[uv]:9.4f} GHz')

print()
print('三、穿隧和厚度：假設 1 份厚度只讓 1 % 穿過去（好算的例子）')
P1 = 0.01
TUNNEL = {}
for n in (1, 2, 3):
    TUNNEL[n] = P1 ** n
    print(f'  厚度 {n} 份  →  穿過去 {TUNNEL[n] * 100:.4f} %')
print('  如果和厚度「成反比」，厚一倍會剩 0.5 %；實際是指數，只剩 0.01 %，小了五十倍。')
