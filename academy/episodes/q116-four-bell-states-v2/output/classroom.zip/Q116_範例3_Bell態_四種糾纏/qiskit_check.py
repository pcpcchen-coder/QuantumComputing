"""父子科技學院 量子電腦學程 Q116：用本機 Qiskit 重現四個 Bell 態（選用，不需要帳號）

安裝（只要一次）：  pip install qiskit
執行：              python qiskit_check.py
"""
from qiskit import QuantumCircuit
from qiskit.primitives import StatevectorSampler
from qiskit.quantum_info import DensityMatrix, Operator, Pauli, Statevector, partial_trace


def bell(name):
    qc = QuantumCircuit(2)
    if name in ('Φ⁻', 'Ψ⁻'):
        qc.x(0)              # 開頭先翻 q0：H 之後帶進負號
    if name in ('Ψ⁺', 'Ψ⁻'):
        qc.x(1)              # 開頭先翻 q1：CNOT 之後兩顆相反
    qc.h(0)                  # 哈達瑪閘：q0 進入疊加
    qc.cx(0, 1)              # 受控反閘：q0 控制、q1 目標
    return qc


def size(sv, keep):
    """單看第 keep 顆：把另一顆 trace 掉，算 Bloch 向量的大小"""
    rho = partial_trace(DensityMatrix(sv), [1 - keep])
    v = [rho.expectation_value(Pauli(p)).real for p in 'XYZ']
    return round(sum(c * c for c in v) ** 0.5, 3) + 0.0


for name in ('Φ⁺', 'Φ⁻', 'Ψ⁺', 'Ψ⁻'):
    qc = bell(name)
    sv = Statevector.from_instruction(qc)
    m = qc.copy()
    m.measure_all()
    counts = StatevectorSampler(seed=2026).run([m], shots=1000).result()[0].data.meas.get_counts()
    print(name, '振幅', [round(float(a.real), 3) + 0.0 for a in sv.data],
          '單看 q0', size(sv, 0), '單看 q1', size(sv, 1), '量測 1000 次', dict(sorted(counts.items())))

xh, hz = QuantumCircuit(1), QuantumCircuit(1)
xh.x(0)
xh.h(0)
hz.h(0)
hz.z(0)
print('先 X 再 H，和先 H 再 Z，是同一個運算嗎？', Operator(xh).equiv(Operator(hz)))
print(bell('Ψ⁻').draw())
