"""父子科技學院 量子電腦學程 Q116：範例 3 Bell 態——四種糾纏（純 Python，不需安裝任何套件）

執行：  python bell_lab.py
它用一個很小的兩顆位元模擬器（只認得 H、X、Z、CNOT），印出：
  一、逐步看振幅：H（q0）→ CNOT（q0 → q1），CNOT 把 |01⟩ 那根搬到 |11⟩
  二、四個 Bell 態：開頭加什麼、狀態、單看每一顆的 Bloch 向量大小
  三、各量測 1000 次（固定的亂數種子；換種子次數會不一樣）
  四、對照組：只做 H 的那一顆，量起來也是一半一半，向量大小卻還是 1；只量 q0 一次之後又如何
  五、X 再 H 等於 H 再 Z：所以「開頭的 X」也可以說成「後面補一個 Z」
  六、改造區：自己排一條線路，先預測，再執行
位元字串寫成 |q1 q0⟩：右邊那位是 q0（和 Qiskit、basic-circuits.html 一樣）。
"""
import random
from math import sqrt

R2 = 1 / sqrt(2)
KETS = ['00', '01', '10', '11']          # 第 i 根柱子 = |q1 q0⟩，i = 2·q1 + q0


def run(gates):
    """兩顆位元從 |00⟩ 出發，依序做 gates，回傳四個振幅 [|00⟩, |01⟩, |10⟩, |11⟩]
    閘的寫法：('h', q)、('x', q)、('z', q)、('cx', 控制, 目標)"""
    s = [1.0, 0.0, 0.0, 0.0]
    for g in gates:
        if g[0] == 'cx':
            c, t = 1 << g[1], 1 << g[2]
            s = [s[i ^ t] if i & c else s[i] for i in range(4)]
            continue
        name, m = g[0], 1 << g[1]
        new = s[:]
        for i in range(4):
            if i & m:
                continue
            a, b = s[i], s[i | m]                       # 這一顆是 0、是 1 的兩個振幅
            if name == 'h':
                new[i], new[i | m] = (a + b) * R2, (a - b) * R2
            elif name == 'x':
                new[i], new[i | m] = b, a
            elif name == 'z':
                new[i], new[i | m] = a, -b
            else:
                raise ValueError('只認得 h、x、z、cx：' + name)
        s = new
    return s


def bloch(s, q):
    """單看第 q 顆的 Bloch 向量（振幅都是實數，所以只有 x、z 兩個分量）"""
    m = 1 << q
    x = sum(2 * s[i] * s[i | m] for i in range(4) if not i & m)
    z = sum((-1 if i & m else 1) * s[i] ** 2 for i in range(4))
    return x, z


def size(s, q):
    x, z = bloch(s, q)
    return sqrt(x * x + z * z)


def num(v):
    return '0' if abs(v) < 1e-9 else ('+' if v > 0 else '−') + f'{abs(v):.3f}'


def ket(s):
    """把振幅寫成 (+|00⟩ +|11⟩)/√2 這種式子（只處理本課用到的情形）"""
    nz = [(i, a) for i, a in enumerate(s) if abs(a) > 1e-9]
    body = ''.join(('−' if a < 0 else '') + f'|{KETS[i]}⟩' if k == 0 else (' − ' if a < 0 else ' + ') + f'|{KETS[i]}⟩'
                   for k, (i, a) in enumerate(nz))
    return body if len(nz) == 1 else f'({body})/√2'


def same(a, b):
    return all(abs(x - y) < 1e-9 for x, y in zip(a, b))


def gname(g):
    return f'CNOT(q{g[1]}→q{g[2]})' if g[0] == 'cx' else f'{g[0].upper()}(q{g[1]})'


def show(label, s):
    print(f'  {label:<16}' + '  '.join(f'|{KETS[i]}⟩ {num(a)}' for i, a in enumerate(s))
          + f'   單看 q0 {size(s, 0):.3f}  單看 q1 {size(s, 1):.3f}')


def measure_q0(s, rng):
    """只量 q0 一次：回傳結果和量完之後的狀態（另一半的振幅歸零，再重新調整大小）"""
    p1 = sum(s[i] ** 2 for i in range(4) if i & 1)
    bit = 1 if rng.random() < p1 else 0
    kept = [a if (i & 1) == bit else 0.0 for i, a in enumerate(s)]
    norm = sqrt(sum(a * a for a in kept))
    return bit, [a / norm for a in kept]


def shots(s, n, rng):
    """兩顆一起量 n 次：每次以機率 振幅² 得到 00、01、10、11 其中一個"""
    counts = {k: 0 for k in KETS}
    for _ in range(n):
        r, i = rng.random(), 0
        while i < 3 and r >= s[i] ** 2:
            r -= s[i] ** 2
            i += 1
        counts[KETS[i]] += 1
    return counts


H0, CX = ('h', 0), ('cx', 0, 1)
BELL = [H0, CX]
FOUR = [('Φ⁺', []), ('Φ⁻', [('x', 0)]), ('Ψ⁺', [('x', 1)]), ('Ψ⁻', [('x', 0), ('x', 1)])]

if __name__ == '__main__':
    rng = random.Random(1116)
    print('一、逐步看振幅（Φ⁺）  每列最後是「單看那一顆」的 Bloch 向量大小')
    show('起點', run([]))
    show('H(q0)', run([H0]))
    show('H(q0) → CNOT', run(BELL))
    print('二、四個 Bell 態：同一條線路，只差開頭加的 X')
    for name, prep in FOUR:
        s = run(prep + BELL)
        lead = '、'.join(gname(g) for g in prep) or '不加'
        print(f'  {name}  開頭：{lead:<13}狀態 {ket(s):<20}單看 q0 {size(s, 0):.3f}  單看 q1 {size(s, 1):.3f}')
    print('三、各量測 1000 次（兩顆一起量；random 種子 1116）')
    for name, prep in FOUR:
        c = shots(run(prep + BELL), 1000, rng)
        print(f'  {name}  ' + '  '.join(f'{k} → {v} 次' for k, v in c.items()))
    print('四、對照組：只做 H(q0)，不做 CNOT；以及量完一顆之後')
    s = run([H0])
    p0 = sum(s[i] ** 2 for i in range(4) if not i & 1)
    print(f'  單看 q0：量到 0 的機率 {p0 * 100:.0f}%，Bloch 向量大小 {size(s, 0):.3f}（一半一半，卻沒有變短）')
    bit, after = measure_q0(run(BELL), rng)
    print(f'  Φ⁺ 只量 q0 一次之後：單看 q0 {size(after, 0):.3f}  單看 q1 {size(after, 1):.3f}（量測把糾纏拆開，兩顆都回到 1）')
    print('五、開頭的 X 等於後面補一個 Z')
    a, b = run([('x', 0), H0]), run([H0, ('z', 0)])
    print(f'  X(q0) → H(q0)：{ket(a)}   H(q0) → Z(q0)：{ket(b)}   一樣嗎？ {same(a, b)}')
    a, b = run([('x', 0), H0, CX]), run([H0, CX, ('z', 0)])
    print(f'  Φ⁻ = 先 X(q0)：{ket(a)}   Φ⁺ 之後補 Z(q0)：{ket(b)}   一樣嗎？ {same(a, b)}')

    # 六、改造區：先預測，再執行。閘寫成 ('h', 0)、('x', 1)、('z', 0)、('cx', 0, 1)，由左往右排
    MY_CIRCUITS = [[('x', 1), ('h', 0), ('cx', 0, 1), ('z', 0)]]
    print('六、改造區')
    for g in MY_CIRCUITS:
        s = run(g)
        print('  ' + ' → '.join(gname(x) for x in g))
        print(f'    狀態 {ket(s)}   單看 q0 {size(s, 0):.3f}  單看 q1 {size(s, 1):.3f}')
