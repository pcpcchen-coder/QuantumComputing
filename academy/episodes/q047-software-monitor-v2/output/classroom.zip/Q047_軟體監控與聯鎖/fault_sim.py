"""父子科技學院 量子電腦學程 Q047：故障注入模擬器（照 peripherals.html#monitor 的示意模型）

執行：python fault_sim.py water     冷卻水中斷
      python fault_sim.py leak      真空洩漏
      python fault_sim.py block     流阻堵塞
不需要安裝任何套件。時間是「動畫秒數」（場景標示時間加速），不是真實冷凍機的時間。
改造：改 ALARM_WATER、STOP_WATER 這些門檻，看看警報和聯鎖提早或延後多少。
"""
import math
import sys

ALARM_WATER = 27.0    # 冷卻水入水溫度超過這個值：警報（°C）
STOP_WATER = 32.0     # 到這個值：聯鎖停壓縮機（°C）
ALARM_OVC = 1e-3      # 外真空（OVC）壓力超過這個值：警報（mbar）
ALARM_FLOW = 0.2      # ³He 流量低於這個值：警報（mmol/s）


def step(fault, t):
    water, ovc, flow, cond, comp_on = 18.0, 1e-5, 0.5, 500.0, True
    status, action = 'OK', '—'
    if fault == 'water':
        water = 18 + min(30, t * 2.2)
        comp_on = water < STOP_WATER
        status = '警報' if water > ALARM_WATER else '警告'
        action = '冷卻水溫上升' if comp_on else '聯鎖停止壓縮機；準備回收混合氣'
    elif fault == 'leak':
        ovc = 1e-5 * math.exp(min(t, 20) * 0.6)
        status = '警報' if ovc > ALARM_OVC else '警告'
        action = '停止循環、檢漏' if ovc > ALARM_OVC else 'OVC 壓力上升'
    elif fault == 'block':
        flow = 0.5 * math.exp(-t / 3)
        cond = 500 + min(600, t * 60)
        status = '警報' if flow < ALARM_FLOW else '警告'
        action = '多為雜質凍結；回收混合氣、清理冷阱' if flow < ALARM_FLOW else '流量下降'
    return water, ovc, flow, cond, comp_on, status, action


fault = sys.argv[1] if len(sys.argv) > 1 else 'water'
print(f'故障情境：{fault}')
print(' 秒  水溫°C   OVC(mbar)  流量  凝結壓力  壓縮機  狀態  動作')
for t in range(0, 13):
    w, o, f, c, on, s, a = step(fault, t)
    print(f'{t:3d}  {w:5.1f}  {o:9.1e}  {f:4.2f}  {c:6.0f}    {"運轉" if on else "停止"}   {s}  {a}')
