"""父子科技學院 量子電腦學程 Q127：迷你模擬器（純 Python，不需要安裝任何套件，也沒有亂數）

執行：  python tiny_sim.py
沒辦法裝 Qiskit 時用這個：它把狀態向量（2ⁿ 個振幅）一步一步算出來，印出每一步的振幅和最後的理想機率。
會的閘：h、x、z、s、t（單位元閘），cx、cz（雙位元閘）。位元字串最右邊是 q0（和 Qiskit、動畫相同）。
改最下面 MY_STEPS 和 MY_PREDICT，就能驗證自己的線路。
"""
import cmath
import math

R = 1 / math.sqrt(2)
ONE = {'h': ((R, R), (R, -R)), 'x': ((0, 1), (1, 0)), 'z': ((1, 0), (0, -1)),
       's': ((1, 0), (0, 1j)), 't': ((1, 0), (0, cmath.exp(1j * math.pi / 4)))}


def run(n, steps):
    """steps：[('h', 0), ('t', 0), ('cz', 1, 0), ...]；回傳每一步之後的狀態向量"""
    amp = [0j] * 2 ** n
    amp[0] = 1
    history = []
    for gate, *qs in steps:
        new = amp[:]
        if gate in ONE:
            (a, b), (c, d) = ONE[gate]
            q = qs[0]
            for i in range(2 ** n):
                if not i >> q & 1:
                    j = i | 1 << q
                    new[i] = a * amp[i] + b * amp[j]
                    new[j] = c * amp[i] + d * amp[j]
        elif gate == 'cx':
            c, t = qs
            for i in range(2 ** n):
                if i >> c & 1:
                    new[i] = amp[i ^ 1 << t]
        elif gate == 'cz':
            c, t = qs
            for i in range(2 ** n):
                if i >> c & 1 and i >> t & 1:
                    new[i] = -amp[i]
        amp = new
        history.append(((gate, *qs), amp))
    return history


def fmt(z):
    """振幅寫成 0.71、−0.50+0.50i 這種樣子（同動畫的讀數）"""
    re, im = round(z.real, 2) + 0.0, round(z.imag, 2) + 0.0
    if im == 0:
        return f'{re:.2f}'.replace('-', '−')
    if re == 0:
        return f'{im:.2f}i'.replace('-', '−')
    return f'{re:.2f}{im:+.2f}i'.replace('-', '−')


def report(name, n, steps, predict):
    print(f'【{name}】')
    for (op, amp) in run(n, steps):
        terms = [f'{fmt(a)}|{k:0{n}b}⟩' for k, a in enumerate(amp) if abs(a) > 1e-9]
        print(f'  {" ".join(map(str, op)):<8} → ' + ' + '.join(terms))
    prob = {f'{k:0{n}b}': abs(a) ** 2 for k, a in enumerate(amp) if abs(a) ** 2 > 1e-9}
    keys = sorted(set(prob) | set(predict))
    print('  理想機率：' + '、'.join(f'{k} {prob.get(k, 0):.1%}' for k in keys))
    worst = max(abs(predict.get(k, 0) - prob.get(k, 0)) for k in keys)
    print('  判定：' + ('預測正確' if worst <= 0.01 else f'預測不對（最多差 {worst:.1%}）'))


A = [('h', 0), ('t', 0), ('t', 0), ('t', 0), ('t', 0), ('h', 0)]
B = [('h', 0), ('h', 1), ('cz', 1, 0), ('h', 0)]
MY_STEPS = [('h', 0), ('s', 0), ('s', 0), ('h', 0)]      # 改這裡：自己的線路（例：兩個 S 是不是等於 Z？）
MY_PREDICT = {'1': 1.0}                                  # 先寫預測，再執行！

if __name__ == '__main__':
    report('範例甲：H、四個 T、H', 1, A, {'1': 1.0})
    report('範例乙：H H、CZ、H', 2, B, {'00': 0.5, '11': 0.5})
    report('故意出錯甲：只放三個 T', 1, A[:3] + A[4:], {'1': 1.0})
    report('故意出錯乙：忘了最後的 H', 2, B[:3], {'00': 0.5, '11': 0.5})
    report('我的專題', 1, MY_STEPS, MY_PREDICT)
