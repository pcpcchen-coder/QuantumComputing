"""父子科技學院 量子電腦學程 Q127：專題模板——設計自己的線路（專題模板 notebook 的程式版）

安裝（只要一次）：  pip install qiskit qiskit-aer
執行：              python my_circuit.py
專題四步：一、寫目標　二、畫線路　三、寫預測（先寫再跑，寫好就不改）　四、用模擬器驗證
每個專題印出一份驗證報告：線路圖、預測、理想機率（Statevector）、抽樣 1000 次（AerSimulator），最後判定預測對不對。
位元字串的最右邊是 q0。固定亂數種子，所以每次執行結果相同；拿掉 seed_simulator 就每次不同。
"""
# %% 匯入
from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector
from qiskit_aer import AerSimulator

SHOTS = 1000
SEED = 127
TOLERANCE = 0.01   # 預測和理想機率最多差 1 個百分點，就算「預測正確」


# %% 範例甲：四個 T（八分之一圈）＝ 一個 Z（相位翻轉）
def example_a(n_t=4):
    """H、n_t 個 T、H。目標：四個 T 等於一個 Z，所以這條線路等於 H-Z-H，一定得到 1。"""
    qc = QuantumCircuit(1, 1)
    qc.h(0)
    for _ in range(n_t):
        qc.t(0)
    qc.h(0)
    qc.measure(0, 0)
    return qc


# %% 範例乙：不用 CNOT，用 CZ 做出 Bell 態
def example_b(last_h=True):
    """兩顆都 H、CZ、q0 再一個 H。目標：H-CZ-H 等於 CNOT（簡報第 22 頁），所以得到 Bell 態。"""
    qc = QuantumCircuit(2, 2)
    qc.h([0, 1])
    qc.cz(1, 0)
    if last_h:
        qc.h(0)
    qc.measure([0, 1], [0, 1])
    return qc


# %% 我的專題：改這一格（目標、線路、預測都換成自己的）
MY_GOAL = '三顆位元都做 H，八種結果機率一樣'


def my_circuit():
    qc = QuantumCircuit(3, 3)
    qc.h([0, 1, 2])
    qc.measure([0, 1, 2], [0, 1, 2])
    return qc


MY_PREDICT = {format(k, '03b'): 1 / 8 for k in range(8)}   # 先寫預測，再執行！

PROJECTS = [
    ('範例甲：四個 T ＝ 一個 Z', '四個八分之一圈相位閘等於一個相位翻轉閘', example_a, {'1': 1.0}),
    ('範例乙：用 CZ 做 Bell 態', '不用 CNOT 也能做出 Bell 態', example_b, {'00': 0.5, '11': 0.5}),
    ('故意出錯甲：只放三個 T', '（同範例甲，預測照抄）', lambda: example_a(3), {'1': 1.0}),
    ('故意出錯乙：忘了最後的 H', '（同範例乙，預測照抄）', lambda: example_b(False), {'00': 0.5, '11': 0.5}),
    ('我的專題', MY_GOAL, my_circuit, MY_PREDICT),
]


# %% 驗證報告
def ideal(qc):
    """理想機率（Statevector，不抽樣）"""
    sv = Statevector(qc.remove_final_measurements(inplace=False))
    return {k: v for k, v in sv.probabilities_dict().items() if v > 1e-9}


def sample(qc):
    """模擬器抽樣 SHOTS 次，回傳每個結果的比例"""
    counts = AerSimulator(seed_simulator=SEED).run(qc, shots=SHOTS).result().get_counts()
    return {k: v / SHOTS for k, v in counts.items()}


def report(name, goal, make, predict):
    qc = make()
    p, s = ideal(qc), sample(qc)
    keys = sorted(set(p) | set(s) | set(predict))
    print(f'【{name}】目標：{goal}')
    print(qc.draw(output='text', idle_wires=False))
    print('    結果    預測     理想   抽樣 1000 次')
    for k in keys:
        print(f'    {k:>5} {predict.get(k, 0):7.1%} {p.get(k, 0):8.1%} {s.get(k, 0):9.1%}')
    worst = max(abs(predict.get(k, 0) - p.get(k, 0)) for k in keys)
    print('    判定：' + ('預測正確' if worst <= TOLERANCE else f'預測不對（最多差 {worst:.1%}）'))
    print()


for project in PROJECTS:
    report(*project)
