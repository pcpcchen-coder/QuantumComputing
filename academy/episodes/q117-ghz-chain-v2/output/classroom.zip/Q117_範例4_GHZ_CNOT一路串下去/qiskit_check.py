"""父子科技學院 量子電腦學程 Q117：用本機 Qiskit 重現 3 顆、4 顆 GHZ 態（選用，不需要帳號）

安裝（只要一次）：  pip install qiskit
執行：              python qiskit_check.py
"""
from qiskit import QuantumCircuit
from qiskit.primitives import StatevectorSampler
from qiskit.quantum_info import Statevector


def ghz(n, skip=None):
    """H(q0)，再 CNOT 一路串下去；skip = 故意少接的那一條（例如 1 代表少接 CNOT(q1→q2)）"""
    qc = QuantumCircuit(n)
    qc.h(0)                          # 哈達瑪閘：q0 進入疊加
    for i in range(n - 1):
        if i != skip:
            qc.cx(i, i + 1)          # 受控反閘：q(i) 控制 q(i+1)，一路串下去
    return qc


for n, skip in ((3, None), (4, None), (3, 1), (4, 1)):
    qc = ghz(n, skip)
    probs = Statevector.from_instruction(qc).probabilities_dict()
    m = qc.copy()
    m.measure_all()
    counts = StatevectorSampler(seed=2026).run([m], shots=1000).result()[0].data.meas.get_counts()
    tag = f'{n} 顆' + ('' if skip is None else f'，少接 CNOT(q{skip}→q{skip + 1})')
    print(tag, '理論機率', {str(k): round(float(v), 3) for k, v in sorted(probs.items())}, '量測 1000 次', dict(sorted(counts.items())))
print(ghz(4).draw())
