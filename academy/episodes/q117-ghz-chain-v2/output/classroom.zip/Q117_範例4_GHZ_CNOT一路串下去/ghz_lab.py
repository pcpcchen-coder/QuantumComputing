"""父子科技學院 量子電腦學程 Q117：範例 4 GHZ——CNOT 一路串下去（純 Python，不需安裝任何套件）

執行：  python ghz_lab.py
它用一個很小的多位元模擬器（只認得 H、X、CNOT），印出：
  一、三顆逐步看振幅：H（q0）→ CNOT（q0 → q1）→ CNOT（q1 → q2），每一步「單看每一顆」的 Bloch 向量大小
  二、四顆逐步看：多一個 CNOT（q2 → q3）
  三、三顆、四顆各量測 1000 次（固定的亂數種子；換種子次數會不一樣）
  四、故意少接一條 CNOT：結果變成什麼、哪幾顆沒綁上
  五、另一種接法：全部由 q0 控制，結果一樣嗎？
  六、玩具雜訊模型：每個 CNOT 之後，目標位元有 2% 機率被翻錯；位元越多，全 0、全 1 以外的比例越高
  七、改造區：自己排一條線路，先預測，再執行
位元字串寫成 |… q2 q1 q0⟩：最右邊那位是 q0（和 Qiskit、basic-circuits.html 一樣）。
"""
import random
from math import sqrt

R2 = 1 / sqrt(2)


def run(n, gates):
    """n 顆位元從 |0…0⟩ 出發，依序做 gates，回傳 2ⁿ 個振幅（第 i 根柱子 = i 的二進位字串）
    閘的寫法：('h', q)、('x', q)、('cx', 控制, 目標)"""
    s = [0.0] * (1 << n)
    s[0] = 1.0
    for g in gates:
        if g[0] == 'cx':
            c, t = 1 << g[1], 1 << g[2]
            s = [s[i ^ t] if i & c else s[i] for i in range(len(s))]
            continue
        name, m = g[0], 1 << g[1]
        new = s[:]
        for i in range(len(s)):
            if i & m:
                continue
            a, b = s[i], s[i | m]                       # 這一顆是 0、是 1 的兩個振幅
            if name == 'h':
                new[i], new[i | m] = (a + b) * R2, (a - b) * R2
            elif name == 'x':
                new[i], new[i | m] = b, a
            else:
                raise ValueError('只認得 h、x、cx：' + name)
        s = new
    return s


def bits(i, n):
    return format(i, f'0{n}b')


def size(s, q):
    """單看第 q 顆的 Bloch 向量大小（振幅都是實數，所以只有 x、z 兩個分量）"""
    m = 1 << q
    x = sum(2 * s[i] * s[i | m] for i in range(len(s)) if not i & m)
    z = sum((-1 if i & m else 1) * a * a for i, a in enumerate(s))
    return sqrt(x * x + z * z)


def bars(s, n):
    """只列出不是 0 的柱子"""
    return '  '.join(f'|{bits(i, n)}⟩ {a:+.3f}' for i, a in enumerate(s) if abs(a) > 1e-9)


def sizes(s, n):
    return '  '.join(f'q{q} {size(s, q):.1f}' for q in range(n))


def gname(g):
    return f'CNOT(q{g[1]}→q{g[2]})' if g[0] == 'cx' else f'{g[0].upper()}(q{g[1]})'


def ghz(n):
    """範例 4 的接法：H(q0)，再 CNOT 一路串下去 q0→q1、q1→q2、…"""
    return [('h', 0)] + [('cx', i, i + 1) for i in range(n - 1)]


def outcomes(s, n):
    return [bits(i, n) for i, a in enumerate(s) if a * a > 1e-9]


def shots(s, n, k, rng):
    """全部一起量 k 次：每次以機率 振幅² 得到其中一個位元字串；只列出有出現的"""
    counts = {}
    for _ in range(k):
        r, i = rng.random(), 0
        while i < len(s) - 1 and r >= s[i] ** 2:
            r -= s[i] ** 2
            i += 1
        counts[bits(i, n)] = counts.get(bits(i, n), 0) + 1
    return dict(sorted(counts.items()))


def show_steps(n):
    gates = ghz(n)
    print(f'  {"起點":<14}{bars(run(n, []), n):<34}單看 {sizes(run(n, []), n)}')
    for k in range(1, len(gates) + 1):
        s = run(n, gates[:k])
        print(f'  {gname(gates[k - 1]):<14}{bars(s, n):<34}單看 {sizes(s, n)}')


def noisy_outside(n, p):
    """玩具雜訊模型（精確計算，不抽樣）：每個 CNOT 之後，目標位元以機率 p 被多翻一次。
    把所有「哪幾個 CNOT 出錯」的情形都算一遍，加總量到全 0、全 1 以外的機率。"""
    gates, total = ghz(n), 0.0
    cxs = [i for i, g in enumerate(gates) if g[0] == 'cx']
    for pattern in range(1 << len(cxs)):
        seq, w = [], 1.0
        for j, g in enumerate(gates):
            seq.append(g)
            if g[0] == 'cx':
                err = (pattern >> cxs.index(j)) & 1
                w *= p if err else 1 - p
                if err:
                    seq.append(('x', g[2]))
        s = run(n, seq)
        total += w * sum(a * a for i, a in enumerate(s) if i not in (0, (1 << n) - 1))
    return total


if __name__ == '__main__':
    rng = random.Random(1117)
    print('一、三顆逐步看：每一步多綁一顆（只列出不是 0 的柱子；最後是「單看每一顆」的 Bloch 向量大小）')
    show_steps(3)
    print('二、四顆逐步看：多一個 CNOT(q2→q3)')
    show_steps(4)
    print('三、各量測 1000 次（random 種子 1117）')
    for n in (3, 4):
        print(f'  {n} 顆：', '  '.join(f'{k} → {v} 次' for k, v in shots(run(n, ghz(n)), n, 1000, rng).items()))
    print('四、故意少接一條 CNOT')
    for n in (3, 4):
        full = ghz(n)
        for j in range(1, len(full)):
            g = full[:j] + full[j + 1:]
            s = run(n, g)
            loose = [f'q{q}' for q in range(n) if size(s, q) > 0.5]
            print(f'  {n} 顆少接 {gname(full[j]):<12}只量到 {"、".join(outcomes(s, n)):<12}沒綁上（向量還是 1）：{"、".join(loose)}')
    print('五、另一種接法：全部由 q0 控制')
    for n in (3, 4):
        star = [('h', 0)] + [('cx', 0, i) for i in range(1, n)]
        print(f'  {n} 顆 ' + ' → '.join(gname(x) for x in star) + f'   和串下去一樣嗎？ {run(n, star) == run(n, ghz(n))}')
    print('六、玩具雜訊模型：每個 CNOT 之後，目標位元有 2% 機率被翻錯（精確計算）')
    for n in range(2, 9):
        print(f'  {n} 顆（{n - 1} 個 CNOT）：量到全 0、全 1 以外的機率 {noisy_outside(n, 0.02) * 100:.1f}%')

    # 七、改造區：先預測，再執行。閘寫成 ('h', 0)、('x', 1)、('cx', 0, 1)，由左往右排
    N, MY_CIRCUIT = 4, [('h', 0), ('cx', 0, 1), ('cx', 2, 3)]
    print('七、改造區')
    s = run(N, MY_CIRCUIT)
    print('  ' + ' → '.join(gname(x) for x in MY_CIRCUIT))
    print(f'    只量到 {"、".join(outcomes(s, N))}   單看 {sizes(s, N)}')
