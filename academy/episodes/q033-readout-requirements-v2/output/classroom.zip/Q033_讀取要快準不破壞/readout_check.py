"""父子科技學院 量子電腦學程 Q033：讀取需求表小工具。

不用安裝任何套件，只要 Python 3。執行：  python readout_check.py
- 一、快：讀取途中掉回 |0⟩ 的機會 ≈ 1 − e^(−t/T1)（只算 T1 衰減）。
- 二、準：讀取保真度 F = 1 − [P(1|0) + P(0|1)] / 2（學程簡報 JJ_Microwave_Readout_Talk p31）。
- 三、檢查一張讀取需求表有沒有過關（目標數字是本課設計的練習數字）。
- 四、動畫 atoms.html#imaging 的判別保真度（animations/js/atoms/12_imaging.js 第 48、55–58 行：
  亮平均 3 × 曝光毫秒數、暗平均 0.12 × 曝光毫秒數 + 0.6，Poisson 分佈，選最好的閾值）。
"""
import math


def decay_chance(t_read_us, t1_us):
    """讀取 t_read 微秒、能量弛豫時間 T1 微秒：讀取途中掉回 |0⟩ 的機會。"""
    return 1 - math.exp(-t_read_us / t1_us)


def fidelity(p1_given0, p0_given1):
    """兩種誤判機率（0–1）→ 讀取保真度。"""
    return 1 - (p1_given0 + p0_given1) / 2


def passes(t_read_us, t1_us, f, repeat_same):
    """本課的練習目標：讀取時間 ÷ T1 ≤ 1/200、保真度 ≥ 99 %、連量兩次相同 ≥ 99 %。"""
    return {'快': t_read_us / t1_us <= 1 / 200, '準': f >= 0.99, '不破壞': repeat_same >= 0.99}


def _pois(lam, k):
    return math.exp(-lam + k * math.log(lam) - math.lgamma(k + 1))


def _cdf(lam, k):
    return sum(_pois(lam, i) for i in range(k))


def imaging_fidelity(expo_ms):
    bright, dark = 3.0 * expo_ms, 0.12 * expo_ms + 0.6
    best, bf = 1, 0.0
    th = 1
    while th < bright + 3:
        f = 1 - ((1 - _cdf(dark, th)) + _cdf(bright, th)) / 2
        if f > bf:
            bf, best = f, th
        th += 1
    return best, bf


print('一、快：讀取途中掉回 |0⟩ 的機會（只算 T1 衰減）')
DECAY = {}
for t_read, t1 in ((0.1, 100), (0.5, 100), (0.5, 1000), (5, 100), (50, 100)):
    p = decay_chance(t_read, t1)
    DECAY[(t_read, t1)] = p
    print(f'  讀取 {t_read:5.1f} μs、T1 = {t1:5d} μs：讀取時間 ÷ T1 = {t_read / t1:.4f} → 約 {100 * p:.2f} %')

print()
print('二、準：讀取保真度')
FID = {}
for a, b in ((0.004, 0.012), (0.005, 0.015), (0.01, 0.03)):
    f = fidelity(a, b)
    FID[(a, b)] = f
    print(f'  P(1|0) = {100 * a:.1f} %、P(0|1) = {100 * b:.1f} % → F = {100 * f:.1f} %，平均誤判 {100 * (a + b) / 2:.1f} %')

print()
print('三、範例需求表檢查（讀取 0.5 μs、T1 = 100 μs、F = 99.2 %、連量兩次相同 99.5 %）')
CHECK = passes(0.5, 100, FID[(0.004, 0.012)], 0.995)
for k, v in CHECK.items():
    print(f'  {k}：' + ('過關' if v else '沒過'))

print()
print('四、動畫 atoms.html#imaging 的判別保真度')
IMG = {}
for e in (1, 2, 5, 10, 20):
    th, f = imaging_fidelity(e)
    IMG[e] = (th, f)
    print(f'  曝光 {e:2d} ms：亮平均 {3 * e:.0f} 光子、暗平均 {0.12 * e + 0.6:.1f} → 閾值 {th}，判別保真度 {100 * f:.2f} %')
