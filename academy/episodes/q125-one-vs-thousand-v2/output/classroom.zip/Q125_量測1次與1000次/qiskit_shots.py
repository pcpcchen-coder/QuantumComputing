"""父子科技學院 量子電腦學程 Q125：用本機 Qiskit 量 Bell 態 1、10、100、1000、10000 次（選用，不需要帳號）

安裝（只要一次）：  pip install qiskit
執行：              python qiskit_shots.py
"""
from math import sqrt
from qiskit import QuantumCircuit
from qiskit.primitives import StatevectorSampler

qc = QuantumCircuit(2, 2)
qc.h(0)                 # 哈達瑪閘
qc.cx(0, 1)             # 受控反閘：做出貝爾態
qc.measure([0, 1], [0, 1])

for shots in (1, 10, 100, 1000, 10000):
    counts = StatevectorSampler(seed=1125).run([qc], shots=shots).result()[0].data.c.get_counts()
    f = counts.get('00', 0) / shots
    print(f'shots = {shots:>5}  {dict(sorted(counts.items()))}  00 的比例 {f:.1%}  誤差範圍 ±{sqrt(0.25 / shots):.1%}')
