"""父子科技學院 量子電腦學程 Q125：量測 1 次與 1000 次（純 Python，不需要安裝任何套件）

執行：  python shots_lab.py
八個範例的理論機率抄自 basic-circuits.html（預設選項、最後一步）。程式只做「照理論機率抽樣」，印出：
  一、八個範例各量 1 次與 1000 次，和理論機率差多少、誤差範圍 σ = √(P(1−P)/N) 多大
  二、隱形傳態一路累加：1、10、100、1000、10000 次時的比例
  三、要幾次才能估到 ±2%：先用公式算，再把同樣的次數重複做 200 輪，數有幾輪落在 ±2% 以內（改造區可以改）
  四、連續三次 0 之後，下一次是 1 的比例（會不會「該輪到 1」？）
用固定的亂數種子，所以每次執行結果相同；改成 random.Random() 就每次不同（頁面的按鈕也是每次不同）。
"""
import random
from math import sqrt, ceil

# 範例名稱、量的位元、理論機率（頁面預設選項、最後一步）
EXAMPLES = [
    ('1 疊加', 'q0', {'0': 0.5, '1': 0.5}),
    ('2 干涉', 'q0', {'1': 1.0}),
    ('3 Bell', 'q1 q0', {'00': 0.5, '11': 0.5}),
    ('4 GHZ', 'q2 q1 q0', {'000': 0.5, '111': 0.5}),
    ('5 隱形傳態', 'q2', {'0': 0.75, '1': 0.25}),
    ('6 Deutsch', 'q0', {'1': 1.0}),
    ('7 BV', 'q2 q1 q0', {'101': 1.0}),
    ('8 Grover', 'q1 q0', {'11': 1.0}),
]


# 改造區：想估到多準（MY_ERR）、機率大約多少（MY_P）、重複幾輪（MY_ROUNDS）
MY_P, MY_ERR, MY_ROUNDS = 0.5, 0.02, 200


def shot(theory, rng):
    """照理論機率抽一個結果（和頁面的 sample() 同一種做法）"""
    r = rng.random()
    for key, p in theory.items():
        r -= p
        if r < 0:
            return key
    return key


def sigma(p, n):
    """n 次量測時，比例的誤差範圍（一個標準差）"""
    return sqrt(p * (1 - p) / n)


def need(p, err):
    """要估到 ±err（一個標準差），至少要量幾次"""
    return ceil(p * (1 - p) / err ** 2 - 1e-9)


if __name__ == '__main__':
    rng = random.Random(1125)   # 固定種子：教材的輸出才對得起來
    print('一、八個範例：量 1 次與 1000 次（看第一個結果的比例）')
    for name, bits, th in EXAMPLES:
        key = next(iter(th))
        one = shot(th, rng)
        n = sum(shot(th, rng) == key for _ in range(1000))
        f, p = n / 1000, th[key]
        print(f'  {name}｜理論 {key}：{p:.0%}｜量 1 次 → {one}｜量 1000 次 → {key} {n} 次（{f:.1%}）'
              f'｜差 {abs(f - p) * 100:.1f} 點｜誤差範圍 ±{sigma(p, 1000) * 100:.1f} 點')
    print('二、隱形傳態一路累加（q2 = 0 的比例，理論 75%）')
    zeros = total = 0
    for target in (1, 10, 100, 1000, 10000):
        while total < target:
            zeros += shot({'0': 0.75, '1': 0.25}, rng) == '0'
            total += 1
        print(f'  共 {total:>5} 次  0 → {zeros:>4} 次（{zeros / total:.1%}）  誤差範圍 ±{sigma(0.75, total) * 100:.1f} 點')
    print('三、要幾次才能估到 ±2%？')
    for p in (0.5, 0.75):
        print(f'  理論 {p:.0%}：N = {p:g} × {1 - p:g} ÷ 0.02² = {need(p, 0.02)} 次')
    N = need(MY_P, MY_ERR)
    inside = 0
    for _ in range(MY_ROUNDS):
        k = sum(rng.random() < MY_P for _ in range(N))
        inside += abs(k / N - MY_P) <= MY_ERR
    print(f'  改造區：理論 {MY_P:.0%} 量 {N} 次，重複 {MY_ROUNDS} 輪：落在 ±{MY_ERR:.0%} 以內的有 {inside} 輪（{inside / MY_ROUNDS:.0%}）')
    print('四、連續三次 0 之後，下一次是 1 的比例（一半一半）')
    seq = [rng.random() < 0.5 for _ in range(100000)]   # True 代表 1
    after = [seq[i] for i in range(3, len(seq)) if not (seq[i - 1] or seq[i - 2] or seq[i - 3])]
    print(f'  連續三次 0 出現 {len(after)} 回，下一次是 1 的有 {sum(after)} 回（{sum(after) / len(after):.1%}）')
