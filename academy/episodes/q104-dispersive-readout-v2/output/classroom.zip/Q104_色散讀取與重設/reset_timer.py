"""父子科技學院 量子電腦學程 Q104：讀完之後怎麼回到 |0⟩——被動等待 vs 主動重設（純 Python，不需要安裝任何套件）

執行：  python reset_timer.py
時間數值取自學程動畫 transmon-3d.html 第 5 章第 7 步的時間軸看板（示意值）。
"""
import math

T1 = 100.0          # 能量衰減時間 T₁（微秒，μs）
GATE = 0.5          # 跑一次線路的閘（μs）
READ = 1.0          # 讀取一次（μs）
DECIDE = 0.35       # FPGA 判斷（μs）
PI = 0.12           # π 脈衝：把 1 翻回 0（μs）
WAIT_T1 = 5         # 改造區：被動等待要等幾倍 T₁？（試試 1、3、5、7）


def passive(n):
    """被動等待：什麼都不做，等 n 倍 T₁。回傳 (每個 shot 的時間 μs, 還留在 |1⟩ 的比例)"""
    return GATE + READ + n * T1, math.exp(-n)


def active():
    """主動重設：讀取 → 判斷 → 是 1 就送 π 脈衝 → 再讀一次確認"""
    return GATE + READ + DECIDE + PI + READ


if __name__ == '__main__':
    print(f'T₁ = {T1:g} μs')
    print('被動等待：等幾倍 T₁ → 每個 shot 多久、每秒幾個、還留在 |1⟩ 的比例')
    for n in (1, 3, 5, 7):
        t, left = passive(n)
        print(f'  等 {n} T₁：{t:8.1f} μs，每秒 {1e6 / t:9,.0f} 個，殘留 {left * 100:6.2f} %')
    tp, _ = passive(WAIT_T1)
    ta = active()
    print(f'主動重設：{ta:.2f} μs，每秒 {1e6 / ta:,.0f} 個')
    print(f'主動重設比等 {WAIT_T1} T₁ 快 {tp / ta:.0f} 倍')
