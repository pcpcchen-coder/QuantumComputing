"""父子科技學院 量子電腦學程 Q062：Shor（秀爾）演算法 的小模擬器

執行：python shor_lab.py                 → 第一關 N = 15、a = 7，第二關 N = 21、a = 2，各跑一次完整五步
      python shor_lab.py 15 7            → 指定 N 和 a
      python shor_lab.py 15 7 8          → 計數暫存器改成 8 顆位元（Q = 256）
      python shor_lab.py 表 21           → 列出 N = 21 每個 a 的週期與能不能分解
      python shor_lab.py 魔王            → 魔王戰：電腦出題，你先在推導單上算，再按 Enter 對答案
五步：① 疊加＋模指數 ② 量第二組暫存器（梳子）③ 量子傅立葉轉換（尖峰）④ 量測得到 y ⑤ 連分數＋最大公因數。
只用 Python 標準函式庫；振幅用完整的離散傅立葉轉換計算，量測依 |振幅|² 隨機取樣。
"""
import cmath
import random
import sys
from fractions import Fraction
from math import gcd


def period(a, N):
    """古典驗算：最小的 r 使 a^r mod N = 1。"""
    r, v = 1, a % N
    while v != 1:
        v = v * a % N
        r += 1
    return r


def comb(N, a, Q, f0):
    """量完第二組暫存器（量到 f0）之後，第一組剩下的 x。"""
    return [x for x in range(Q) if pow(a, x, N) == f0]


def qft_probs(xs, Q):
    """對均勻的梳子做量子傅立葉轉換，回傳每個 y 的機率。"""
    out = []
    for y in range(Q):
        s = sum(cmath.exp(2j * cmath.pi * x * y / Q) for x in xs)
        out.append(abs(s) ** 2 / (len(xs) * Q))
    return out


def convergents(y, Q):
    """y/Q 的漸近分數（連分數一項一項截斷）。"""
    out, n, d = [], y, Q
    p1, p0, q1, q0 = 1, 0, 0, 1
    while d:
        t = n // d
        p1, p0 = t * p1 + p0, p1
        q1, q0 = t * q1 + q0, q1
        out.append(Fraction(p1, q1))
        n, d = d, n - t * d
    return out


def post(N, a, y, Q):
    """古典收尾：連分數找 r（只用分母 ≤ N 的漸近分數的分母），再算最大公因數。回傳 (結果文字, 因數或 None)。"""
    lines = [f'量到 y = {y}，y / {Q} = {y / Q:.4f}']
    if y == 0:
        return lines + ['y = 0：沒有週期資訊 → 重跑'], None
    cv = [c for c in convergents(y, Q) if c.denominator <= N]
    lines.append('漸近分數：' + '、'.join(f'{c.numerator}/{c.denominator}' for c in cv))
    r = next((c.denominator for c in reversed(cv) if pow(a, c.denominator, N) == 1), None)
    if r is None:
        return lines + ['沒有分母滿足 a^r mod N = 1（k 和 r 可能有公因數，或 Q 太小）→ 重跑'], None
    lines.append(f'週期 r = {r}（驗算 {a}^{r} mod {N} = 1）')
    if r % 2:
        return lines + [f'r = {r} 是奇數 → 魔王反擊，換一個 a'], None
    h = pow(a, r // 2, N)
    p, q = gcd(h - 1, N), gcd(h + 1, N)
    lines.append(f'{a}^{r // 2} mod {N} = {h} → gcd({h} − 1, {N}) = {p}，gcd({h} + 1, {N}) = {q}')
    if 1 < p < N:
        return lines + [f'{N} = {p} × {N // p} ✓'], (p, N // p)
    return lines + ['只拆出 1 和 N → 魔王反擊，換一個 a'], None


def run(N, a, bits=6, rng=random, show=True):
    Q = 2 ** bits
    if gcd(a, N) != 1:
        print(f'gcd({a}, {N}) = {gcd(a, N)}：運氣好，直接找到因數！')
        return
    seq = [pow(a, x, N) for x in range(min(Q, 12))]
    x0 = rng.randrange(Q)
    f0 = pow(a, x0, N)
    xs = comb(N, a, Q, f0)
    pr = qft_probs(xs, Q)
    y = rng.choices(range(Q), weights=pr)[0]
    peaks = [k for k in range(Q) if pr[k] > 0.03]
    if show:
        print(f'=== N = {N}，a = {a}，計數位元 {bits} 顆（Q = {Q}） ===')
        print(f'① 疊加＋模指數：f(x) = {a}^x mod {N} = ' + ', '.join(map(str, seq)) + ' …')
        print(f'② 量第二組暫存器得到 {f0} → 梳子 x = ' + ', '.join(map(str, xs[:6])) + f' …（共 {len(xs)} 根，間隔 {period(a, N)}）')
        print('③ 量子傅立葉轉換 → 尖峰 y = ' + '、'.join(f'{k}（{pr[k]:.1%}）' for k in peaks))
        lines, res = post(N, a, y, Q)
        print('④ ' + lines[0])
        for ln in lines[1:]:
            print('⑤ ' + ln)
    return y


def table(N):
    print(f'N = {N}：每個和 {N} 互質的 a')
    for a in range(2, N):
        if gcd(a, N) != 1:
            continue
        r = period(a, N)
        if r % 2:
            note = 'r 是奇數 → 換 a'
        else:
            h = pow(a, r // 2, N)
            p, q = gcd(h - 1, N), gcd(h + 1, N)
            note = f'{a}^{r // 2} mod {N} = {h}，gcd = {p}、{q}' + ('' if 1 < p < N else ' → 只拆出 1 和 N，換 a')
        print(f'  a = {a:2d}：r = {r}，{note}')


def boss():
    N = random.choice([15, 21])
    a = random.choice([x for x in range(2, N) if gcd(x, N) == 1])
    print(f'魔王出題：分解 N = {N}，用 a = {a}。先在推導單上寫出 {a}^x mod {N} 的週期，再按 Enter。')
    input()
    print(f'週期 r = {period(a, N)}。接著量子電腦跑一次：')
    run(N, a)


if __name__ == '__main__':
    args = sys.argv[1:]
    if args[:1] == ['表']:
        table(int(args[1]) if len(args) > 1 else 15)
    elif args[:1] in (['魔王'], ['boss']):
        boss()
    elif len(args) >= 2:
        run(int(args[0]), int(args[1]), int(args[2]) if len(args) > 2 else 6)
    else:
        rng = random.Random(17)   # 固定種子：第一關量到 48、第二關量到 11
        run(15, 7, rng=rng)
        print()
        run(21, 2, rng=rng)
