"""父子科技學院 量子電腦學程 Q115：用本機 Qiskit 重現 H‑Z‑H = X（選用，不需要帳號）

安裝（只要一次）：  pip install qiskit
執行：              python qiskit_check.py
"""
from qiskit import QuantumCircuit
from qiskit.primitives import StatevectorSampler
from qiskit.quantum_info import Operator, Statevector


def report(name, qc):
    sv = Statevector.from_instruction(qc)
    m = qc.copy()
    m.measure_all()
    counts = StatevectorSampler(seed=2026).run([m], shots=1000).result()[0].data.meas.get_counts()
    print(name, '振幅', [round(float(a.real), 3) + 0.0 for a in sv.data],
          '機率', {str(k): round(float(v), 3) for k, v in sv.probabilities_dict().items() if v > 1e-9},
          '量測 1000 次', dict(sorted(counts.items())))


hzh = QuantumCircuit(1)
hzh.h(0)                     # 第一個哈達瑪閘：做出疊加
hzh.z(0)                     # 相位翻轉閘：只給 |1⟩ 加負號
hzh.h(0)                     # 第二個哈達瑪閘：干涉
hh = QuantumCircuit(1)
hh.h(0)
hh.h(0)                      # 對照組：拿掉 Z
report('H‑Z‑H', hzh)
report('H‑H  ', hh)

x = QuantumCircuit(1)
x.x(0)
print('H‑Z‑H 和 X 是同一個運算嗎？', Operator(hzh).equiv(Operator(x)))
print('H‑H 和「什麼都不做」是同一個運算嗎？', Operator(hh).equiv(Operator(QuantumCircuit(1))))
print(hzh.draw())
