"""父子科技學院 量子電腦學程 Q115：範例 2 干涉——H‑Z‑H = X（純 Python，不需安裝任何套件）

執行：  python paths.py
它用一個很小的一顆位元模擬器（只認得 H、X、Z 三種閘），印出：
  一、逐步看振幅：H → Z → H，每一步 |0⟩、|1⟩ 的振幅與機率
  二、對照組：拿掉 Z，只剩 H → H
  三、路徑加總表：最後一個 H 把「經由 0」和「經由 1」兩條路徑的振幅加起來
  四、錯誤示範：如果把機率相加，會得到什麼
  五、各量測 1000 次（固定的亂數種子；這兩條線路的機率是 100%／0%，所以次數不會變）
  六、改造區：自己排一條線路，先預測，再執行
"""
import random
from math import sqrt

R2 = 1 / sqrt(2)


def run(gates):
    """一顆位元從 |0⟩ 出發，由左往右依序做 gates（'h'、'x'、'z'），回傳 [|0⟩ 的振幅, |1⟩ 的振幅]"""
    a, b = 1.0, 0.0
    for g in gates:
        if g == 'h':
            a, b = (a + b) * R2, (a - b) * R2
        elif g == 'x':
            a, b = b, a
        elif g == 'z':
            b = -b
        else:
            raise ValueError('只認得 h、x、z：' + g)
    return [a, b]


def num(v):
    return '0' if abs(v) < 1e-9 else ('+' if v > 0 else '−') + f'{abs(v):.3f}'


def name(gates):
    return ' → '.join(g.upper() for g in gates) or '起點'


def show(gates):
    s = run(gates)
    print(f'  {name(gates):<12}' + '  '.join(f'|{i}⟩ {num(v)}（{v * v * 100:.0f}%）' for i, v in enumerate(s)))


def steps(gates):
    for k in range(len(gates) + 1):
        show(gates[:k])


# H 的係數：從 |j⟩ 到 |i⟩ 乘上 HC[i][j]（只有 |1⟩ → |1⟩ 是負的）
HC = [[R2, R2], [R2, -R2]]


def path_table(gates):
    """最後一個閘必須是 H：把它之前的振幅，沿兩條路徑乘上 H 的係數，再加總"""
    assert gates[-1] == 'h'
    before = run(gates[:-1])
    print(f'  {name(gates)}（最後一個 H 之前：|0⟩ {num(before[0])}、|1⟩ {num(before[1])}）')
    for i in (0, 1):
        via = [before[j] * HC[i][j] for j in (0, 1)]
        total = via[0] + via[1]
        print(f'    到 |{i}⟩  經由 0：{num(via[0])}  經由 1：{num(via[1])}  總和 {num(total)}  機率 {total * total * 100:.0f}%')


def shots(gates, n, rng):
    """量測 n 次：每次以機率 振幅² 得到 0 或 1，回傳 [0 的次數, 1 的次數]"""
    p0 = run(gates)[0] ** 2
    c0 = sum(rng.random() < p0 for _ in range(n))
    return [c0, n - c0]


HZH, HH = ['h', 'z', 'h'], ['h', 'h']

if __name__ == '__main__':
    rng = random.Random(1115)
    print('一、逐步看振幅（有 Z）')
    steps(HZH)
    print('二、對照組（拿掉 Z）')
    steps(HH)
    print('三、路徑加總表（同一個結果的兩條路徑先相加，再平方）')
    path_table(HZH)
    path_table(HH)
    print('四、錯誤示範：把機率相加')
    p = (R2 * R2) ** 2
    print(f'  每條路徑的機率 {p:.2f}，兩條相加 {p + p:.2f}：到 |0⟩、到 |1⟩ 都是 50%，算不出抵消')
    print('五、各量測 1000 次')
    for g in (HZH, HH):
        c = shots(g, 1000, rng)
        print(f'  {name(g):<12}0 → {c[0]} 次  1 → {c[1]} 次')

    # 六、改造區：先預測，再執行。閘寫成 'h'、'x'、'z'，由左往右排
    MY_CIRCUITS = [['h', 'x', 'h']]
    print('六、改造區')
    for g in MY_CIRCUITS:
        show(g)
        if g and g[-1] == 'h':
            path_table(g)
