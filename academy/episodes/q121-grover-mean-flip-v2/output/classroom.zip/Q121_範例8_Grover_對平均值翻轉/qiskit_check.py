"""父子科技學院 量子電腦學程 Q121：用本機 Qiskit 重現兩位元 Grover 一輪（選用，不需要帳號）

安裝（只要一次）：  pip install qiskit
執行：              python qiskit_check.py
線路和 basic-circuits.html#grover 頁面下方的程式碼同一種接法：標記 = X、CZ、X；擴散 = H、X、CZ、X、H。
"""
from qiskit import QuantumCircuit
from qiskit.primitives import StatevectorSampler
from qiskit.quantum_info import Statevector


def grover(t, measure=True):
    """t 寫成 q1 q0；只做一輪（兩顆位元的最佳輪數）"""
    qc = QuantumCircuit(2)
    qc.h([0, 1])
    zeros = [q for q in (0, 1) if t[1 - q] == '0']
    if zeros:
        qc.x(zeros)                          # 標記：先把答案變成 11
    qc.cz(0, 1)
    if zeros:
        qc.x(zeros)                          # 再還原
    qc.h([0, 1])                             # 擴散：H、X、CZ、X、H
    qc.x([0, 1])
    qc.cz(0, 1)
    qc.x([0, 1])
    qc.h([0, 1])
    if measure:
        qc.measure_all()
    return qc


sampler = StatevectorSampler(seed=2026)
for t in ('00', '01', '10', '11'):
    amp = ' '.join(f'{round(a, 9) + 0.0:+.2f}' for a in Statevector(grover(t, measure=False)).data.real)   # 順序 00 01 10 11
    counts = sampler.run([grover(t)], shots=1000).result()[0].data.meas.get_counts()
    print(f'答案 {t}：振幅 {amp}　量 1000 次 {counts}')
print(grover('01').draw())
