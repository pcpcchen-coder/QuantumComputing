"""父子科技學院 量子電腦學程 Q121：範例 8 Grover——對平均值翻轉（純 Python，不需安裝任何套件）

執行：  python grover_mean.py
它印出：
  一、兩顆位元、答案 01：每一步的四個振幅、平均值、每根柱子離平均多遠
  二、沒有標記就擴散：每根柱子都站在平均線上，翻完一動也不動
  三、四種答案都試一次：標記後的平均、一輪後的柱子
  四、用真正的閘（哈達瑪閘、翻轉閘、受控相位翻轉閘）接出擴散：多一個整體負號，機率不變
  五、選項變多（4 顆位元、16 個選項）：一輪拉不滿，第二輪答案離平均更遠
  六、改造區：換成自己的答案，先預測，再執行
位元字串寫成 q1 q0（最右邊是 q0），和 basic-circuits.html#grover、Qiskit 一樣。
"""
from math import sqrt

ANSWER = '01'      # 影片和教材用的答案


def show(v):
    return ' '.join(f'{a + 0.0:+.2f}'.replace('-', '−') for a in v)


def sg(a):
    return f'{a + 0.0:+.2f}'.replace('-', '−')


def mean(v):
    return sum(v) / len(v)


def uniform(n):
    """每顆位元都做哈達瑪閘之後：每個振幅都是 1/√N"""
    N = 2 ** n
    return [1 / sqrt(N)] * N


def mark(v, t):
    """標記：只把答案的振幅變號，其他不動"""
    w = v[:]
    w[int(t, 2)] = -w[int(t, 2)]
    return w


def diffuse(v):
    """擴散：每個振幅對平均值翻轉，新振幅 = 2 × 平均 − 原振幅"""
    m = mean(v)
    return [2 * m - a for a in v]


# ---- 第四段用：一顆一顆閘作用在兩顆位元上（索引 = q1 q0） ----
def h(v, q):
    m, w = 1 << q, v[:]
    for i in range(4):
        if not i & m:
            a, b = v[i], v[i | m]
            w[i], w[i | m] = (a + b) / sqrt(2), (a - b) / sqrt(2)
    return w


def x(v, q):
    m, w = 1 << q, v[:]
    for i in range(4):
        if not i & m:
            w[i], w[i | m] = v[i | m], v[i]
    return w


def cz(v):
    w = v[:]
    w[3] = -w[3]
    return w


def gate_round(t):
    """真正的閘：H、H；標記 = 對 0 的那一位做 X → CZ → X；擴散 = H、X、CZ、X、H"""
    v = [1.0, 0.0, 0.0, 0.0]
    v = h(h(v, 0), 1)
    zeros = [q for q in (0, 1) if t[1 - q] == '0']
    for q in zeros:
        v = x(v, q)
    v = cz(v)
    for q in zeros:
        v = x(v, q)
    for g in (h, x):
        v = g(g(v, 0), 1)
    v = cz(v)
    for g in (x, h):
        v = g(g(v, 0), 1)
    return v


def clean(v):
    return [0.0 if abs(a) < 1e-12 else a for a in v]


if __name__ == '__main__':
    print(f'一、兩顆位元、答案 {ANSWER}（振幅順序 00 01 10 11）')
    i = int(ANSWER, 2)
    v1 = uniform(2)
    v2 = mark(v1, ANSWER)
    v3 = diffuse(v2)
    for name, v in (('①哈達瑪閘', v1), ('②標記    ', v2), ('③擴散    ', v3)):
        print(f'  {name}：{show(v)}   平均 {mean(v):+.2f}   答案的機率 {v[i] ** 2:.1%}')
    m = mean(v2)
    print(f'  標記後離平均：其他三根 {sg(v2[(i + 1) % 4] - m)}（在平均上面），答案 {sg(v2[i] - m)}（在平均下面）')
    print(f'  擴散後離平均：其他三根 {sg(v3[(i + 1) % 4] - m)}，答案 {sg(v3[i] - m)}：離多遠，就翻到另一邊多遠')

    print('二、沒有標記就擴散')
    print(f'  擴散前：{show(v1)}   平均 {mean(v1):+.2f}')
    print(f'  擴散後：{show(diffuse(v1))}   每根都站在平均線上，一動也不動')

    print('三、四種答案都試一次')
    for t in ('00', '01', '10', '11'):
        a = mark(uniform(2), t)
        b = clean(diffuse(a))
        print(f'  答案 {t}：標記後平均 {mean(a):+.2f}；一輪後 {show(b)}   答案的機率 {b[int(t, 2)] ** 2:.0%}')

    print('四、用真正的閘接出擴散（H、X、CZ、X、H）')
    for t in ('00', '01', '10', '11'):
        g = clean(gate_round(t))
        ideal = clean(diffuse(mark(uniform(2), t)))
        same = all(abs(p * p - q * q) < 1e-12 for p, q in zip(g, ideal))
        print(f'  答案 {t}：閘電路 {show(g)}   理想 {show(ideal)}   '
              f'整體差一個負號：{"是" if all(abs(p + q) < 1e-12 for p, q in zip(g, ideal)) else "否"}；機率{"相同" if same else "不同"}')

    print('五、選項變多：4 顆位元、16 個選項、答案是編號 6')
    v = uniform(4)
    print(f'  一開始：每根 {v[0]:+.2f}，答案的機率 {v[6] ** 2:.2%}')
    for r in (1, 2):
        a = mark(v, format(6, '04b'))
        m = mean(a)
        v = diffuse(a)
        print(f'  第 {r} 輪：標記後平均 {m:+.3f}，答案在平均下面 {m - a[6]:.2f}；'
              f'擴散後答案 {v[6]:+.3f}（機率 {v[6] ** 2:.1%}），其他每根 {v[0]:+.3f}')

    # 六、改造區：換成自己的答案（兩位，只寫 0 和 1），先預測，再執行
    MY_ANSWER = '11'
    a = mark(uniform(2), MY_ANSWER)
    b = clean(diffuse(a))
    print('六、改造區')
    print(f'  我的答案 {MY_ANSWER}：標記後 {show(a)}，平均 {mean(a):+.2f}')
    print(f'  一輪後 {show(b)}；量到 {MY_ANSWER} 的機率 {b[int(MY_ANSWER, 2)] ** 2:.0%}')
