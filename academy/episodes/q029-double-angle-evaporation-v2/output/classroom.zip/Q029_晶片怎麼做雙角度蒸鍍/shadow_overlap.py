"""父子科技學院 量子電腦學程 Q029：影子蒸鍍的重合寬度（和動畫 index.html#fab 同一套幾何）。

不用安裝任何套件，只要 Python 3。執行：  python shadow_overlap.py
- 紙橋（或光阻橋）離桌面（基板）的高度 h，照射角度 θ 從垂直方向量起。
- 每一邊的影子平移 s = h × tanθ（動畫讀數「影子平移 s = h·tanθ」）。
- 第一次從左邊照，亮區往右平移 s；第二次從右邊照，亮區往左平移 s。
  橋正下方兩次都照到的寬度 = 2s − 橋寬；小於 0 代表兩邊碰不到（沒有接面）。
- 這是理想的平行光；手電筒是點光源，實際影子會放大、邊緣模糊。
- 參考：學程簡報 JJ_Microwave_Readout_Talk p21–22；animations/js/scenes/07_fab.js。
"""
import math

H = 5.0       # 紙離桌面的高度（公分）
W = 2.0       # 紙橋寬度（公分）


def shift(h, deg):
    return h * math.tan(math.radians(deg))


def overlap(h, w, deg):
    """橋正下方兩次都照到的寬度（公分）；負數表示中間還差多少才碰得到。"""
    return 2 * shift(h, deg) - w


print(f'一、紙高 {H:.0f} 公分、橋寬 {W:.0f} 公分：照射角度與橋下重合寬度（理想平行光）')
print('角度   每邊平移     橋下重合')
TABLE = {}
for deg in range(5, 45, 5):
    o = overlap(H, W, deg)
    TABLE[deg] = o
    note = f'{o:5.2f} 公分' if o > 0 else f'碰不到（還差 {-o:.2f} 公分）'
    print(f' {deg:2d}°   {shift(H, deg):5.2f} 公分   {note}')

MIN_DEG = math.degrees(math.atan(W / (2 * H)))
print()
print(f'二、最小角度：tanθ = 橋寬 ÷（2 × 高度）→ θ = {MIN_DEG:.1f}°，比這個角度小，橋下就沒有重合')

print()
print('三、換一個高度（角度 20°）：紙架得越高，平移越多')
HEIGHTS = {}
for h in (3.0, 5.0, 8.0):
    HEIGHTS[h] = overlap(h, W, 20)
    print(f'  高 {h:.0f} 公分：每邊平移 {shift(h, 20):.2f} 公分，橋下重合 {overlap(h, W, 20):5.2f} 公分')

print()
print('四、動畫 index.html#fab 的幾何（場景單位）')
HB, HT, XB, S = 0.8, 0.25, 0.25, 0.55        # 07_fab.js 第 16、40 行
HEFF = HB + HT * 0.5                          # 第 77 行
THETA = math.degrees(math.atan(S / HEFF))
JJW = 2 * S - 2 * XB
print(f'  有效高度 h = {HEFF:.3f}、平移 s = {S}、蒸鍍角 θ = {THETA:.1f}°（讀數寫 31°）')
print(f'  橋寬 {2 * XB}，橋下重合寬 2s − 橋寬 = {JJW:.2f}（和金色重疊區的寬度一樣）')

print()
print('五、製程控制（簡報 p22）：f01 正比於 1/√R_n')
RATIO = 1.02 ** -0.5
print(f'  R_n 大 2 %：頻率變成 {RATIO:.4f} 倍，少 {(1 - RATIO) * 100:.2f} %；以 5 GHz 為例約少 {(1 - RATIO) * 5000:.1f} MHz')
