"""父子科技學院 量子電腦學程 Q045：熱負載預算計算器（照 peripherals.html#wiring 的估算模型）

執行：python heat_budget.py          （不需要安裝任何套件）
改造：改下面的 QUBITS，或把 PASSIVE 乘上 0.27 試試「細同軸」
"""
import math

QUBITS = [50, 100, 1000]

STAGES = ['50 K', '4 K', 'Still', 'Cold plate', 'MXC']
PASSIVE = [45e-3, 1e-3, 3e-6, 0.4e-6, 0.015e-6]   # 每條不鏽鋼同軸帶下的熱（瓦）
ATT = [0, 2e-6, 0, 2e-8, 2e-9]                    # 每條輸入線的衰減器發熱（瓦）
HEMT = 5e-3                                       # 每條讀取輸出線的低溫放大器（4 K，瓦）
COOL = [30, 1.5, 40e-3, 200e-6, 19e-6]            # 每一層的冷卻能力（瓦）


def fmt(w):
    return f'{w:.2f} W' if w >= 1 else f'{w * 1e3:.1f} mW' if w >= 1e-3 else f'{w * 1e6:.1f} uW'


for n in QUBITS:
    g = math.ceil(n / 6)                 # 讀取輸入、讀取輸出、泵浦：每 6 顆一條
    xy, z, rin, rout, pump = n, n, g, g, g
    coax = xy + z + rin + rout + pump
    print(f'\n{n} 顆量子位元 -> 同軸線 {coax} 條')
    for i, s in enumerate(STAGES):
        load = coax * PASSIVE[i] + (xy + rin + pump) * ATT[i] + (rout * HEMT if i == 1 else 0)
        pct = load / COOL[i] * 100
        flag = '  <-- 超過！' if pct > 100 else ''
        print(f'  {s:<10} {fmt(load):>10} / {fmt(COOL[i]):>9}  {pct:6.0f}%{flag}')
