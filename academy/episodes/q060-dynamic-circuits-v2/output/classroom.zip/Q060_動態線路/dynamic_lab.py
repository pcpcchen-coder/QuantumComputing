"""父子科技學院 量子電腦學程 Q060：動態線路 的小模擬器

執行：python dynamic_lab.py            → 主動重置：零態、一態、加態、倒下 60° 各跑 1000 次，比較「有回饋」和「沒有回饋」
      python dynamic_lab.py 冒險        → 冒險任務：電腦偷偷選起點，你寫條件，最後 1000 次全是 0 就過關
      python dynamic_lab.py 症狀        → 三位元重複碼：故意翻錯一顆，看兩顆輔助位元的症狀
      python dynamic_lab.py qiskit      → 有裝 qiskit 與 qiskit-aer 時，用真正的中途量測＋if_test 跑主動重置與症狀量測
主動重置的線路：準備狀態 → 中途量測 → 量到 1 就做 X（翻轉閘）→ 再量一次。
只用 Python 標準函式庫（qiskit 模式除外）。
"""
import math
import random
import sys

STARTS = {   # 名稱: 從北極倒下的角度 θ（度）；量到 1 的機率 = sin²(θ/2)
    '|0⟩ 零態': 0,
    '|1⟩ 一態': 180,
    '|+⟩ 加態': 90,
    '倒下 60°': 60,
}


def p1(theta):
    return math.sin(math.radians(theta) / 2) ** 2


def active_reset(theta, shots=1000, feedback=True, rng=random):
    """回傳 (第一次量到 0 的次數, 第一次量到 1 的次數, 第二次量到 0 的次數, 第二次量到 1 的次數)。"""
    a0 = a1 = b0 = b1 = 0
    for _ in range(shots):
        first = 1 if rng.random() < p1(theta) else 0   # 中途量測：狀態塌縮成 0 或 1
        a1 += first
        a0 += 1 - first
        bit = first
        if feedback and first == 1:                    # 前饋：量到 1 就做 X
            bit = 0
        b1 += bit
        b0 += 1 - bit
    return a0, a1, b0, b1


def table(seed=60):
    rng = random.Random(seed)
    print('起點｜回饋｜第一次量測（0 / 1）｜第二次量測（0 / 1）')
    for name, th in STARTS.items():
        for fb in (True, False):
            a0, a1, b0, b1 = active_reset(th, 1000, fb, rng)
            print(f'{name}｜{"有" if fb else "沒有"}｜{a0} / {a1}｜{b0} / {b1}')
    print('\n有回饋時第二次量測全部是 0；沒有回饋時，第二次量測和第一次一樣（量過就塌縮了）。')


def adventure():
    name = random.choice(list(STARTS))
    th = STARTS[name]
    print('關主（電腦）偷偷選了一個起點。你只能中途量一次，再決定量到 0、量到 1 各要做什麼。')
    r0 = input('量到 0 時要做什麼？（輸入 X 或 不做）：').strip().upper()
    r1 = input('量到 1 時要做什麼？（輸入 X 或 不做）：').strip().upper()
    ok = 0
    for _ in range(1000):
        bit = 1 if random.random() < p1(th) else 0
        if (bit == 0 and r0 == 'X') or (bit == 1 and r1 == 'X'):
            bit ^= 1
        ok += bit == 0
    print(f'最後量 1000 次：0 有 {ok} 次、1 有 {1000 - ok} 次。', '過關！' if ok == 1000 else '還沒過關，再想想條件。')
    print('關主選的起點是', name)


def syndrome(data):
    """三顆資料位元 data = [q1, q2, q3]；輔助一比 1、2 號，輔助二比 2、3 號（相同得 0，不同得 1）。"""
    return data[0] ^ data[1], data[1] ^ data[2]


FIX = {(0, 0): None, (1, 0): 0, (1, 1): 1, (0, 1): 2}   # 症狀 → 要修第幾顆（0 起算）


def syndrome_demo():
    print('資料位元一開始都是 000（重複碼的邏輯 0）。')
    for wrong in (None, 0, 1, 2):
        data = [0, 0, 0]
        if wrong is not None:
            data[wrong] ^= 1
        s = syndrome(data)
        fix = FIX[s]
        after = data[:]
        if fix is not None:
            after[fix] ^= 1
        tag = '沒有翻錯' if wrong is None else f'故意翻錯 {wrong + 1} 號'
        print(f'{tag}：資料 {data} → 症狀（輔助一, 輔助二）= {s} → ' + ('不用修' if fix is None else f'修 {fix + 1} 號') + f' → {after}')
    print('改造：同時翻錯兩顆（例如 1、2 號），症狀會指到哪裡？修完變成什麼？')


def with_qiskit():
    from qiskit import QuantumCircuit
    from qiskit_aer import AerSimulator
    sim = AerSimulator()
    qc = QuantumCircuit(1, 2)
    qc.h(0)
    qc.measure(0, 0)
    with qc.if_test((qc.clbits[0], 1)):
        qc.x(0)
    qc.measure(0, 1)
    print(qc.draw())
    print('主動重置（位元字串左邊是第二次量測）：', sim.run(qc, shots=1000).result().get_counts())
    q = QuantumCircuit(5, 5)   # 0、1、2 是資料位元，3、4 是輔助位元
    q.x(1)                      # 故意把 2 號翻錯
    q.cx(0, 3); q.cx(1, 3); q.cx(1, 4); q.cx(2, 4)
    q.measure(3, 3); q.measure(4, 4)
    with q.if_test((q.clbits[3], 1)):
        with q.if_test((q.clbits[4], 1)):
            q.x(1)
    q.measure([0, 1, 2], [0, 1, 2])
    print('症狀量測＋修正（左兩位是輔助二、輔助一，右三位是資料 3、2、1 號）：', sim.run(q, shots=200).result().get_counts())


if __name__ == '__main__':
    arg = sys.argv[1] if len(sys.argv) > 1 else ''
    {'冒險': adventure, 'adventure': adventure, '症狀': syndrome_demo, 'syndrome': syndrome_demo,
     'qiskit': with_qiskit}.get(arg, table)()
