"""父子科技學院 量子電腦學程 Q109：表面碼——穩定子與匹配解碼（純 Python，不需要安裝任何套件）

執行：  python surface_d3.py
d = 3 的表面碼（和 transmon-3d.html 第 10 章同一個排法）：資料位元 D1～D9 排成 3×3，
  D1 D2 D3
  D4 D5 D6
  D7 D8 D9
這裡只看 X 錯誤（位元翻轉），所以只用 4 個 Z 穩定子（青色格子）；Z 錯誤由另外 4 個 X 穩定子用同樣的方法處理。
"""
from itertools import combinations

# 改造區 1：自己注入錯誤（寫資料位元的編號），看哪些穩定子亮、解碼器怎麼修
MY_ERRORS = [1, 4]

# 4 個 Z 穩定子：名字 → 它量奇偶的資料位元
Z_STABS = {
    '左上（內部）': (1, 2, 4, 5),
    '右下（內部）': (5, 6, 8, 9),
    '左邊界半圓': (4, 7),
    '右邊界半圓': (3, 6),
}
TOP_ROW = (1, 2, 3)   # 邏輯 Z 是第一列的 Z：殘餘的 X 錯誤在這一列有奇數個 → 邏輯位元被翻轉


def syndrome(errs):
    """哪些穩定子亮（量到 −1）：它管的資料位元裡，錯誤的個數是奇數"""
    return tuple(name for name, qs in Z_STABS.items() if sum(q in errs for q in qs) % 2 == 1)


# 解碼器：對每一種亮法，找「最少顆」就能造成同樣亮法的修正（最小權重）。
# d = 3 只有 2⁹ = 512 種，可以全部試一遍；大碼距時改用最小權重完美匹配，答案相同、但快得多。
TABLE = {}
for k in range(10):
    for fix in combinations(range(1, 10), k):
        TABLE.setdefault(syndrome(set(fix)), set(fix))


def decode(errs):
    errs = set(errs)
    fix = TABLE[syndrome(errs)]
    left = errs ^ fix                     # 錯誤和修正抵消後剩下的
    logical = sum(q in left for q in TOP_ROW) % 2 == 1
    return fix, left, logical


def show(errs):
    fix, left, logical = decode(errs)
    lit = syndrome(set(errs)) or ('沒有',)
    print(f'  錯誤 {fmt(errs)} → 亮：{"、".join(lit)} → 修正 {fmt(fix)} → '
          + ('邏輯錯誤 ✗（剩下 ' + fmt(left) + '）' if logical else '成功 ✓'))


def fmt(qs):
    return '、'.join(f'D{q}' for q in sorted(qs)) or '無'


if __name__ == '__main__':
    print('一、單一錯誤（9 種）')
    for q in range(1, 10):
        show([q])
    print('二、兩個錯誤（36 種）中，騙過解碼器的：')
    bad = [pair for pair in combinations(range(1, 10), 2) if decode(pair)[2]]
    for pair in bad:
        show(pair)
    print(f'  共 {len(bad)} 種會造成邏輯錯誤，{36 - len(bad)} 種修得好')
    print('三、每顆資料位元以機率 p 翻轉時，邏輯錯誤率（512 種情況全部加總，不用亂數）')
    for p in (0.01, 0.05, 0.10, 0.20, 0.30):
        pl = sum(p ** k * (1 - p) ** (9 - k)
                 for k in range(10) for errs in combinations(range(1, 10), k) if decode(errs)[2])
        print(f'  p = {p * 100:4.0f}%  →  邏輯錯誤率 {pl * 100:6.2f}%  '
              + ('（比不編碼好）' if pl < p else '（比不編碼還糟）'))
    print('四、我的實驗：')
    show(MY_ERRORS)
