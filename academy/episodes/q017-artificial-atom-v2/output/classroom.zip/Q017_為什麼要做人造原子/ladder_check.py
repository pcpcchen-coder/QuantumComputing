"""父子科技學院 量子電腦學程 Q017：樓梯等不等高？——LC 電路和約瑟夫森接面電路的能階。

不用安裝任何套件，只要 Python 3。執行：  python ladder_check.py
和學程動畫 animations/index.html#potential（js/scenes/04_potential.js）用同樣的數字與算法：
充電能 E_C = 0.25 GHz、E_J / E_C = 50，電荷基底 n = -14 … 14。
"""
import math

EC = 0.25            # 充電能（GHz）
EJ = 50 * EC         # 約瑟夫森能（GHz）
N = 14


def jacobi_eigenvalues(a, sweeps=60):
    """對稱矩陣的 Jacobi 對角化（只用標準函式庫），回傳由小到大的特徵值。"""
    n = len(a)
    a = [row[:] for row in a]
    for _ in range(sweeps):
        off = sum(a[i][j] ** 2 for i in range(n) for j in range(n) if i != j)
        if off < 1e-22:
            break
        for p in range(n - 1):
            for q in range(p + 1, n):
                if abs(a[p][q]) < 1e-15:
                    continue
                theta = (a[q][q] - a[p][p]) / (2 * a[p][q])
                t = (1 if theta >= 0 else -1) / (abs(theta) + math.sqrt(theta * theta + 1))
                c = 1 / math.sqrt(t * t + 1)
                s = t * c
                for k in range(n):
                    akp, akq = a[k][p], a[k][q]
                    a[k][p], a[k][q] = c * akp - s * akq, s * akp + c * akq
                for k in range(n):
                    apk, aqk = a[p][k], a[q][k]
                    a[p][k], a[q][k] = c * apk - s * aqk, s * apk + c * aqk
    return sorted(a[i][i] for i in range(n))


# LC 電路（線性）：能階 E_n = ω(n + 1/2)，ω = √(8 E_J E_C)
w = math.sqrt(8 * EJ * EC)
LC = [w * (n + 0.5) for n in range(5)]
LC_GAPS = [LC[k + 1] - LC[k] for k in range(3)]
print('LC 電路（線性）    相鄰兩階的間距（GHz）：', [round(g, 3) for g in LC_GAPS])

# 約瑟夫森接面電路（transmon）：H = 4 E_C n² − (E_J / 2)(|n⟩⟨n+1| + h.c.)
dim = 2 * N + 1
H = [[0.0] * dim for _ in range(dim)]
for i in range(dim):
    n = i - N
    H[i][i] = 4 * EC * n * n
    if i + 1 < dim:
        H[i][i + 1] = H[i + 1][i] = -EJ / 2
E = jacobi_eigenvalues(H)
JJ_GAPS = [E[k + 1] - E[k] for k in range(3)]
ALPHA_MHZ = (JJ_GAPS[1] - JJ_GAPS[0]) * 1000
print('約瑟夫森接面（非線性）相鄰兩階的間距（GHz）：', [round(g, 3) for g in JJ_GAPS])
print(f'非諧性 = (1→2 間距) − (0→1 間距) = {ALPHA_MHZ:.0f} MHz；LC 電路是 {(LC_GAPS[1] - LC_GAPS[0]) * 1000:.0f} MHz')
print('結論：LC 電路每一階一樣高，微波會一路往上推；換成約瑟夫森接面，0→1 和 1→2 的頻率不同，微波就能只推 0 和 1。')
