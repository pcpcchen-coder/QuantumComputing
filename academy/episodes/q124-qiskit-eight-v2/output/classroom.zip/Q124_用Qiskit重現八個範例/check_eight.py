"""父子科技學院 量子電腦學程 Q124：八個範例的「答案卷」（純 Python，不需安裝任何套件）

執行：  python check_eight.py
沒有 Qiskit 也能先對答案：用最簡單的狀態向量模擬（只有實數振幅，沒有亂數、沒有雜訊），
照 basic-circuits.html 的八個線路一步一步算，印出被量測位元的理論機率。
位元字串的最右邊是 q0。
"""
from math import cos, pi, sin, sqrt


def run(n, gates):
    """從全零開始，依序做 gates，回傳 2ⁿ 個振幅"""
    v = [0.0] * 2 ** n
    v[0] = 1.0
    for g, *q in gates:
        for i in range(2 ** n):
            if g in ('h', 'x', 'ry'):
                m = 1 << q[0]
                if i & m:
                    continue
                a, b = v[i], v[i | m]
                if g == 'h':
                    v[i], v[i | m] = (a + b) / sqrt(2), (a - b) / sqrt(2)
                elif g == 'x':
                    v[i], v[i | m] = b, a
                else:   # ry(角度)
                    c, s = cos(q[1] / 2), sin(q[1] / 2)
                    v[i], v[i | m] = c * a - s * b, s * a + c * b
            elif g == 'z' and i >> q[0] & 1:
                v[i] = -v[i]
            elif g == 'cz' and i >> q[0] & 1 and i >> q[1] & 1:
                v[i] = -v[i]
            elif g == 'cx' and i >> q[0] & 1 and not i >> q[1] & 1:
                j = i | 1 << q[1]
                v[i], v[j] = v[j], v[i]
    return v


def probs(n, gates, measured):
    out = {}
    for i, a in enumerate(run(n, gates)):
        if a * a > 1e-12:
            k = ''.join(str(i >> q & 1) for q in sorted(measured, reverse=True))
            out[k] = out.get(k, 0) + a * a
    return '、'.join(f'{k}: {p:.0%}' for k, p in sorted(out.items()))


def H(*qs):
    return [('h', q) for q in qs]


def X(*qs):
    return [('x', q) for q in qs]


def bv(secret):
    return X(3) + H(0, 1, 2, 3) + [('cx', q, 3) for q in range(3) if secret[2 - q] == '1'] + H(0, 1, 2)


def teleport(angle):
    return [('ry', 0, angle)] + H(1) + [('cx', 1, 2), ('cx', 0, 1)] + H(0) + [('cx', 1, 2), ('cz', 0, 2)]


EIGHT = [
    ('1 疊加', 1, H(0), [0]),
    ('2 干涉', 1, H(0) + [('z', 0)] + H(0), [0]),
    ('3 Bell 態', 2, H(0) + [('cx', 0, 1)], [0, 1]),
    ('4 GHZ 態', 3, H(0) + [('cx', 0, 1), ('cx', 1, 2)], [0, 1, 2]),
    ('5 隱形傳態', 3, teleport(pi / 3), [2]),
    ('6 Deutsch', 2, X(1) + H(0, 1) + [('cx', 0, 1)] + H(0), [0]),
    ('7 BV', 4, bv('101'), [0, 1, 2]),
    ('8 Grover', 2, H(0, 1) + [('cz', 0, 1)] + H(0, 1) + X(0, 1) + [('cz', 0, 1)] + X(0, 1) + H(0, 1), [0, 1]),
]

if __name__ == '__main__':
    print('八個範例的理論機率（純 Python）')
    for name, n, gates, measured in EIGHT:
        print(f'  {name}：{probs(n, gates, measured)}')
    MY_SECRET = '011'
    MY_ANGLE = pi / 2
    print('改造區')
    print(f'  BV 密碼 {MY_SECRET}：{probs(4, bv(MY_SECRET), [0, 1, 2])}')
    print(f'  隱形傳態 角度 {MY_ANGLE:.4f}：{probs(3, teleport(MY_ANGLE), [2])}')
