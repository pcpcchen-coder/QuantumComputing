"""父子科技學院 量子電腦學程 Q124：用 Qiskit 重現八個範例（八範例 notebook 的程式版）

安裝（只要一次）：  pip install qiskit qiskit-aer
執行：              python eight_examples.py
每個範例的線路都照 animations/basic-circuits.html 頁面最下方「Qiskit 程式碼」區塊（預設選項）抄寫。
每個範例跑兩次：
  1. Statevector：不量測，直接算出理論機率，和頁面灰色底的理論機率比對（數字要一樣）
  2. shots：量 1000 次，數每種結果出現幾次（像頁面的「量測 1,000 次」，每次跑都會差一點）
位元字串的最右邊是 q0（和頁面、Qiskit 的讀法相同）。
用 VS Code 或 Jupyter 開啟時，每個「# %%」是一格，可以一格一格執行；八範例.ipynb 是同樣內容的筆記本版。
"""
# %% 匯入
from math import pi, sin

from qiskit import QuantumCircuit
from qiskit.primitives import StatevectorSampler
from qiskit.quantum_info import Statevector


# %% 範例 1　疊加：量子硬幣（起始態 = |0⟩）
def superposition():
    qc = QuantumCircuit(1, 1)
    qc.h(0)
    qc.measure(0, 0)
    return qc


# %% 範例 2　干涉：H-Z-H = X（中間的閘 = 有 Z）
def interference():
    qc = QuantumCircuit(1, 1)
    qc.h(0)
    qc.z(0)
    qc.h(0)
    qc.measure(0, 0)
    return qc


# %% 範例 3　Bell 態（Φ⁺）
def bell():
    qc = QuantumCircuit(2, 2)
    qc.h(0)
    qc.cx(0, 1)
    qc.measure([0, 1], [0, 1])
    return qc


# %% 範例 4　GHZ 態（3 顆）
def ghz():
    qc = QuantumCircuit(3, 3)
    qc.h(0)
    qc.cx(0, 1)
    qc.cx(1, 2)
    qc.measure([0, 1, 2], [0, 1, 2])
    return qc


# %% 範例 5　隱形傳態（ψ = √¾|0⟩ + ½|1⟩，只量 q2）
def teleport(angle=pi / 3):
    qc = QuantumCircuit(3, 1)
    qc.ry(angle, 0)          # 準備要傳的狀態 ψ（q0）
    qc.h(1)
    qc.cx(1, 2)              # 糾纏對（q1、q2）
    qc.cx(0, 1)
    qc.h(0)                  # Alice：Bell 量測的前半
    qc.cx(1, 2)
    qc.cz(0, 2)              # Bob：用受控閘代替「量完再修正」，結果相同
    qc.measure(2, 0)
    return qc


# %% 範例 6　Deutsch（黑盒裡的函數 f(x) = x）
def deutsch():
    qc = QuantumCircuit(2, 1)
    qc.x(1)
    qc.h([0, 1])
    qc.cx(0, 1)              # 黑盒 U_f（只查詢這一次）
    qc.h(0)
    qc.measure(0, 0)
    return qc


# %% 範例 7　Bernstein–Vazirani（密碼 s = 101，寫法 s2 s1 s0）
def bv(secret='101'):
    qc = QuantumCircuit(4, 3)
    qc.x(3)
    qc.h([0, 1, 2, 3])
    for q in range(3):       # 黑盒：計算 s·x（只查詢這一次）
        if secret[2 - q] == '1':
            qc.cx(q, 3)
    qc.h([0, 1, 2])
    qc.measure([0, 1, 2], [0, 1, 2])
    return qc


# %% 範例 8　Grover（2 顆、答案 11、最佳 1 輪）
def grover():
    qc = QuantumCircuit(2, 2)
    qc.h([0, 1])
    qc.cz(0, 1)              # 標記：答案 11 變號
    qc.h([0, 1])             # 擴散：H、X、CZ、X、H（會多一個整體負號，不影響機率）
    qc.x([0, 1])
    qc.cz(0, 1)
    qc.x([0, 1])
    qc.h([0, 1])
    qc.measure([0, 1], [0, 1])
    return qc


# %% 頁面灰色底的理論機率（basic-circuits.html，預設選項）
PAGE = {
    '1 疊加': {'0': 0.5, '1': 0.5},
    '2 干涉': {'1': 1.0},
    '3 Bell 態': {'00': 0.5, '11': 0.5},
    '4 GHZ 態': {'000': 0.5, '111': 0.5},
    '5 隱形傳態': {'0': 0.75, '1': 0.25},
    '6 Deutsch': {'1': 1.0},
    '7 BV': {'101': 1.0},
    '8 Grover': {'11': 1.0},
}
CIRCUITS = dict(zip(PAGE, (superposition, interference, bell, ghz, teleport, deutsch, bv, grover)))


def theory(qc):
    """Statevector：拿掉最後的量測，算出被量測那幾顆位元的理論機率"""
    measured = sorted(qc.find_bit(i.qubits[0]).index for i in qc.data if i.operation.name == 'measure')
    sv = Statevector(qc.remove_final_measurements(inplace=False))
    return {k: v for k, v in sorted(sv.probabilities_dict(qargs=measured).items()) if v > 1e-12}


def same(p, q):
    return all(abs(p.get(k, 0) - q.get(k, 0)) < 1e-9 for k in set(p) | set(q))


def fmt(d, pct=True):
    return '、'.join(f'{k}: {v:.0%}' if pct else f'{k}: {v}' for k, v in sorted(d.items()))


# %% 一、兩種跑法：Statevector 理論機率和頁面比；shots = 1000
sampler = StatevectorSampler(seed=2026)   # 固定種子，全班印出來的次數才會一樣；拿掉就每次不同
print('一、Statevector 理論機率 vs 頁面；shots = 1000')
matched = 0
for name, make in CIRCUITS.items():
    qc = make()
    p = theory(qc)
    ok = same(p, PAGE[name])
    matched += ok
    counts = sampler.run([qc], shots=1000).result()[0].data.c.get_counts()
    print(f'  {name}：理論 {fmt(p)}　和頁面{"一樣" if ok else "不一樣！"}　量 1000 次 {fmt(counts, False)}')
print(f'  八個範例裡，理論機率和頁面一樣的有 {matched} 個')

# %% 二、換成本機高效能模擬器 qiskit-aer
print('二、換成本機高效能模擬器 qiskit-aer（同樣量 1000 次）')
try:
    from qiskit import transpile
    from qiskit_aer import AerSimulator
    sim = AerSimulator(seed_simulator=2026)
    for name, make in CIRCUITS.items():
        counts = sim.run(transpile(make(), sim), shots=1000).result().get_counts()
        print(f'  {name}：{fmt(counts, False)}')
except ImportError:
    print('  沒有安裝 qiskit-aer，跳過（pip install qiskit-aer）')

# %% 三、改造區
print('三、改造區：換成自己的參數，先預測，再執行')
MY_SECRET = '011'  # BV 的密碼（s2 s1 s0），到頁面 #bv 點成同一組密碼再比對
MY_ANGLE = pi / 2  # 隱形傳態 ψ 的角度：量到 1 的機率應該是 sin²(角度 / 2)
p = theory(bv(MY_SECRET))
print(f'  BV 密碼 {MY_SECRET}：理論 {fmt(p)}　{"讀出的正是密碼" if p.get(MY_SECRET, 0) > 0.999 else "和密碼不一樣！"}')
p = theory(teleport(MY_ANGLE))
print(f'  隱形傳態 角度 {MY_ANGLE:.4f}：理論 {fmt(p)}　公式 sin² 算出 1 的機率 {sin(MY_ANGLE / 2) ** 2:.0%}')
