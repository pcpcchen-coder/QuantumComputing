"""父子科技學院 量子電腦學程 Q048：從零到上線——機房用電與 UPS 估算（只用 Python 標準函式庫）

執行：python power_budget.py
數字是學程簡報與文件整理的代表值（依機型與規模而異），只用來練習「先算清楚再配置」。
"""
LOADS = {                      # kW；學程《周邊系統連接與啟動指南》§1.2
    '脈衝管壓縮機': 10.7,
    '冷卻水系統': 10.0,
    '控制電子機櫃': 3.0,
    '氣體處理系統（泵）': 1.5,
    '電腦／監控／網路': 1.0,
}

total = sum(LOADS.values())
print(f'合計約 {total:.1f} kW（簡報取整為「約 25 kW」）')
for name, kw in LOADS.items():
    print(f'  {name:<12} {kw:>5.1f} kW  佔 {kw / total:5.1%}')

# 改造區：決定哪些負載接 UPS、要撐多久（小時），UPS 需要的能量 = 功率 × 時間
on_ups = ['控制電子機櫃', '電腦／監控／網路']    # 一般作法：控制系統接 UPS，壓縮機不接
hours = 2                                           # 簡報建議至少 1–2 小時
kw = sum(LOADS[n] for n in on_ups)
print(f'\n方案 A：UPS 供 {kw:.1f} kW × {hours} 小時 = {kw * hours:.1f} kWh')

# 方案 B（學程文件的推論）：冷卻鏈也接 UPS，只要撐到發電機接手（例如 15 分鐘）
cool = LOADS['脈衝管壓縮機'] + LOADS['冷卻水系統']
bridge_h = 15 / 60
print(f'方案 B：另加冷卻鏈 {cool:.1f} kW × {bridge_h:.2f} 小時 = {cool * bridge_h:.1f} kWh，'
      f'但 UPS 的瞬間輸出要從 {kw:.1f} kW 提高到 {kw + cool:.1f} kW 以上')
