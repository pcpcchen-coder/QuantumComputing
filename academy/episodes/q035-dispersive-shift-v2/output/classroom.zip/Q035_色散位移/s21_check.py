"""父子科技學院 量子電腦學程 Q035：S21 判讀小工具。

不用安裝任何套件，只要 Python 3。執行：  python s21_check.py
公式和動畫 animations/index.html#dispersive（js/scenes/09_dispersive.js 第 20–21、74、106–108 行）相同，
頻率都以諧振腔線寬 κ 為單位：
- 量子位元在 |0⟩：諧振腔頻率 ω_r − χ；在 |1⟩：ω_r + χ（學程簡報 JJ_Microwave_Readout_Talk p28）。
- 穿透係數 S21 = 1 / (1 + 2i(ω − ω_s)/κ)（筆記 notes/dispersive-readout.md §2.5）：
  振幅 |S21| = 1/√(1 + 4d²)、相位 = −arctan(2d)，d = (ω − ω_s)/κ。
- 一、探測在正中間：不同 2χ/κ 的相位差與 IQ 分離距離。
- 二、χ/κ = 0.5 時，探測頻率移動，兩種狀態的振幅、相位差與分離距離。
- 三、盲測練習：電腦偷偷選 |0⟩ 或 |1⟩，只印出 S21 的振幅與相位，你來猜（固定亂數種子，可重現）。
"""
import cmath
import math
import random


def s21(probe, shift):
    """探測頻率 probe、諧振腔頻率 shift（都以 κ 為單位）的穿透係數。"""
    return 1 / (1 + 2j * (probe - shift))


def compare(chi, probe=0.0):
    """回傳 (|0⟩ 振幅, |1⟩ 振幅, 相位差（度）, IQ 分離距離)。"""
    s0, s1 = s21(probe, -chi), s21(probe, chi)
    dphi = abs(math.degrees(cmath.phase(s1) - cmath.phase(s0)))
    return abs(s0), abs(s1), dphi, abs(s1 - s0)


print('一、探測在正中間（ω = ω_r）：2χ/κ 與相位差、分離距離')
MID = {}
for x in (0.1, 0.2, 0.25, 0.5, 1, 2, 3, 4):
    a0, a1, dphi, sep = compare(x / 2)
    MID[x] = (a0, dphi, sep)
    print(f'  2χ/κ = {x:<4}：兩種狀態振幅都是 {a0:.3f}、相位差 {dphi:5.1f}°、分離距離 {sep:.3f}')

print()
print('二、χ/κ = 0.5（2χ = κ），移動探測頻率')
PROBE = {}
for p in (-1.0, -0.5, -0.25, 0.0, 0.25, 0.5, 1.0):
    a0, a1, dphi, sep = compare(0.5, p)
    PROBE[p] = (a0, a1, dphi, sep)
    print(f'  探測 {p:+.2f} κ：|0⟩ 振幅 {a0:.3f}、|1⟩ 振幅 {a1:.3f}、相位差 {dphi:5.1f}°、分離距離 {sep:.3f}')

print()
print('三、盲測練習（χ/κ = 0.5；先自己猜，最後一行才是答案）')
rng = random.Random(39)
QUIZ = []
for k in range(1, 6):
    state = rng.randint(0, 1)
    probe = rng.choice((-0.5, 0.0, 0.5))
    s = s21(probe, 0.5 if state else -0.5)
    QUIZ.append((probe, state))
    print(f'  第 {k} 題：探測 {probe:+.1f} κ → 振幅 {abs(s):.3f}、相位 {math.degrees(cmath.phase(s)):+6.1f}°')
print('  答案：' + '、'.join(f'第 {k} 題 |{st}⟩' for k, (_, st) in enumerate(QUIZ, 1)))
