"""父子科技學院 量子電腦學程 Q063：快在哪？加速的等級 —— 把「比較快」換成數字

執行：python speedup_lab.py                  → 四個實驗全部跑一次
      python speedup_lab.py 格羅弗 1000000   → N 個抽屜：古典平均次數 vs 格羅弗輪數
      python speedup_lab.py 分解 2048        → n 位元：一般數域篩法 vs 秀爾 n³ 的量級（示意，常數略去）
      python speedup_lab.py 記憶體 50        → 精確模擬 n 顆量子位元要多少記憶體
      python speedup_lab.py 交叉 1e-9 1e-3   → 假設古典每查一次 1e-9 秒、量子每輪 1e-3 秒，N 多大格羅弗才划算
只用 Python 標準函式庫。所有「每一步幾秒」都是你自己填的假設，不是哪一台機器的真實數字。
"""
import math
import sys


def grover(N):
    """N 個抽屜、一個答案：古典平均要查 N/2 次；格羅弗約 (π/4)√N 輪。"""
    theta = math.asin(1 / math.sqrt(N))
    k = max(1, round(math.pi / (4 * theta) - 0.5))
    p = math.sin((2 * k + 1) * theta) ** 2
    return N / 2, k, p


def shor_vs_gnfs(bits):
    """n 位元整數：一般數域篩法 exp((64/9)^(1/3) (ln N)^(1/3) (ln ln N)^(2/3)) 與 n³ 的以 10 為底的量級。"""
    ln_n = bits * math.log(2)
    gnfs = (64 / 9) ** (1 / 3) * ln_n ** (1 / 3) * math.log(ln_n) ** (2 / 3) / math.log(10)
    return gnfs, 3 * math.log10(bits)


def memory(n):
    """精確存下 n 顆量子位元的狀態：2ⁿ 個複數，每個 16 bytes。"""
    return 2 ** n * 16


def human(b):
    for unit, s in (('EB', 1e18), ('PB', 1e15), ('TB', 1e12), ('GB', 1e9), ('MB', 1e6), ('KB', 1e3)):
        if b >= s:
            return f'{b / s:.3g} {unit}'
    return f'{b} bytes'


def crossover(t_classical, t_round):
    """古典平均 (N/2)·t_classical = 格羅弗 (π/4)√N·t_round 的 N。"""
    s = (math.pi / 4) * t_round * 2 / t_classical
    return s * s


def show_grover(N):
    c, k, p = grover(N)
    print(f'格羅弗：N = {N:,} 個抽屜 → 古典平均查 {c:,.0f} 次；格羅弗最佳 {k:,} 輪（成功機率 {p:.3f}）；差 {c / k:,.1f} 倍')


def show_shor(bits):
    g, s = shor_vs_gnfs(bits)
    print(f'分解 {bits} 位元：古典（一般數域篩法）約 10^{g:.1f}；秀爾約 n³ = 10^{s:.1f}（示意量級，常數都略去）')


def show_memory(n):
    print(f'精確模擬 {n} 顆：2^{n} × 16 bytes = {human(memory(n))}')


def show_cross(tc, tq):
    N = crossover(tc, tq)
    print(f'假設古典每查一次 {tc:g} 秒、格羅弗每輪 {tq:g} 秒：N 要超過約 {N:.3g}，格羅弗才比較快')
    for x in (1e6, 1e9, 1e12, 1e15):
        print(f'  N = {x:.0e}：古典 {x / 2 * tc:.3g} 秒，格羅弗 {math.pi / 4 * math.sqrt(x) * tq:.3g} 秒')


def show_loading(N):
    c, k, _ = grover(N)
    print(f'載入瓶頸：先把 {N:,} 筆資料一筆一筆載入（約 {N:,} 步），再跑 {k:,} 輪格羅弗 → 合計 {N + k:,} 步，'
          f'比古典直接找的平均 {c:,.0f} 次還多')


if __name__ == '__main__':
    a = sys.argv[1:]
    if a[:1] == ['格羅弗']:
        show_grover(int(float(a[1])) if len(a) > 1 else 10 ** 6)
    elif a[:1] == ['分解']:
        show_shor(int(a[1]) if len(a) > 1 else 2048)
    elif a[:1] == ['記憶體']:
        show_memory(int(a[1]) if len(a) > 1 else 50)
    elif a[:1] == ['交叉']:
        show_cross(float(a[1]) if len(a) > 1 else 1e-9, float(a[2]) if len(a) > 2 else 1e-3)
    else:
        print('== 平方級：格羅弗 ==')
        for N in (4, 16, 64, 10 ** 6, 10 ** 12):
            show_grover(N)
        print('\n== 指數級：秀爾 vs 一般數域篩法 ==')
        for bits in (512, 1024, 2048):
            show_shor(bits)
        print('\n== 古典模擬的極限 ==')
        for n in (30, 40, 50):
            show_memory(n)
        print('\n== 瓶頸 ==')
        show_loading(10 ** 6)
        show_cross(1e-9, 1e-3)
