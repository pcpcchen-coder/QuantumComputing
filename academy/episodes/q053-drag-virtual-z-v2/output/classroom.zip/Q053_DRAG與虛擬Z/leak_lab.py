"""父子科技學院 量子電腦學程 Q053：DRAG 與虛擬 Z 的小實驗室（只用 Python 標準函式庫）

執行：python leak_lab.py
一、照 operation.html#pulse（03_pulse.js）的算法，算方波、高斯、高斯 + DRAG 在 f₁₂ 處的頻譜高度（dB，以 f₀₁ 為 0 dB）。
二、在布洛赫球上比較「90°、虛擬 Z、90°」和「90°、90°」。
三、把線路裡只改相位的閘改成虛擬 Z，算省下多少時間（練習假設：每個真脈衝 40 ns）。
模型忽略退相干與線路失真，只用來比較趨勢。
"""
import math

ALPHA = -0.22  # f12 − f01（GHz），和動畫相同


def wave(shape, area_deg=180, tg=40.0):
    """回傳 [(t, I, Q)]，I、Q 單位 rad/ns；面積只由 I 決定。"""
    def env(t):
        if shape == 'square':
            return 1.0
        s, x = tg / 4, t - tg / 2
        return math.exp(-x * x / (2 * s * s)) - math.exp(-tg * tg / (8 * s * s))
    beta = 1 / (2 * math.pi * ALPHA)           # 讓頻譜在 f12 處為零
    n, dt, total, raw = 400, tg / 400, 0.0, []
    for i in range(n + 1):
        t = i * dt
        d_env = (env(t + 0.01) - env(t - 0.01)) / 0.02
        raw.append((t, env(t), beta * d_env if shape == 'drag' else 0.0))
        total += env(t) * dt
    k = math.radians(area_deg) / total
    return [(t, i * k, q * k) for t, i, q in raw]


def spectrum(w, f, tg):
    re = im = 0.0
    dt = tg / (len(w) - 1)
    for t, i, q in w:
        a = -2 * math.pi * f * t
        re += (i * math.cos(a) - q * math.sin(a)) * dt
        im += (i * math.sin(a) + q * math.cos(a)) * dt
    return math.hypot(re, im)


print('一、f12 處的頻譜高度（dB；動畫的圖最低只畫到 -60）')
print('  閘長度   方波    高斯    高斯+DRAG')
for tg in (40, 20, 10):          # 改造區：加 30、16 試試
    row = []
    for shape in ('square', 'gauss', 'drag'):
        w = wave(shape, 180, tg)
        row.append(20 * math.log10(spectrum(w, ALPHA, tg) / spectrum(w, 0, tg)))
    print(f'  {tg:>3} ns  {row[0]:6.1f}  {row[1]:6.1f}  {row[2]:8.1f}')


def rot(v, axis, ang):
    """布洛赫向量 v 繞單位軸 axis 轉 ang（弧度），羅德里格斯公式。"""
    a, b, c = axis
    x, y, z = v
    co, si = math.cos(ang), math.sin(ang)
    d = a * x + b * y + c * z
    return (x * co + (b * z - c * y) * si + a * d * (1 - co),
            y * co + (c * x - a * z) * si + b * d * (1 - co),
            z * co + (a * y - b * x) * si + c * d * (1 - co))


X90 = lambda v: rot(v, (1, 0, 0), math.pi / 2)   # 相位 0° 的 90° 脈衝
VZ90 = lambda v: rot(v, (0, 0, 1), math.pi / 2)  # 虛擬 Z（90°）：動畫把箭頭繞 z 轉 90°


def show(name, v):
    print(f'  {name:<26} (x, y, z) = ({v[0]:+.2f}, {v[1]:+.2f}, {v[2]:+.2f})  P(1) = {(1 - v[2]) / 2:.3f}')


print('\n二、虛擬 Z 會改變後面的脈衝')
N = (0.0, 0.0, 1.0)
show('90°、90°', X90(X90(N)))
show('90°、虛擬Z、90°', X90(VZ90(X90(N))))
show('90°、虛擬Z、90°、虛擬Z、90°', X90(VZ90(X90(VZ90(X90(N))))))

print('\n三、改成虛擬 Z 省多少時間（練習假設：每個真脈衝 40 ns）')
circuit = ['H', 'S', 'H', 'T', 'X', 'Z', 'H', 'S']   # 改造區：換成你自己的線路
phase_only = {'Z', 'S', 'T'}
before = 40 * len(circuit)
after = 40 * sum(g not in phase_only for g in circuit)
print(f'  線路 {" ".join(circuit)}')
print(f'  原本 {before} ns，改成虛擬 Z 後 {after} ns，省下 {before - after} ns（{(before - after) / before:.0%}）')
