"""父子科技學院 量子電腦學程 Q037：保真度計算小工具。

不用安裝任何套件，只要 Python 3。執行：  python fidelity_calc.py
- 讀取保真度 F = 1 − [P(1|0) + P(0|1)] / 2（學程簡報 JJ_Microwave_Readout_Talk p31）。
  P(1|0)：準備 0 卻判成 1；P(0|1)：準備 1 卻判成 0。
- 二、三部分的模型和動畫 animations/operation.html#readout（js/operation/07_readout.js 第 51–62 行）相同：
  兩團雲中心在 ±0.65、寬度 σ = 0.715 / √(4τ)（τ 是積分時間，單位 μs）；閾值滑桿值 × 1.3 是閾值位置；
  T₁ = 50 μs，讀取途中衰減的 |1⟩ 會落在兩團之間。erf 用的是動畫裡同一個近似式，所以數字和讀數一樣。
- 一、手算保真度。二、移動閾值。三、改積分時間、開關 T₁ 衰減。四、盲測練習（固定亂數種子，可重現）。
"""
import math
import random


def erf(x):
    """與 07_readout.js 第 55 行相同的近似式。"""
    s = 1 if x >= 0 else -1
    x = abs(x)
    t = 1 / (1 + 0.3275911 * x)
    y = 1 - ((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496735) * t + 0.254829592) * t * math.exp(-x * x)
    return s * y


def phi(x):
    return 0.5 * (1 + erf(x / math.sqrt(2)))


def fidelity(p10, p01):
    """兩種錯誤率（0～1）→ 讀取保真度。"""
    return 1 - (p10 + p01) / 2


def confusion(thr=0.0, tau=1.0, t1on=True, sep=1.0):
    """回傳 (P(1|0), P(0|1), F)，都是 0～1。"""
    scale, T1 = 1.3, 50
    c0, c1 = -sep * scale / 2, sep * scale / 2
    s = 0.55 * scale / math.sqrt(tau * 4)
    x = thr * scale
    p10 = 1 - phi((x - c0) / s)
    pd = 1 - math.exp(-tau / T1) if t1on else 0
    frac = min(1, max(0, (c1 - x) / (c1 - c0)))
    p11 = (1 - pd) * (1 - phi((x - c1) / s)) + pd * frac
    p01 = 1 - p11
    return p10, p01, fidelity(p10, p01)


def pct(v):
    return f'{v * 100:5.1f} %'


print('一、手算保真度')
EX = fidelity(0.02, 0.06)
print(f'  P(1|0) = 2 %、P(0|1) = 6 % → 平均錯誤 4 % → F = {EX * 100:.1f} %')

print()
print('二、移動閾值（積分時間 1 μs、T₁ 衰減開）')
THR = {}
for t in (-0.4, -0.3, -0.2, -0.1, 0.0, 0.1, 0.2, 0.3, 0.4):
    THR[t] = confusion(thr=t)
    p10, p01, f = THR[t]
    print(f'  閾值 {t:+.1f}：P(1|0) {pct(p10)}　P(0|1) {pct(p01)}　F {pct(f)}')

print()
print('三、積分時間與 T₁ 衰減（閾值 0）')
TAU = {}
for tau in (0.3, 0.5, 1.0, 2.0, 3.0, 4.0):
    TAU[tau] = (confusion(tau=tau), confusion(tau=tau, t1on=False))
    (a10, a01, af), (b10, b01, bf) = TAU[tau]
    print(f'  τ = {tau:.1f} μs：T₁ 開 P(1|0) {pct(a10)} P(0|1) {pct(a01)} F {pct(af)}｜T₁ 關 F {pct(bf)}')

print()
print('四、盲測練習（先自己猜閾值往哪邊偏，最後一行才是答案）')
rng = random.Random(37)
QUIZ = []
for k in range(1, 6):
    t = rng.choice((-0.3, -0.2, -0.1, 0.1, 0.2, 0.3))
    p10, p01, f = confusion(thr=t)
    QUIZ.append(t)
    print(f'  第 {k} 題：P(1|0) {pct(p10)}　P(0|1) {pct(p01)}　→ 閾值往哪邊偏？保真度多少？')
print('  答案：' + '、'.join(f'第 {k} 題 閾值 {t:+.1f}（{"往 |1⟩ 那團" if t > 0 else "往 |0⟩ 那團"}，F {confusion(thr=t)[2] * 100:.1f} %）'
                         for k, t in enumerate(QUIZ, 1)))
