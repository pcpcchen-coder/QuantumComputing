"""父子科技學院 量子電腦學程 Q105：BV 密碼對決——古典逐位查詢 vs 量子只查詢一次（純 Python，不需要安裝任何套件）

執行：  python bv_duel.py
做法和學程動畫 transmon-3d.html 第 9 章相同：H⊗n → 黑盒子（只查詢一次）→ H⊗n → 量測。
"""
import math
import random

SECRET = '101'      # 改造區：換成你自己的密碼（只能用 0 和 1，幾位都可以，建議 3–6 位）
SHOTS = 1000        # 量子電路重跑幾次（每個 shot：重設 → 跑電路 → 讀一次）
NOISE = 0.03        # 每顆位元讀錯的機率（3% 是動畫裡的示意值；改成 0 就是理想機器）
SEED = 7            # 亂數種子：固定它，每次跑出來的結果都一樣


def oracle(x):
    """黑盒子：只回答 s·x 的奇偶（對應位元相乘、加總、取 mod 2）"""
    return sum(int(a) * int(b) for a, b in zip(SECRET, x)) % 2


def hadamard_all(amp, n):
    """每顆位元各做一次 H（哈達瑪閘）"""
    a = amp[:]
    for q in range(n):
        bit = 1 << q
        for i in range(len(a)):
            if not i & bit:
                x, y = a[i], a[i | bit]
                a[i], a[i | bit] = (x + y) / math.sqrt(2), (x - y) / math.sqrt(2)
    return a


def show(amp, n):
    """列出振幅；位元多於 3 顆時只列前 8 個"""
    t = '  '.join(f'{i:0{n}b}:{v:+.3f}' for i, v in enumerate(amp[:8]))
    return t + ('  …' if len(amp) > 8 else '')


if __name__ == '__main__':
    n = len(SECRET)
    print(f'密碼 s = {SECRET}（{n} 位元）')
    # 古典：一次問一位
    got = ''
    for k in range(n):
        x = ''.join('1' if j == k else '0' for j in range(n))
        r = oracle(x)
        got += str(r)
        print(f'古典第 {k + 1} 次：問 x = {x} → 回答 {r}')
    print(f'古典查詢 {n} 次 → 拼出 s = {got}')
    # 量子：振幅向量（2ⁿ 個數字）
    amp = [1.0] + [0.0] * (2 ** n - 1)
    amp = hadamard_all(amp, n)
    print('① H 之後：  ', show(amp, n))
    amp = [(-1) ** oracle(f'{i:0{n}b}') * v for i, v in enumerate(amp)]
    print('② 查詢 1 次：', show(amp, n))
    amp = hadamard_all(amp, n)
    amp = [0.0 if abs(v) < 1e-12 else v for v in amp]
    print('③ 再 H 之後：', show(amp, n))
    # 量測：依振幅² 抽樣，再加上讀取誤判
    rng = random.Random(SEED)
    prob = [v * v for v in amp]
    count = {}
    for _ in range(SHOTS):
        r, k = rng.random(), 0
        while k < len(prob) - 1 and r >= prob[k]:
            r -= prob[k]
            k += 1
        for q in range(n):
            if rng.random() < NOISE:
                k ^= 1 << q
        key = f'{k:0{n}b}'
        count[key] = count.get(key, 0) + 1
    top = sorted(count.items(), key=lambda kv: -kv[1])
    print(f'量測 {SHOTS} 次（每顆位元讀錯 {NOISE:.0%}）：' + '、'.join(f'{k} {c} 次' for k, c in top[:4]))
    best, c = top[0]
    print(f'最多的是 {best}（{c / SHOTS:.1%}）→ {"猜中" if best == SECRET else "沒猜中"}')
    print(f'查詢次數：古典 {n} 次，量子 1 次')
