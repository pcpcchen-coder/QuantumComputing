"""父子科技學院 量子電腦學程 Q046：時間差 → 相位差 計算器

執行：python phase_drift.py          （不需要安裝任何套件）
改造：改下面的 FREQ（例如 4e9、8e9），或改 DF 看兩台沒鎖在一起的儀器怎麼慢慢飄走
"""

FREQ = 5e9          # 驅動微波的頻率（赫），5 GHz
REF = 10e6          # 參考時脈 10 MHz
DF = 1.0            # 兩台儀器各自走時，頻率差多少（赫）

print(f'參考時脈 {REF / 1e6:.0f} MHz：每秒 {REF:,.0f} 拍，一拍 {1 / REF * 1e9:.0f} ns')
print(f'{FREQ / 1e9:g} GHz 是參考時脈的 {FREQ / REF:,.0f} 倍；轉一圈要 {1 / FREQ * 1e9:.3f} ns')

print('\n一、時間差 → 相位差（相位差 = 360° × 頻率 × 時間差）')
for dt, name in [(1e-12, '1 ps'), (10e-12, '10 ps'), (50e-12, '50 ps'), (0.1e-9, '0.1 ns'), (0.2e-9, '0.2 ns'), (1e-9, '1 ns')]:
    deg = 360 * FREQ * dt
    print(f'  晚 {name:>6}：{deg:8.1f}°   （除掉整圈後 {deg % 360:5.1f}°）')

print(f'\n二、兩台儀器沒鎖在一起，頻率差 {DF} Hz：相位一秒一秒累積')
for t in [0.1, 0.25, 0.5, 1.0, 2.0]:
    deg = 360 * DF * t
    print(f'  {t:4} 秒後：差 {deg:6.1f}°（{deg / 360:.2f} 圈）')

print('\n三、拍手版：兩個節拍器各打各的（60 與 63 拍／分）')
for t in [5, 10, 20, 40]:
    beats = (63 - 60) / 60 * t
    print(f'  {t:2} 秒後：差 {beats:.2f} 拍')
