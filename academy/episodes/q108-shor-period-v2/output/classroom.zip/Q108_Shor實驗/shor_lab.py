"""父子科技學院 量子電腦學程 Q108：Shor 實驗——自選 N、a 找週期（純 Python，不需要安裝任何套件）

執行：  python shor_lab.py
做法和學程動畫 transmon-3d.html 第 8 章相同：H → 模指數 → 量測工作暫存器 → QFT → 量測 → 連分數與 gcd。
這是小數字示範：電腦直接用 2^t 個振幅模擬，數字一大就算不動——這正是需要量子電腦的地方。
"""
import cmath
import math
import random

N = 15              # 改造區：要分解的數（動畫可選 15 或 21）
A = 7               # 改造區：和 N 互質的 a（N = 15 時可試 2、4、7、8、11、13、14）
COUNT_QUBITS = 4    # 計數位元幾顆：4 顆 → Q = 16；5 顆 → Q = 32
SHOTS = 20          # 量子電路重跑幾次（每次都重設 → 跑完整個電路 → 量一次）
SEED = 7            # 亂數種子：固定它，每次跑出來的結果都一樣


def convergents(y, q):
    """y/q 的連分數漸近分數 [(分子, 分母), ...]"""
    out, n, d, p1, p2, q1, q2 = [], y, q, 1, 0, 0, 1
    while d:
        ai = n // d
        p, qq = ai * p1 + p2, ai * q1 + q2
        out.append((p, qq))
        p2, p1, q2, q1 = p1, p, q1, qq
        n, d = d, n - ai * d
    return out


def post_process(y, n, a, q):
    """古典後處理（和動畫相同）：連分數找候選 r → 驗算 → gcd。回傳 (成功?, 說明)"""
    if y == 0:
        return False, 'y = 0 → 沒有週期資訊，重跑'
    cands = [(p, d) for p, d in convergents(y, q) if d <= n and p > 0]
    r = 0
    for p, d in reversed(cands):
        for m in range(1, 5):
            if m * d <= n and pow(a, m * d, n) == 1:
                r = m * d
                break
        if r:
            break
    frac = '、'.join(f'{p}/{d}' for p, d in cands) or '（無）'
    if not r:
        return False, f'{y}/{q} → 漸近分數 {frac} → 找不到 r，重跑或加大 Q'
    if r % 2:
        return False, f'{y}/{q} → r = {r} 是奇數 → 換一個 a'
    h = pow(a, r // 2, n)
    if h == n - 1:
        return False, f'{y}/{q} → r = {r}，但 {a}^{r // 2} mod {n} = {h} ≡ −1 → 換一個 a'
    f1, f2 = math.gcd(h - 1, n), math.gcd(h + 1, n)
    if f1 in (1, n) or f2 in (1, n):
        return False, f'{y}/{q} → 候選 r = {r}，但 gcd 只得到 1 和 {n}（平凡因數）→ 重跑'
    return True, f'{y}/{q} → r = {r} → {a}^{r // 2} mod {n} = {h} → gcd({h - 1}, {n}) = {f1}，gcd({h + 1}, {n}) = {f2} → {n} = {f1} × {f2}'


if __name__ == '__main__':
    q = 2 ** COUNT_QUBITS
    rng = random.Random(SEED)
    print(f'N = {N}，a = {A}，計數位元 {COUNT_QUBITS} 顆（Q = {q}）')
    g = math.gcd(A, N)
    if g != 1:
        print(f'gcd({A}, {N}) = {g}：運氣好，直接找到因數 {g}，不用量子電腦')
        raise SystemExit
    f = [pow(A, x, N) for x in range(q)]
    r_true = next(k for k in range(1, N + 1) if pow(A, k, N) == 1)
    print(f'f(x) = {A}^x mod {N}：' + ', '.join(map(str, f[:12])) + ' …')
    print(f'真實週期 r = {r_true}（古典驗算：{A}^{r_true} mod {N} = 1）')
    # 量測工作暫存器（觀念上）：隨機選一個 x，留下 f 值相同的 x —— 一把間隔 r 的梳子
    w = f[rng.randrange(q)]
    comb = [x for x in range(q) if f[x] == w]
    print(f'量測工作暫存器得到 {w} → 梳子 x = ' + ', '.join(map(str, comb)))
    # QFT：把梳子轉成尖峰
    amp = [sum(cmath.exp(2j * math.pi * x * y / q) for x in comb) / math.sqrt(len(comb) * q) for y in range(q)]
    prob = [abs(v) ** 2 for v in amp]
    peaks = [(y, p) for y, p in enumerate(prob) if p > 0.005]
    print('QFT 後機率最大的 y：' + '、'.join(f'{y}（{p:.1%}）' for y, p in sorted(peaks, key=lambda t: -t[1])[:8]))
    # 量測計數暫存器 SHOTS 次，每次都做後處理
    count, ok = {}, 0
    for _ in range(SHOTS):
        u, y = rng.random(), 0
        while y < q - 1 and u >= prob[y]:
            u -= prob[y]
            y += 1
        count[y] = count.get(y, 0) + 1
    print(f'量測 {SHOTS} 次：' + '、'.join(f'y={y} {c} 次' for y, c in sorted(count.items())))
    for y in sorted(count):
        good, why = post_process(y, N, A, q)
        ok += count[y] if good else 0
        print(f'  y = {y}（{count[y]} 次）：{why}' + (' ✓' if good else ' ✗'))
    print(f'成功分解 {ok} / {SHOTS} 次')
